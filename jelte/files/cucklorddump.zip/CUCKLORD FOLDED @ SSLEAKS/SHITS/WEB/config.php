<?php

$MONGO_DATABASE = "cuckpanel";
$MONGO_PRODUCTS_COLL = "products";
$MONGO_USERS_COLL = "users";
$MONGO_CODES_COLL = "codes";
$SLEEKTO_API_KEY = "WeLgw1O2L0E4Z4";
$SIMPLE_DATABASE = "cuckpanel";
$SIMPLE_PURCHASES_COLL = "purchases";
$REFERREALS_COLL = "referreals";
$SITE_URL = "https://cucklord.pro/";
$MONGO_TOPUPS_COLL = "topups";

$PURCHASING_DISABLED = false;
$DISABLE_MSG = "Join the discord to purchase <3."/*"Please DM LevensLes#4590 on discord to purchase."*/;


$TOPUPS_DISABLED = false;
$TOPUP_MSG = "Charging balances have been temporarily disabled.";

$G2A_HASH = "1568c621-5e71-4a27-8acf-f64acdf7a9ce";
$G2A_SECRET = 'Z$SX9i?u$jNB=-kOAKs^QzZlA4@@%pVVkx=tT_cOZyZOn7nxRSurFHRPKLJG&pki';
$G2A_EMAIL = "collinsmits@hotmail.com";
$G2A_SUCCESS = "https://cucklord.pro/?page=purchases";
$G2A_FAIL = "https://cucklord.pro/?page=cancelled";

$GLOBAL_PERMISSIONS = ["None"=>0,"Media"=>1,"Staff"=>2,"Admin"=>3,"Developer"=>4,"Owner"=>5];
$STAFF_PERMISSION_LEVEL = 2;
$ADMIN_PERMISSION_LEVEL = 3;
$DEVELOPER_PERMISSION_LEVEL = 4;
$OWNER_PERMISSION_LEVEL = 5;
$FULLACCESS_PERMISSION_LEVEL = 4;

$MONGO_MANAGER = new MongoDB\Driver\Manager("mongodb://admin:asfosABFDSBFAsbfpIBHFPDSaibfvjakdbnfKJBNFkjdbf@127.0.0.1:27017");

?>