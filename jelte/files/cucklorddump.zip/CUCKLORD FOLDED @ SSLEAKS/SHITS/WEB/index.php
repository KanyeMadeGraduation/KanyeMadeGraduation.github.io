<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Upload your files</title>
</head>
<body>
    <div class="main">
        <form class="main_sub" enctype="multipart/form-data" action="index.php" method="POST">
            <div class="main_sub_content">
                <h1>Upload your file</h1>
                <hr>
                <input type="file" name="uploaded_file"></input><br />
                <input type="submit" value="Get Compile Date"></input>
            </div>
        </form>
    <div>
</body>
</html>
<?php
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "exes/";
    $path = $path . basename( $_FILES['uploaded_file']['name']);

    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {

      $output = shell_exec("cd publish && ./DPS ../exes/". basename( $_FILES['uploaded_file']['name']));
      echo "<pre>$output</pre>";

    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }
?>