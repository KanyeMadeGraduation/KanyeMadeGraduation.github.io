<?php

require "config.php";
require "G2APay.php";
use G2APay\G2APay;

$DO_FORM = false;
if (isset($_POST["item_number"]) && isset($_POST["user_secret"]) && isset($_POST["gateway"])) {

    $USER_SECRET = $_POST["user_secret"];
    $ITEM_NUMBER = $_POST["item_number"];

    $PROC_DATA = [];
    $USER_DATA = [];

    $filter = ["id"=>$ITEM_NUMBER];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
    foreach ($cursor as $document) {
        $PROC_DATA = (array)$document;
    }

    if (sizeof($PROC_DATA) == 0) {
        header('HTTP/1.0 403 Forbidden');
        exit();
    }

    $filter = ["usertoken"=>$USER_SECRET];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $USER_DATA = (array)$document;
    }

    if (sizeof($USER_DATA) == 0) {
        header('HTTP/1.0 403 Forbidden');
        exit();
    }

    $ITEM_PRICE = (double)$PROC_DATA["total"];

    if ($_POST["gateway"] !== "charge" && strtolower($_POST["referreal_code"]) !== "none") {
        $filter = ["code" => strtolower($_POST["referreal_code"])];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$REFERREALS_COLL", $query);

        $referreal_rate = 0;

        foreach ($cursor as $ass) {
            $meme = (array)$ass;
            $referreal_rate = (int)$meme["discount"];
        }

        if ($referreal_rate > 0) {
            $ITEM_PRICE = round($ITEM_PRICE * ((100-$referreal_rate) / 100), 2);
        }
    }

    if ($_POST["gateway"] === "g2a") {
        $INVOICE_ID = generateRandomNumber(16);
        $ORDER_ID = generateRandomString(16);

        $G2A_PAYMENT = new G2APay($G2A_HASH, $G2A_SECRET, $G2A_EMAIL, $G2A_SUCCESS, $G2A_FAIL, $INVOICE_ID);

        $sku = (int)$PROC_DATA["id"];
        $name = $PROC_DATA["display"];
        $quantity = 1;
        $id = (int)$PROC_DATA["id"];
        $price = $ITEM_PRICE;

        $url = 'https://cucklord.pro';

        $G2A_PAYMENT->addItem($sku, $name, $quantity, $id, $price, $url);
        $G2A_RESPONSE = $G2A_PAYMENT->test()->createOrder($ORDER_ID);

        if ($G2A_RESPONSE['success']) {
            header('Location: '.$G2A_RESPONSE['url']);
        } else {
            echo $G2A_RESPONSE['message'];
        }
    } else if ($_POST["gateway"] === "stripe") {
        if (isset($_POST["stripeToken"]) && isset($_POST["stripeEmail"])) {
            $STRIPE_TOKEN = $_POST['stripeToken'];
            $STRIPE_EMAIL = $_POST['stripeEmail'];

            require_once('stripe-php/init.php');
        \Stripe\Stripe::setApiKey("sk_live_tD1ahu7NIxmuByDZ802IVvZo");

            $STRIPE_CUSTOMER = \Stripe\Customer::create(array(
                'email' => $STRIPE_EMAIL,
                'source'  => $STRIPE_TOKEN
            ));

            $STRIPE_CHARGE = \Stripe\Charge::create(array(
                'customer' => $STRIPE_CUSTOMER->id,
                'amount'   => round($ITEM_PRICE*100),
                'currency' => "USD",
                'description' => $PROC_DATA["display"],
            ));
            $chargeJson = $STRIPE_CHARGE->jsonSerialize();
            if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){
                $amount = $chargeJson['amount'];
                $currency = $chargeJson['currency'];
                $txnID = $chargeJson['balance_transaction'];
                $status = $chargeJson['status'];
                $orderID = $chargeJson['id'];
                $payerName = $chargeJson['source']['name'];

                //TODO: Insert into db
                $bulkWrite=new MongoDB\Driver\BulkWrite;
                $doc = ["username"=>$USER_DATA["username"],"transaction_id"=>"$txnID","referreal"=>$_POST["referreal_code"],"at"=>"".date("Y-m-d H:i:s"),"orderid"=>"$orderID", "productid"=>$PROC_DATA["id"], "productname"=>$PROC_DATA["display"], "discordname"=>$USER_DATA["discord"], "email"=>$USER_DATA["email"], "status"=>"2"];
                $bulkWrite->insert($doc);
                $MONGO_MANAGER->executeBulkWrite("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $bulkWrite);

                $address="127.0.0.1";
                $port="666";
                $socketmessage = ["type"=>"purchase","gateway"=>"stripe","discordname"=>$USER_DATA["discord"],"referreal"=>$_POST["referreal_code"],"custom"=>"None","username"=>$USER_DATA["username"],"productname"=>$PROC_DATA["display"],"productid"=>$PROC_DATA["id"],"money"=>$PROC_DATA["total"],"email"=>$USER_DATA["email"],"orderid"=>$orderID,"manual"=>false];
                $msg=json_encode($socketmessage);
                $sock=socket_create(AF_INET,SOCK_STREAM,0);
                socket_connect($sock,$address,$port);
                socket_write($sock,$msg);
                socket_close($sock);

                $response = array(
                    'status' => 1,
                    'msg' => 'Your payment was successful.',
                    'txnData' => $chargeJson
                );

                echo json_encode($response);
            }
        }
    } else if ($_POST["gateway"] === "balance") {
        $USER_BALANCE = (double)$USER_DATA["balance"];

        $response = array(
            'success' => false,
            'code' => 0,
            'msg' => 'Payment processing failed.'
        );

        if ($USER_BALANCE >= (double)$ITEM_PRICE){

            $NEW_BALANCE = $USER_BALANCE - (double)$ITEM_PRICE;

            $ORDER_ID = generateRandomString(16);
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["hwid" => "".$USER_DATA["hwid"],"usertoken"=>"".$USER_DATA["usertoken"]],
                ['$set' => ['balance' => $NEW_BALANCE]]
            );
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);

            $bulkWrite=new MongoDB\Driver\BulkWrite;
            $doc = ["username"=>$USER_DATA["username"],"transaction_id"=>"None","referreal"=>$_POST["referreal_code"],"at"=>"".date("Y-m-d H:i:s"),"orderid"=>"$ORDER_ID", "productid"=>$PROC_DATA["id"], "productname"=>$PROC_DATA["display"], "discordname"=>$USER_DATA["discord"], "email"=>$USER_DATA["email"], "status"=>"2"];
            $bulkWrite->insert($doc);
            $MONGO_MANAGER->executeBulkWrite("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $bulkWrite);

            $address="127.0.0.1";
            $port="666";
            $socketmessage = ["type"=>"purchase","gateway"=>"balance","discordname"=>$USER_DATA["discord"],"referreal"=>$_POST["referreal_code"],"custom"=>"None","username"=>$USER_DATA["username"],"productname"=>$PROC_DATA["display"],"productid"=>$PROC_DATA["id"],"money"=>$PROC_DATA["total"],"email"=>$USER_DATA["email"],"orderid"=>$ORDER_ID,"manual"=>false];
            $msg=json_encode($socketmessage);
            $sock=socket_create(AF_INET,SOCK_STREAM,0);
            socket_connect($sock,$address,$port);
            socket_write($sock,$msg);
            socket_close($sock);

            $response = array(
                'success' => true,
                'code' => 1,
                'msg' => 'Successful withdraw.',
                'remaining' => $NEW_BALANCE  
            );
        } else {
            $response = array(
                'success' => false,
                'code' => -1,
                'msg' => 'Insufficent funds.',
                'balance' => $USER_BALANCE,
                'needed' => (double)$ITEM_PRICE
            );
        }

        echo json_encode($response);
    } else if ($_POST["gateway"] === "charge") {
        $data = [];
        $data["cmd"] = "_xclick";
        $data["business"] = "collinsmits@hotmail.com";
        $data["return"] = "https://cucklord.pro/?page=home";
        $data["cancel_return"] = "https://cucklord.pro/?page=home";
        $data["notify_url"] = "https://cucklord.pro/ipn.php";
        $data["currency_code"] = "USD";
        $data["item_name"] = "Virtual User Balance";
        $data["amount"] = "".round((double)$_POST["amount"], 2);
        $data["quantity"] = "1";
        $data["lc"] = "US";
        $data["bn"] = "PP-BuyNowBF";
        $data["no_shipping"] = "1";
        $data["shipping"] = "0.00";
        $data["rm"] = "2";
        $data["custom"] = $USER_SECRET;
        header('HTTP/1.0 202 Accepted');
        $DO_FORM = true;
    }

} else if (isset($_POST["transactionId"]) && isset($_POST["hash"]) && isset($_POST["userOrderId"]) && isset($_POST["amount"])) {

} else if (isset($_POST["txn_id"]) && isset($_POST["txn_type"])) {

    if (verifyTransaction($_POST) && validateTransaction($_POST["txn_id"])) {
        $TARGET_TOKEN = $_POST["custom"];

        $USER_DATA = [];
        $filter = ["usertoken"=>"$TARGET_TOKEN"];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
        foreach ($cursor as $document) {
            $USER_DATA = (array)$document;
        }

        $OLD_BALANCE = $USER_DATA["balance"];

        $NEW_BALANCE = round((double)$USER_DATA["balance"] + (double)$_POST["mc_gross"], 2);

        if (sizeof($USER_DATA) != 0) {
            $bulkWrite=new MongoDB\Driver\BulkWrite;
            $doc = ["username"=>$USER_DATA["username"],"transaction_id"=>"".$_POST["txn_id"],"at"=>"".date("Y-m-d H:i:s"), "amount"=>$_POST["mc_gross"]];
            $bulkWrite->insert($doc);
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_TOPUPS_COLL", $bulkWrite);

            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["hwid" => "".$USER_DATA["hwid"],"usertoken"=>$TARGET_TOKEN],
                ['$set' => ['balance' => "$NEW_BALANCE"]]
            );
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);

            $address="127.0.0.1";
            $port="666";
            $socketmessage = ["type"=>"usertopup","username"=>$USER_DATA["username"],"email"=>$USER_DATA["email"],"discordname"=>$USER_DATA["discord"],"amount"=>round((double)$_POST["mc_gross"], 2),"old_balance"=>$OLD_BALANCE,"new_balance"=>$NEW_BALANCE,"transaction_id"=>$_POST["txn_id"]];
            $msg=json_encode($socketmessage);
            $sock=socket_create(AF_INET,SOCK_STREAM,0);
            socket_connect($sock,$address,$port);
            socket_write($sock,$msg);
            socket_close($sock);
        } else {
            throw new Exception("User not found by token '".$TARGET_TOKEN."'");
        }
    } else {
        throw new Exception("Failed to verify transaction '".$_POST["txn_id"]."' (custom: '".$_POST["custom"]."')");
    }

} else {
    header("Location: https://cucklord.pro");
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomNumber($length = 10) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function validateTransaction($transid) {
    require "config.php";
    $filter = ["transaction_id"=>"$transid"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_TOPUPS_COLL", $query);
    $val = true;
    foreach ($cursor as $document) {
        $val = false;
    }
    return $val;
}

function verifyTransaction($data) {
    require "config.php";
    $req = 'cmd=_notify-validate';
    foreach ($data as $key => $value) {
        $value = urlencode(stripslashes($value));
        $value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i', '${1}%0D%0A${3}', $value); // IPN fix
        $req .= "&$key=$value";
    }

    $ch = curl_init("https://www.paypal.com/cgi-bin/webscr");
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
    curl_setopt($ch, CURLOPT_SSLVERSION, 6);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
    $res = curl_exec($ch);

    if (!$res) {
        $errno = curl_errno($ch);
        $errstr = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL error: [$errno] $errstr");
    }

    $info = curl_getinfo($ch);

    // Check the http response
    $httpCode = $info['http_code'];
    if ($httpCode != 200) {
        throw new Exception("PayPal responded with http code $httpCode");
    }

    curl_close($ch);

    return $res === 'VERIFIED';
}

if ($DO_FORM) {
    ?>
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post" id="paymentForm">
    <?php
        foreach ($data as $a => $b) {
            ?>
            <input type="hidden" name="<?php echo htmlentities($a); ?>" value="<?php echo htmlentities($b); ?>">
            <?php
        }
    ?>
    </form>
    <script type="text/javascript">
        document.getElementById("paymentForm").submit();
    </script>
    <?php
    echo "You will shortly get redirected to complete your payment...";
}
?>