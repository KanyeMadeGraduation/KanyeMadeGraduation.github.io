<?php
$ip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];

require "config.php";
$nigger = $_POST["nigger"];
$HWID = $_POST["HWID"];


    $filter = ['HWID' => $HWID];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_HWID_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;

        $valid = true;
    }

    if ($valid){
        echo("correctauth");

// Replace the URL with your own webhook url
$url = "https://discordapp.com/api/webhooks/664138493156392974/SA27ZC2u2h4zhaEHEqPFyZfvBsuQ8sdHLBD3LutQs-2LmLsFF-ZZ4FVSpSau3M_Ynp_2";

$hookObject = json_encode([
    /*
     * The username shown in the message
     */
    "username" => "Ghost Auth",

   
    /*
     * Whether or not to read the message in Text-to-speech
     */
    "tts" => false,
    /*
     * File contents to send to upload a file
     */
    // "file" => "",
    /*
     * An array of Embeds
     */
    "embeds" => [
        /*
         * Our first embed
         */
        [
            // Set the title for your embed
            "title" => "Google.com",

            // The type of your embed, will ALWAYS be "rich"
            "type" => "rich",

            // A description for your embed
            "description" => "",

            // The URL of where your title will be a link to
            "url" => "https://www.google.com/",

            /* A timestamp to be displayed below the embed, IE for when an an article was posted
             * This must be formatted as ISO8601
             */
            "timestamp" => "2018-03-10T19:15:45-05:00",

            // The integer color to be used on the left side of the embed
            "color" => hexdec( "FFFFFF" ),

            // Field array of objects
            "fields" => [
                // Field 1
                [
                    "name" => "$ip",
                    "value" => "$HWID",
                    "inline" => false
                ],
                // Field 2
                [
                    "name" => "Data B",
                    "value" => "Value B",
                    "inline" => true
                ],
                // Field 3
                [
                    "name" => "Data C",
                    "value" => "Value C",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

$ch = curl_init();

curl_setopt_array( $ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);

$response = curl_exec( $ch );
curl_close( $ch );

    }
    //else{
    //     echo "Fucking cunt is bad yes here is hwid i got: $HWID";
    // }


    
?>

