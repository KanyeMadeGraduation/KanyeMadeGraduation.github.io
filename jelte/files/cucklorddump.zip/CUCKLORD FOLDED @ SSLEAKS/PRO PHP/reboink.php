<?php

$id = $_POST["id"];

$base_url = "https://api.sleek.to/tests/restart";

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => $base_url,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => array(
        "token" => "WgHtpkiFrLbPY3",
        "test_id" => $id
    )
));

$response = curl_exec($curl);
curl_close($curl);

echo $response;