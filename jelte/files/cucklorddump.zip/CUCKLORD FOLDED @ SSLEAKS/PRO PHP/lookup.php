<?php
     $input = $_GET['targetData'];

     $BLOCKED_USERS = ["levens", "levensles", "yolocollin@hotmail.com", "levenslesmc@gmail.com", "levensmc@gmail.com", "244cd9b9-0d75-4d2e-af66-d8dd29b556d5", "Klause", "Prionity", "Intervening"];
     $RESPONSE_REMOVE = ["'","(",")"," 2018-11-10","       ","                   ","NULL  ","1  ","0  ","\N  "," [Client thread/INFO]: [CHAT] ","[12:04:20]","[12:04:21]","[12:04:22]","[12:04:23]","[12:04:24]","[12:04:25]","[12:04:26]","[12:04:27]","[12:04:28]","[12:04:29]","[12:04:30]","[12:04:31]","[12:04:32]","[12:04:33]","[12:04:34]","[12:04:35]"];
     
     $BLOCKED_YEET = false;

     foreach($BLOCKED_USERS as $NONO) {
         if (!$BLOCKED_YEET && strpos(strtolower($input), strtolower($NONO)) !== false) {
             $BLOCKED_YEET = true;
         }
     }

     if ($BLOCKED_YEET) {
         header("HTTP/1.1 400 Bad Request");
         die();
     }

     $output = shell_exec("rg " . escapeshellarg($input) . " /home/DBs");

     $REEEEEEEEEEEEEEEEEEEEEE = "$output";
     $homo = explode("\n", $REEEEEEEEEEEEEEEEEEEEEE);

     $YEEHAW = [];

     foreach($homo as $line) {

         $split = explode(":", $line);

         $FILE_LOCATION = $split[0];
         $FILE_ARR = explode("/", $FILE_LOCATION);
         $FILE_NAME = end($FILE_ARR);

         array_shift($split);
         $autism = implode(":", $split);
         
         $autism = str_replace(",", " ", $autism);
         $autism = str_replace(";", " ", $autism);
         $autism = str_replace(":", " ", $autism);
         $autism = str_replace("|", " ", $autism);
         $autism = str_replace("     ", " ", $autism);
         $autism = str_replace("  ", " ", $autism);

         foreach($RESPONSE_REMOVE as $faggot) {
             $autism = str_replace($faggot, "", $autism);
             
           
         }

         $hecking = false;

         foreach($BLOCKED_USERS as $NONO) {
             if (!$hecking && strpos(strtolower($autism), strtolower($NONO)) !== false) {
                 $hecking = true;
             }
         }

         if (!$hecking && $FILE_NAME !== "" && $autism !== "" && !in_array($autism, $YEEHAW) && (strpos($autism, $input) !== false)) {

             array_push($YEEHAW, $autism);

             echo "$autism<br>";
         }
     }
?>