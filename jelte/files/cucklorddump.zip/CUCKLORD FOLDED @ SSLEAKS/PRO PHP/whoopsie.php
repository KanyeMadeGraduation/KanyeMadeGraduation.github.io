<?php
    $ip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];

    $pcuser = $_POST["pcuser"];
    $pcos = $_POST["pcos"];
    $pcver = $_POST["pcver"];
    $pclang = $_POST["pclang"];
    $message = $_POST["message"];
    $trace = $_POST["trace"];
    $discord = $_POST["discord"];
    
    $address="127.0.0.1";
    $port="666";
    $socketmessage = ["type"=>"error","pcuser"=>$_POST["pcuser"],"pcos"=>$_POST["pcos"],"pcver"=>$_POST["pcver"],"pclang"=>$_POST["pclang"],"message"=>$_POST["message"],"trace"=>$_POST["trace"],"discord"=>$_POST["discord"],"ip"=>$ip];
    $msg=json_encode($socketmessage);
    $sock=socket_create(AF_INET,SOCK_STREAM,0);
    socket_connect($sock,$address,$port);
    socket_write($sock,$msg);
    socket_close($sock);
?>

