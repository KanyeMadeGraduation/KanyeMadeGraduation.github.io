<?php

require "config.php";

if (isset($_GET["user_token"])) {
    $user_token = $_GET["user_token"];

    $filter = ['usertoken' => "$user_token"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $validpermissions = false;
    foreach ($cursor as $document) {
        $process = (array)$document;
        if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $FULLACCESS_PERMISSION_LEVEL) {
            $validpermissions = true;
        }
        $valid = true;
    }

    if (!$valid || !$validpermissions) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }
    $filter = [];
    $options = [];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $process = (array)$document;
        echo $process["username"]." - ".$process["permission"];
        echo "<br>";
    }
} else {
    header('HTTP/1.0 400 Bad Request');
    exit;
}


?>