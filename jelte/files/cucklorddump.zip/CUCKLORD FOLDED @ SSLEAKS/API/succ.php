<?php

require "config.php";

if (!isset($_GET["yes"]) || strcmp($_GET["yes"], "agkdaGASg9sagakljgAgaagdoIS)dgaA") !== 0) {
    die("you fucking cocksucker.");
}

$filter = ["activated"=>false];
$options = [];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
foreach ($cursor as $document) {
    $DATA = (array)$document;
    $BULK_WRITE = new MongoDB\Driver\BulkWrite;
    $BULK_WRITE->delete(
        ["username" => $DATA["username"], "email" => $DATA["email"]]
    );
    $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
    echo $DATA["username"]." has been removed. <br>";
}
echo "Complete.";

?>