<?php

require "config.php";

$realip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];

if (isset($_GET["hwid"])) {
    $hwid = $_GET["hwid"];
    $OWNS_CUCKLORD = false;

    if ($hwid === "" || strlen($hwid) != 32) {
        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"auth","hwid"=>$hwid,"ip"=>$realip,"username"=>"None","result"=>"Failed (Invalid HWID)"];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $filter = ['hwid' => "$hwid"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;
        $valid = true;
    }

    if ($USR_DTA["banned"] === true) {
        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"auth","hwid"=>$hwid,"ip"=>$realip,"username"=>$USR_DTA["username"],"result"=>"Failed (Banned)"];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);
        header("HTTP/1.1 403 Forbidden");
        die();
    }

    $OTHER_ACCESS = false;
    $IS_STAFF = $valid ? ($GLOBAL_PERMISSIONS[$USR_DTA["permission"]] >= $STAFF_PERMISSION_LEVEL) : false;

    if ($valid && !$IS_STAFF) {
        $filter = ["email"=>$USR_DTA["email"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001") {
                $OTHER_ACCESS = true;
            }
        }
    }

    if ($valid && !$OTHER_ACCESS) {
        $PERMS = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]];
        if ($PERMS >= $STAFF_PERMISSION_LEVEL) {
            $OTHER_ACCESS = true;
        }
    }

    if ($valid && $OTHER_ACCESS) {

        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"auth","hwid"=>$hwid,"ip"=>$realip,"username"=>$USR_DTA["username"],"result"=>"Success"];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);

        $LULUL = (array)isset($USR_DTA["past_ips"]) ? $USR_DTA["past_ips"] : [];
        if (!empty($USR_DTA["lastip"]) && !in_array($USR_DTA["lastip"], $LULUL)) {
            array_push($LULUL, $USR_DTA["lastip"]);
        }

        $BULK_WRITE = new MongoDB\Driver\BulkWrite;
        $BULK_WRITE->update(
            ["hwid" => "$hwid"],
            ['$set' => ['lastip' => "$realip", 'past_ips' => (array)$LULUL]]
        );
        $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);

        $responsetype = "json";

        if (isset($_GET["responsetype"])) {
            if ($_GET["responsetype"] === "plaintext") {
                $responsetype = "plaintext";
            }
        }

        if ($responsetype === "json") {
            header('Content-Type: application/json');
            echo json_encode($USR_DTA, JSON_PRETTY_PRINT);
        } else {
            foreach ($USR_DTA as $key => $value) {
                if (is_array($key) || is_array($value)) continue;
                echo $key."=".$value;
                echo "_:_";
            }
        }
    } else {
        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"auth","hwid"=>$hwid,"ip"=>$realip,"username"=>$USR_DTA["username"],"result"=>"Failed (No access)"];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

?>