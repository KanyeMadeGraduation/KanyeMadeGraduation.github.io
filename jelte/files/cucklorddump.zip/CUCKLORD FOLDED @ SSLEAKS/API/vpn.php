<?php

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["token"]) && isset($_POST["ip"])) {
    $TOKEN = $_POST["token"];
    $IP = $_POST["ip"];

    $MONGO_MANAGER = new MongoDB\Driver\Manager("mongodb://admin:laKJSDGHQ12ladgjk1A@127.0.0.1:27017");
    $SLEEKTO_API_KEY = "WeLgw1O2L0E4Z4";

    $filter = ['token' => "$TOKEN"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("vpncheck.tokens", $query);
    $valid = false;
    $TOKEN_DATA = [];
    foreach ($cursor as $document) {
        $TOKEN_DATA = (array)$document;
        $valid = true;
    }

    if (!$valid || sizeof($TOKEN_DATA) == 0) {
        header("HTTP/1.1 403 Unauthorized");
        die();
    }

    $base_url = "https://api.sleek.to/vpn_check?token=".$SLEEKTO_API_KEY."&ip=".$IP;

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $base_url,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    echo $response;
} else {
    header("HTTP/1.1 400 Bad Request");
}

?>