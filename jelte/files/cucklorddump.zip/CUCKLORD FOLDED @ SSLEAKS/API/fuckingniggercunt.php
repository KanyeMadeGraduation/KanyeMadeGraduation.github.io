<?php

if (isset($_GET["hwid"])) {
    require "config.php";
    $hwid = $_GET["hwid"];
    $OWNS_CUCKLORD = false;

    if ($hwid === "" || strlen($hwid) != 32) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $filter = ['hwid' => "$hwid"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;
        $valid = true;
    }

    $OTHER_ACCESS = false;
    $IS_STAFF = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]] >= $STAFF_PERMISSION_LEVEL;

    if ($valid && !$IS_STAFF) {
        $filter = ["email"=>$USR_DTA["email"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001" || $STORED_PURCHASE_DATA["productid"] === "0003") {
                $OTHER_ACCESS = true;
            }
        }
    }

    if ($valid && !$OTHER_ACCESS) {
        $PERMS = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]];
        if ($PERMS >= $STAFF_PERMISSION_LEVEL) {
            $OTHER_ACCESS = true;
        }
    }

    if ($valid && $OTHER_ACCESS) {
        $file = "/home/CuckClicker.exe";

        if (file_exists($file)) {
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=".generateRandomString(3).".exe");
            header("Content-Transfer-Encoding: binary");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Pragma: public");
            header("Content-Length: ".filesize($file));

            ob_clean();
            flush();
            readfile($file);
        } else {
            header("HTTP/1.1 410 Gone");
        }

        die();
    } else {
        header("HTTP/1.1 403 Unauthorized");
    }
} else {
    header("HTTP/1.1 400 Bad Request");
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>