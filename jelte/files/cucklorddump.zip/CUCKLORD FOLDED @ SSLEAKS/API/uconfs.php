<?php

require "config.php";

if (!isset($_GET["method"])) {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

if (strcmp($_GET["method"], "save") == 0) {
    $parameters = ["configName", "minCPS", "maxCPS", "cpsDropping", "cpsSpiking", "extremeRand", "instantStart", "blockhit", "retardClick", "delayBetweenBlockhits", "publicConfig"];
} else if (strcmp($_GET["method"], "delete") == 0) {
    $parameters = ["configName"];
} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}


if (isset($_GET["hwid"])) {
    $hwid = $_GET["hwid"];
    foreach($parameters as $param) {
        if (!isset($_GET[$param])) {
            header('HTTP/1.1 400 Bad Request');
            exit;
        }
    }
    $OWNS_CUCKLORD = false;

    if ($hwid === "" || strlen($hwid) != 32) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $filter = ['hwid' => "$hwid"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;
        $valid = true;
    }

    $OTHER_ACCESS = false;
    $IS_STAFF = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]] >= $STAFF_PERMISSION_LEVEL;

    if ($valid && !$IS_STAFF) {
        $filter = ["email"=>$USR_DTA["email"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001" || $STORED_PURCHASE_DATA["productid"] === "0003") {
                $OTHER_ACCESS = true;
            }
        }
    }

    if ($valid && !$OTHER_ACCESS) {
        $PERMS = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]];
        if ($PERMS >= $STAFF_PERMISSION_LEVEL) {
            $OTHER_ACCESS = true;
        }
    }

    if ($valid && $OTHER_ACCESS) {

        $HAS_CONF = 0;

        $filter = ["display"=>$_GET["configName"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.userconfigs", $query);
        $STORED_CONFIG_DATA = [];
        $kneega = false;
        foreach ($cursor as $document) {
            $STORED_CONFIG_DATA = (array)$document;
            $kneega = true;
        }

        $filter = ["author"=>$USR_DTA["username"]];
        $options = [];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.userconfigs", $query);
        foreach ($cursor as $document) {
            $HAS_CONF++;
        }

        if ($kneega && strcmp($STORED_CONFIG_DATA["author"], $USR_DTA["username"]) !== 0) {
            echo "-69";
            exit;
        }

        if ($HAS_CONF >= 3) {
            echo "-420";
            exit;
        }

        if (strcmp($_GET["method"], "save") == 0) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["display" =>$_GET["configName"]],
                ['$set' => [
                    "name"=>$USR_DTA["username"]."-".$_GET["configName"],
                    "display"=>$_GET["configName"],
                    "author"=>$USR_DTA["username"],
                    "minCPS"=>(int)$_GET["minCPS"],
                    "maxCPS"=>(int)$_GET["maxCPS"],
                    "cpsDropping"=>(bool)$_GET["cpsDropping"],
                    "cpsSpiking"=>(bool)$_GET["cpsSpiking"],
                    "extremeRand"=>(bool)$_GET["extremeRand"],
                    "instantStart"=>(bool)$_GET["instantStart"],
                    "blockhit"=>(bool)$_GET["blockhit"],
                    "retardClick"=>(bool)$_GET["retardClick"],
                    "delayBetweenBlockhits"=>(int)$_GET["delayBetweenBlockhits"],
                    "publicConfig"=>(bool)$_GET["publicConfig"]
                    ]
                ],
                ["upsert" => true]
            );
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.userconfigs", $BULK_WRITE);
            $end = (int)$UPDATE_RESULT->getUpsertedCount() + (int)$UPDATE_RESULT->getUpdatedCount();
            echo $end;
        } else if (strcmp($_GET["method"], "delete") == 0) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->delete(['display' => $_GET["configName"], 'author' => $USR_DTA["username"]], ['limit' => 1]);
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.userconfigs", $BULK_WRITE);
            $end = (int)$UPDATE_RESULT->getDeletedCount();
            echo $end;
        } else {
            echo "wrong method";
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

?>