<?php

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "https://129.6.13.35/actualtime.cgi");
$nigger = curl_exec($curl);

?>