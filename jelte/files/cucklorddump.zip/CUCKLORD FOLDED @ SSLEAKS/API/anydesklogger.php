<?php

require "config.php";

if (isset($_GET["user_token"]) && isset($_GET["username"]) && isset($_GET["anydeskname"]) && isset($_GET["anydeskaddress"]) && isset($_GET["anydeskip"])) {
    $user_token = $_GET["user_token"];

    $filter = ['usertoken' => "$user_token"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $validpermissions = false;
    foreach ($cursor as $document) {
        $process = (array)$document;
        if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $CUSTOMER_PERMISSION_LEVEL) {
            $validpermissions = true;
        }
        $valid = true;
    }

    if (!$valid || !$validpermissions) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $sentby = $_GET["username"];
    $username = $_GET["anydeskname"];
    $id = $_GET["anydeskaddress"];
    $ip = $_GET["anydeskip"];
    $identifier = generateRandomString(32);
    $time = microtime(true);

    $bulkWrite=new MongoDB\Driver\BulkWrite;
    $doc=["identifier"=>"$identifier","username" => "$username", "resolvedby"=>"$sentby", "anydeskid"=>"$id", "resolvedip"=>"$ip", "time"=>"$time"];
    $bulkWrite->insert($doc);
    $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_ANYDESK_COLL", $bulkWrite);
    header('HTTP/1.0 201 Created');
    $filter = ['identifier' => "$identifier"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_ANYDESK_COLL", $query);
    header('HTTP/1.0 201 Created');
    foreach ($cursor as $document) {
        $process = (array)$document;
        header('Content-Type: application/json');
        echo json_encode($process, JSON_PRETTY_PRINT);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>