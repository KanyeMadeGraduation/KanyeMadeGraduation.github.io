<?php

require "config.php";

if (isset($_GET["hwid"])) {
    $hwid = $_GET["hwid"];
    $OWNS_CUCKLORD = false;

    $realip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];


    if ($hwid === "" || strlen($hwid) != 32) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $filter = ['hwid' => "$hwid"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;
        $valid = true;
    }

    $OTHER_ACCESS = false;
    $IS_STAFF = false;

    if ($valid) {
        $IS_STAFF = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]] >= $STAFF_PERMISSION_LEVEL;
    }

    if ($valid && !$IS_STAFF) {
        $filter = ["email"=>$USR_DTA["email"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001" || $STORED_PURCHASE_DATA["productid"] === "0003") {
                if (!$STORED_PURCHASE_DATA["banned"]) {
                    $OTHER_ACCESS = true;
                }
            }
        }
    }

    if ($valid && !$OTHER_ACCESS) {
        $PERMS = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]];
        if ($PERMS >= $STAFF_PERMISSION_LEVEL) {
            $OTHER_ACCESS = true;
        }
    }

    if ($valid && $OTHER_ACCESS) {

        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"authC","hwid"=>$hwid,"ip"=>$realip,"username"=>$USR_DTA["username"],"result"=>"Success"];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);

        $realip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];
        $BULK_WRITE = new MongoDB\Driver\BulkWrite;
        $BULK_WRITE->update(
            ["hwid" => "$hwid"],
            ['$set' => ['lastip' => "$realip"]]
        );
        $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);

        $responsetype = "json";

        if (isset($_GET["responsetype"])) {
            if ($_GET["responsetype"] === "plaintext") {
                $responsetype = "plaintext";
            }
        }

        if ($responsetype === "json") {
            header('Content-Type: application/json');
            echo json_encode($USR_DTA, JSON_PRETTY_PRINT);
        } else {
            foreach ($USR_DTA as $key => $value) {
                if (is_array($key) || is_array($value)) {
                    continue;
                }
                echo $key."=".$value;
                echo "_:_";
            }
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

?>