<?php
require "../config.php";

$args = ["server"];

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    header("HTTP/1.1 400 Bad Request");
    die();
}

foreach($args as $arg) {
    if (!isset($_GET["$arg"])) {
        header("HTTP/1.1 400 Bad Request");
        die();
    }
}

$SERVER = $_GET["server"];

$filter = ['server' => "$SERVER"];
$options = [ 'limit' => 1 ];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("cucklord-alts.servers", $query);
$valid = false;
$SERVER_DATA = [];
foreach ($cursor as $document) {
    $SERVER_DATA = (array)$document;
    $valid = true;
}
header("Content-Type: application/json");
if (!$valid) {
    die(json_encode(["success"=>false,"server"=>"$SERVER","error"=>"Server not found"]));
}

$filter = ['id' => "".$SERVER_DATA["license"]];
$options = [ 'limit' => 1 ];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("cucklord-alts.licenses", $query);
$lvalid = false;
$LICENSE_DATA = [];
foreach ($cursor as $document) {
    $LICENSE_DATA = (array)$document;
    $lvalid = true;
}

if (!$lvalid) {
    die(json_encode(["success"=>false,"server"=>"$SERVER","error"=>"License not found"]));
}

$ione = (int)$SERVER_DATA["daily_alt_limit"];
$itwo = (int)$LICENSE_DATA["alt_limit"];

if ($ione >= $itwo) {
    die(json_encode(["success"=>false,"server"=>"$SERVER","error"=>"Account limit reached"]));
}

$ione = $ione + 1;

$BULK_WRITE = new MongoDB\Driver\BulkWrite;
$BULK_WRITE->update(
    ["id" => "".$SERVER],
    ['$set' => ['daily_alt_limit' => $ione]]
);
$UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("cucklord-alts.servers", $BULK_WRITE);

die(json_encode(["success"=>true,"server"=>"$SERVER","data"=>["account"=>"test@email.com:password"]]));

?>