<?php
require "../config.php";

$args = ["server"];

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    header("HTTP/1.1 400 Bad Request");
    die();
}

foreach($args as $arg) {
    if (!isset($_GET["$arg"])) {
        header("HTTP/1.1 400 Bad Request");
        die();
    }
}

$SERVER = $_GET["server"];

$filter = ['server' => "$SERVER"];
$options = [ 'limit' => 1 ];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("cucklord-alts.servers", $query);
$valid = false;
$SERVER_DATA = [];
foreach ($cursor as $document) {
    $SERVER_DATA = (array)$document;
    $valid = true;
}
header("Content-Type: application/json");

if (!$valid) {
    die(json_encode(["success"=>false,"server"=>"$SERVER","error"=>"Server not found"]));
}

$filter = ['id' => "".$SERVER_DATA["license"]];
$options = [ 'limit' => 1 ];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("cucklord-alts.licenses", $query);
$lvalid = false;
$LICENSE_DATA = [];
foreach ($cursor as $document) {
    $LICENSE_DATA = (array)$document;
    $lvalid = true;
}

if (!$lvalid) {
    die(json_encode(["success"=>false,"server"=>"$SERVER","error"=>"License not found"]));
}

die(json_encode(["success"=>true,"server"=>"$SERVER","license"=>["status"=>strcmp($SERVER_DATA["license"], "None") !== 0,"name"=>$LICENSE_DATA["name"],"at"=>$SERVER_DATA["license_at"],"license_alts"=>$LICENSE_DATA["alt_limit"]],"data"=>["remaining_alts"=>$SERVER_DATA["daily_alt_limit"],"stock"=>0,"restock"=>"Never"]]));
?>