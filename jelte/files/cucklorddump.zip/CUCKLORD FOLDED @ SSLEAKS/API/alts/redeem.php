<?php
require "../config.php";

$args = ["server", "token"];

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    header("HTTP/1.1 400 Bad Request");
    die();
}

foreach($args as $arg) {
    if (!isset($_POST["$arg"])) {
        header("_GET/1.1 400 Bad Request");
        die();
    }
}

$SERVER = $_GET["server"];
$TOKEN = $_GET["token"];
?>