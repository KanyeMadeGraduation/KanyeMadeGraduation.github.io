<?php

require "config.php";

if (isset($_GET["user_token"]) &&isset($_GET["hwid"]) && isset($_GET["username"]) && isset($_GET["password"]) && isset($_GET["disabled"]) && isset($_GET["permission"]) && isset($_GET["email"]) && isset($_GET["inviter"]) && isset($_GET["products"])) {
    $user_token = $_GET["user_token"];

    $filter = ['usertoken' => "$user_token"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $validpermissions = false;
    foreach ($cursor as $document) {
        $process = (array)$document;
        if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $FULLACCESS_PERMISSION_LEVEL) {
            $validpermissions = true;
        }
        $valid = true;
    }

    if (!$valid || !$validpermissions) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $username = $_GET["username"];
    $password = $_GET["password"];
    $token = generateRandomString(64);
    $disabled = $_GET["disabled"];
    $permission = $_GET["permission"];
    $lastip = isset($_GET["lastip"]) ? $_GET["lastip"] : "0.0.0.0";
    $registeredat = microtime(true);
    $lastlogin = "0";
    $email = $_GET["email"];
    $inviter = $_GET["inviter"];
    $products = $_GET["products"];
    $hwid = $_GET["hwid"];

    $bulkWrite=new MongoDB\Driver\BulkWrite;
    $doc=['username' => "$username", "password"=>"$password","usertoken"=>"$token","disabled"=>"$disabled","permission"=>"$permission","lastip"=>"$lastip","registeredat"=>"$registeredat","lastlogin"=>"$lastlogin","email"=>"$email","inviter"=>"$inviter","products"=>"$products","hwid"=>"$hwid","passreset"=>"false"];
    $bulkWrite->insert($doc);
    $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $bulkWrite);

    $filter = ['usertoken' => "$token"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    header('HTTP/1.0 201 Created');
    foreach ($cursor as $document) {
        $process = (array)$document;
        header('Content-Type: application/json');
        echo json_encode($process, JSON_PRETTY_PRINT);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


?>