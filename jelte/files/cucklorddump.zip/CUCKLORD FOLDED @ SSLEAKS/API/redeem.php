<?php

require "config.php";

if (isset($_GET["orderid"])) {
    $ORDER_ID = $_GET["orderid"]

    $filter = ['orderid' => "$ORDER_ID", "status" => "2"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.purchases", $query);
    $HOMOKANK = [];
    foreach ($cursor as $document) {
        $HOMOKANK = (array)$document;
        $valid = true;
    }

    if (!$valid) {
        die("nigger");
    }

    $BULK_WRITE = new MongoDB\Driver\BulkWrite;
    $BULK_WRITE->update(
        ["orderid" => "$ORDER_ID", "status" => "2"],
        ['$set' => ['status' => "0"]]
    );
    $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.purchases", $BULK_WRITE);

    die("kank|".$HOMOKANK["productid"]."|".$HOMOKANK["username"]."|".$HOMOKANK["email"]);
}

?>