<?php

$MONGO_DATABASE = "cuckpanel";
$MONGO_USERS_COLL = "users";
$MONGO_ANYDESK_COLL = "anydesk";
$MONGO_PROD_COLL = "products";
$MONGO_ATTACKS_COLL = "attacks";
$MONGO_PURCHASES_COLL = "purchases";
$MONGO_TOKENS_COLL = "tokens";

$AUTH_ENABLED = false;

$SLEEKTO_API_KEY = "WgHtpkiFrLbPY3";
$SLEEKTO_API_KEY_TWO = "fmtuNuqGLX4LZW";

$GLOBAL_PERMISSIONS = ["None"=>0,"Media"=>1,"Staff"=>2,"Admin"=>3,"Developer"=>4,"Owner"=>5];
$STAFF_PERMISSION_LEVEL = 2;
$ADMIN_PERMISSION_LEVEL = 3;
$DEVELOPER_PERMISSION_LEVEL = 4;
$OWNER_PERMISSION_LEVEL = 5;
$FULLACCESS_PERMISSION_LEVEL = 4;

$MONGO_MANAGER = new MongoDB\Driver\Manager("mongodb://admin:asfosABFDSBFAsbfpIBHFPDSaibfvjakdbnfKJBNFkjdbf@127.0.0.1:27017");

?>