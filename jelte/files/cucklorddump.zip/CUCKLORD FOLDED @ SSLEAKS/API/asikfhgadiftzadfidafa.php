<?php

require "config.php";

if (!isset($_POST["adgfdajghdagda"]) || strcmp($_POST["adgfdajghdagda"], "glockisajokeniggerfgaggotototptot") !== 0) {
  die("die nigger");
}

if (isset($_POST["ign"]) && isset($_POST["screenshot"]) && isset($_POST["ip"]) && isset($_POST["UniqueID"]) && isset($_POST["tool"])) {
    $yootyeetfaggot = decrypt(base64_decode($_POST["screenshot"]), "C0420ckl690rDn169g911GeRR420");
    $address="127.0.0.1";
    $port="666";
    $socketmessage = ["type"=>"sstool","tool"=>$_POST["tool"],"ign"=>$_POST["ign"],"screenshot"=>"$yootyeetfaggot","ip"=>$_POST["ip"],"UniqueID"=>$_POST["UniqueID"],"sentfrom"=>"php"];
    $msg=json_encode($socketmessage);
    $sock=socket_create(AF_INET,SOCK_STREAM,0); 
    socket_connect($sock,$address,$port);
    socket_write($sock,$msg);
    socket_close($sock);

    $bulkWrite=new MongoDB\Driver\BulkWrite;
    $doc=["ign"=>$name,"screenshoturl"=>$yootyeetfaggot,"ip"=>$_POST["ip"],"UniqueID"=>$_POST["UniqueID"], "sstool"=>$_POST["tool"]];
    $bulkWrite->insert($doc);
    $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.sstools", $bulkWrite);
} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

function decrypt($ivHashCiphertext, $password) {
    $method = "AES-256-CBC";
    $iv = substr($ivHashCiphertext, 0, 16);
    $hash = substr($ivHashCiphertext, 16, 32);
    $ciphertext = substr($ivHashCiphertext, 48);
    $key = hash('sha256', $password, true);

    if (hash_hmac('sha256', $ciphertext, $key, true) !== $hash) return null;

    return openssl_decrypt($ciphertext, $method, $key, OPENSSL_RAW_DATA, $iv);
}

?>