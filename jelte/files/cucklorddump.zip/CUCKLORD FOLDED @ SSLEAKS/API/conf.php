<?php

require "config.php";

if (isset($_GET["hwid"])) {
    $hwid = $_GET["hwid"];
    $OWNS_CUCKLORD = false;

    if ($hwid === "" || strlen($hwid) != 32) {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

    $filter = ['hwid' => "$hwid"];
    $options = [ 'limit' => 1 ];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $USR_DTA = [];
    foreach ($cursor as $document) {
        $USR_DTA = (array)$document;
        $valid = true;
    }

    $OTHER_ACCESS = false;
    $IS_STAFF = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]] >= $STAFF_PERMISSION_LEVEL;

    if ($valid && !$IS_STAFF) {
        $filter = ["email"=>$USR_DTA["email"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001" || $STORED_PURCHASE_DATA["productid"] === "0003") {
                $OTHER_ACCESS = true;
            }
        }
    }

    if ($valid && !$OTHER_ACCESS) {
        $PERMS = $GLOBAL_PERMISSIONS[$USR_DTA["permission"]];
        if ($PERMS >= $STAFF_PERMISSION_LEVEL) {
            $OTHER_ACCESS = true;
        }
    }

    if ($valid && $OTHER_ACCESS) {
        $filter = [];
        $options = [];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.clickerconfigs", $query);
        foreach ($cursor as $document) {
            $dta = (array)$document;
            echo $dta["name"]."_:_".$dta["display"]."_:_".$dta["minCPS"]."_:_".$dta["maxCPS"]."_:_".($dta["cpsDropping"] ? "1" : "0")."_:_".($dta["cpsSpiking"] ? "1" : "0")."_:_".($dta["extremeRand"] ? "1" : "0")."_:_".($dta["instantStart"] ? "1" : "0")."_:_".($dta["blockhit"] ? "1" : "0")."_:_".($dta["retardClick"] ? "1" : "0")."_:_".$dta["delayBetweenBlockhits"]."[#]";
        }
    } else {
        header('HTTP/1.0 403 Forbidden');
        exit;
    }

} else {
    header('HTTP/1.1 400 Bad Request');
    exit;
}

?>