<?php

if (!isset($_GET["token"]) || $LOGGED_IN) {
    die("no");
}

$TOKEN = $_GET["token"];

$filter = ["activation_token"=>"$TOKEN","activated"=>false];
$options = ["limit"=>1];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
$yeet = [];
foreach($cursor as $document) {
    $thing = (array)$document;
    $yeet = $thing;
}

if (sizeof($yeet) == 0) {
    die("still no");
}

$BULK_WRITE = new MongoDB\Driver\BulkWrite;
$BULK_WRITE->update(
    ["activation_token" => "$TOKEN", "activated"=>false],
    ['$set' => ['activated' =>true]]
);
$UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);

$_SESSION["MESSAGE_ID"] = 135676523;
header("location: index.php?page=login".$REFERREAL_PART);
die();
?>