<?php

require "config.php";
if (!$LOGGED_IN) {
    header("location: index.php?page=home");
}

?>

<div class="row productsrow">
    <div class="card productcard text-center" style="margin-top:5rem; width: 25rem;">
        <div class="card-header productname text-white">
        Order cancelled
        </div>
        <div class="card-body">
            <form action="/index.php">
                <input type="hidden" name="page" value="products" />
                <p class="card-text cost">You have cancelled your order.</p>
                <p class="card-text">You may try again by returning to our products page.</p>
                <br>
                <button type="submit" class="btn btn-primary continue">Return</button>
            </form>
        </div>
    </div>
</div>