<?php

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
}

?>
<style type="text/css">
    .productcard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .productname {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .productpurchase {
        background-color: #515172;
        border-color: #515172;
        top: 90%;
    }
    .productpurchase:hover, .productpurchase:focus, .productpurchase:active, .productpurchase.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
        width: 100%;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .product-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .product-list-group {
        list-style: none;
    }

    .productdet {
        font-size: 22.5px;
    }

    .productsrow {
        display: flex;
        justify-content: center;
        align-self: center;
    }
</style>

<script type="text/javascript">
<?php
if ($PURCHASING_DISABLED) {
    ?>
    $(document).ready(function() {
        setTimeout(function() {
            toastr.options = {
                timeOut: 0,
                extendedTimeOut: 0
            };

            toastr.error("<?php echo $DISABLE_MSG; ?>");
        }, 200);
    });
    <?php
}
if ($TOPUPS_DISABLED) {
    ?>
    $(document).ready(function() {
        setTimeout(function() {
            toastr.options = {
                timeOut: 0,
                extendedTimeOut: 0
            };

            toastr.error("<?php echo $TOPUP_MSG; ?>");
        }, 200);
    });
    <?php
}
?>
</script>

<div class="row productsrow">

<?php
$filter = [];
$options = [];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
foreach ($cursor as $document) {
    $process = (array)$document;
    if ($process["enabled"]) {
        $features = (array)$process["features"];
        ?>
        <div class="card productcard text-center" style="margin-top:5rem; width: 18rem;">
            <div class="card-header productname text-white">
            <?php echo $process["fullname"]; ?>
            </div>
            <div class="card-body d-flex flex-column">
                <p class="card-text timestamp"><?php echo $process["period"]; ?></p>
                <hr/>
                <ul class="product-list-group list-group">
                    <?php
                    foreach($features as $feature) {
                        ?>
                        <li class="productdet"><?php echo $feature; ?></li>
                        <?php
                    }
                    ?>
                </ul>
                <hr/>
                <p class="mt-auto card-text cost"><?php echo $process["fmoney"]; ?></p>
                <?php
                if (!$PURCHASING_DISABLED/* || $STAFF_LEVEL >= $ADMIN_PERMISSION_LEVEL*/) {
                    ?>
                        <a href="?page=buy&product=<?php echo $process["name"]; ?><?php echo $REFERREAL_PART; ?>" class="btn btn-primary productpurchase">Purchase</a>
                    <?php
                } else {
                    ?>
                    <a href="#" disabled class="btn btn-primary productpurchase">Purchase</a>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }
}

?>