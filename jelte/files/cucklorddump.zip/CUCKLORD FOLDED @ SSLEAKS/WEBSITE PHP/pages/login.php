<?php

if ($LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if (isset($_POST["lol"])) {
    $PASSWORD_SALT = "sqjfdajdu6rd67ARDauzsdta86SD5AR67asfFGADFGAFdasdJSU6AafsdgDDgasfagR5674R6UsdghFDADFZUZARD564ufzuzasrs7d6aaUTasdfaDFS56as";
    $LOGIN_NAME = $_POST["usernameData"];
    $LOGIN_PASSWORD = $_POST["passwordData"];
    $HASHED_PASSWORD = strtoupper(hash('sha512', $PASSWORD_SALT.$LOGIN_PASSWORD));
    $filter = ["username"=>"$LOGIN_NAME"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $banned = false;
    $accountactivated = false;
    $STORED_INFO = [];
    $REFERREAL_PART = "";
    if (isset($_POST["r"])) {
        $REFERREAL_PART = "&r=".$_POST["r"];
    }
    foreach ($cursor as $document) {
        $valid = true;
        $STORED_INFO = (array)$document;
        if (strcmp($STORED_INFO["password"], $HASHED_PASSWORD) !== 0) {
            $_SESSION["MESSAGE_ID"] = 2;
            header("location: index.php?page=login".$REFERREAL_PART);
            die();
        }
        if (!isset($STORED_INFO["activated"])) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => "".$STORED_INFO["user_id"]],
                ['$set' => ['activated' =>true]]
            );
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
            $accountactivated = true;
        } else {
            $accountactivated = $STORED_INFO["activated"];
        }
        if ($STORED_INFO["banned"]) {
            $banned = true;
        }
    }
    if ($valid) {
        if ($banned) {
            $_SESSION["MESSAGE_ID"] = 104;
            $_SESSION["BANNED_REASON"] = $STORED_INFO["banreason"];
            header("location: index.php?page=login".$REFERREAL_PART);
            die();
        } else if (!$accountactivated) {
            $_SESSION["MESSAGE_ID"] = 11244;
            header("location: index.php?page=login".$REFERREAL_PART);
            die();
        } else {
            $_SESSION["USERNAME"] = $STORED_INFO["username"];
            $_SESSION["PASSWORD"] = $STORED_INFO["password"];
            $_SESSION["EMAIL"] = $STORED_INFO["email"];
            $_SESSION["PERMISSION"] = $STORED_INFO["permission"];
            $_SESSION["MESSAGE_ID"] = 1;
            header("location: index.php?page=home".$REFERREAL_PART);
            die();
        }
    } else {
        $_SESSION["MESSAGE_ID"] = 2;
        header("location: index.php?page=login".$REFERREAL_PART);
        die();
    }
}

?>
<style type="text/css">
    .sitecard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .sitename {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .sitebutton {
        background-color: #515172;
        border-color: #515172;
    }
    .sitebutton:hover, .sitebutton:focus, .sitebutton:active, .sitebutton.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .site-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .site-list-group {
        list-style: none;
    }

    .sitedet {
        font-size: 22.5px;
    }

    .siterow {
        display: flex;
        justify-content: center;
        align-self: center;
    }
</style>

<?php

if (isset($_SESSION["MESSAGE_ID"])) {
    $MID = $_SESSION["MESSAGE_ID"];
    if ($MID == 2) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Invalid credentials!</strong> You have entered an invalid password or username.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == 5) {
        ?>
        <div class="alert alert-success" role="alert">
            <strong>Welcome!</strong> You have successfully registered, you can now log in.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == 104) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Cannot log in!</strong> Your account is currently suspended for "<?php echo $_SESSION["BANNED_REASON"]; ?>".
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
        unset($_SESSION["BANNED_REASON"]);
    }
}

?>

<div class="row siterow">
    <div class="card sitecard text-center" style="margin-top:5rem; width: 18rem;">
        <div class="card-header sitename text-white">
        Log in
        </div>
        <div class="card-body">

            <form action="/index.php" method="post">
                <input type="hidden" name="page" value="login" />
                <input type="hidden" name="lol" value="login" />
                <?php
                if ($USR_REFERREAL !== "") {
                    ?>
                        <input type="hidden" name="r" value="<?php echo $USR_REFERREAL; ?>"/>
                    <?php
                }
                ?>
                <div class="form-group">
                    <label for="usernameData">Username</label>
                    <input type="username" class="form-control" name="usernameData" id="usernameData" aria-describedby="usernameHelp" placeholder="Enter your username">
                </div>
                <div class="form-group">
                    <label for="discordData">Password</label>
                    <input type="password" class="form-control" name="passwordData" id="passwordData" aria-describedby="passwordHelp" placeholder="Enter your password">
                </div>
                <button type="submit" class="btn btn-primary sitebutton">Log in</button>
            </form>
        </div>
    </div>
</div>

<?php

if(isset($_SESSION["MESSAGE_ID"])) {
    if ($_SESSION["MESSAGE_ID"] == 654) {
        ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        <script type="text/javascript">
            Swal.fire({
                title: '<strong>Activation Required</strong>',
                type: 'warning',
                html: 'We have sent a verification email to you. Please click on the link to activate your account.',
                showCloseButton: false,
                showCancelButton: false,
                focusConfirm: true,
                confirmButtonText: 'OK',
                confirmButtonAriaLabel: 'OK',
            });
        </script>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    } else if ($_SESSION["MESSAGE_ID"] == 135676523) {
        ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        <script type="text/javascript">
            Swal.fire({
                title: '<strong>Activation Completed</strong>',
                type: 'success',
                html: 'You have successfully verified your account. You can now log in.',
                showCloseButton: false,
                showCancelButton: false,
                focusConfirm: true,
                confirmButtonText: 'OK',
                confirmButtonAriaLabel: 'OK',
            });
        </script>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    } else if ($_SESSION["MESSAGE_ID"] == 11244) {
        ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        <script type="text/javascript">
            Swal.fire({
                title: '<strong>Activation Required</strong>',
                type: 'error',
                html: "Your account isn't verified yet.",
                showCloseButton: false,
                showCancelButton: false,
                focusConfirm: true,
                confirmButtonText: 'OK',
                confirmButtonAriaLabel: 'OK',
            });
        </script>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
}

?>