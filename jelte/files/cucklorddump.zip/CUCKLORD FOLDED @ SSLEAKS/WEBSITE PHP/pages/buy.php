<?php

require "config.php";

$PRODUCT = "Unknown";

if(isset($_GET["product"])) {
    $PRODUCT = $_GET["product"];
} else {
    header("location: index.php?page=home".$REFERREAL_PART);
}

$STAGE = "0";

if (isset($_GET["stage"])) {
    $STAGE = $_GET["stage"];
} else {
    header("location: index.php?page=buy&product=".$PRODUCT."&stage=".$STAGE.$REFERREAL_PART);
}

$USER_EMAIL = "UNSPECIFIED";
$USER_DISCORD = "UNSPECIFIED";
$USER_SERVER_ID = "NONE";
$USE_SERVER_ID = false;

if ($STAGE == "1") {
    if (isset($_GET["emailData"]) && isset($_GET["discordData"])) {
        if ($_GET["emailData"] === "" || $_GET["discordData"] === "") {
            $STAGE = "0";
            header("location: index.php?page=buy&product=".$PRODUCT."&stage=".$STAGE.$REFERREAL_PART);
        } else {
            $USER_EMAIL = $_GET["emailData"];
            $USER_DISCORD = $_GET["discordData"];
            if(isset($_GET["serverData"])) {
                if ($_GET["serverData"] === "") {
                    $STAGE = "0";
                    header("location: index.php?page=buy&product=".$PRODUCT."&stage=".$STAGE.$REFERREAL_PART);
                } else {
                    $USER_SERVER_ID = $_GET["serverData"];
                    $USE_SERVER_ID = true;
                }
            }
        }
    } else {
        $STAGE = "0";
        header("location: index.php?page=buy&product=".$PRODUCT."&stage=".$STAGE.$REFERREAL_PART);
    }

    $filter = ["username"=>"$USERNAME"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $process = (array)$document;
        
        $BULK_WRITE = new MongoDB\Driver\BulkWrite;
        $BULK_WRITE->update(
            ["username" => $USERNAME],
            ['$set' => ['discord' => $USER_DISCORD]],
            ['multi' => false, 'upsert' => false]
        );

        $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
    }
}

$PROC_DATA = [];

$filter = ["name"=>"$PRODUCT"];
$options = ["limit"=>1];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
foreach ($cursor as $document) {
    $PROC_DATA = (array)$document;
}

if (sizeof($PROC_DATA) == 0) {
    header("location: index.php?page=products&error=invalid_product".$REFERREAL_PART);
}

$CURRENT_PRODUCT_DATA = $PROC_DATA;
$FORM_ACTION = "/index.php?page=buy&product=.$PRODUCT.&stage=1".$REFERREAL_PART;

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$NEW_PRICE = (double)$CURRENT_PRODUCT_DATA["total"];

if ($REFERREAL_DISCOUNT > 0) {
    $NEW_PRICE = round($NEW_PRICE * ((100-$REFERREAL_DISCOUNT) / 100), 2);;
}


?>

<script type="text/javascript">
<?php
if ($PURCHASING_DISABLED) {
    ?>
    $(document).ready(function() {
        setTimeout(function() {
            toastr.options = {
                timeOut: 0,
                extendedTimeOut: 0
            };

            toastr.error("<?php echo $DISABLE_MSG; ?>");
        }, 200);
    });
    <?php
}
if ($TOPUPS_DISABLED) {
    ?>
    $(document).ready(function() {
        setTimeout(function() {
            toastr.options = {
                timeOut: 0,
                extendedTimeOut: 0
            };

            toastr.error("<?php echo $TOPUP_MSG; ?>");
        }, 200);
    });
    <?php
}
?>
</script>

<?php

if ($PURCHASING_DISABLED) {
    ?>
    <div class="row datarow">
        <div class="card datacard text-center" style="margin-top:5rem; width: 30rem;">
            <div class="card-header datacardname text-white">
            Purchase
            </div>
            <div class="card-body">
                <div class="alert alert-danger" role="alert">
                    YOU DO NOT HAVE PERMISSION TO VIEW THIS CONTENT AT THIS TIME.
                </div>
            </div>
        </div>
    </div>
    <?php
} else {

    if($STAGE == 0) {
        ?>

            <div class="row productsrow">
                <div class="card productcard text-center" style="margin-top:5rem; width: 18rem;">
                    <div class="card-header productname text-white">
                    <?php if(!$LOGGED_IN) {
                        echo "Notice";
                    } else {
                        echo $PRODUCT;
                    } ?>
                    </div>
                    <div class="card-body">

                        <?php

                        if (!$LOGGED_IN) {
                            ?>
                            <p class="card-text cost">Please <a href="index.php?page=login<?php echo $REFERREAL_PART; ?>">log in</a> or <a href="index.php?page=register<?php echo $REFERREAL_PART; ?>">register</a> to continue.</p>
                            <?php
                        } else {

                        ?>

                        <form id="buystage0form" action="/index.php">
                            <input type="hidden" name="page" value="buy" />
                            <input type="hidden" name="product" value="<?php echo $PRODUCT; ?>" />
                            <input type="hidden" name="stage" value="1" />
                            <input type="hidden" name="emailData" value="<?php echo $EMAIL; ?>" />
                            <?php
                            if ($USR_REFERREAL !== "") {
                                ?>
                                    <input type="hidden" name="r" value="<?php echo $USR_REFERREAL; ?>"/>
                                <?php
                            }
                            ?>
                            <p class="card-text timestamp"><?php echo $CURRENT_PRODUCT_DATA["display"]; ?></p>
                            <hr/>
                            <?php
                            if(strpos($DISCORD, "#") !== false) {
                                ?>
                                <p class="card-text">No need to enter your discord name today.</p>
                                <input type="hidden" name="discordData" value="<?php echo $DISCORD; ?>" />
                                <?php
                            } else {
                                ?>
                                <div class="form-group">
                                    <label for="discordData">Discord Name (with #)</label>
                                    <input type="text" class="form-control" name="discordData" id="discordData" aria-describedby="discordHelp" placeholder="Enter your discord with #">
                                </div>
                                <?php
                            }
                            ?>
                            <?php

                            if(strpos($DISCORD, "#") !== false) {
                                ?>
                                <script type="text/javascript">
                                    <?php if (!$PURCHASING_DISABLED || $STAFF_LEVEL >= $ADMIN_PERMISSION_LEVEL) { ?>
                                        $("#buystage0form").submit();
                                    <?php } ?>
                                </script>
                                <?php
                            }

                            ?>
                            <hr/>
                            <p class="card-text cost"><?php echo $CURRENT_PRODUCT_DATA["fmoney"]; ?></p>
                            <button type="<?php if (!$PURCHASING_DISABLED || $STAFF_LEVEL >= $ADMIN_PERMISSION_LEVEL) { ?> submit <?php } ?>" <?php if ($PURCHASING_DISABLED && $STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) { ?>disabled<?php } ?> class="btn btn-primary continue">Continue</button>
                        </form>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>

        <?php
    }

    if ($STAGE == 1) {
        ?>

        <script src="https://embed.selly.gg"></script>

            <div class="row productsrow">
                <div class="card productcard text-center" style="margin-top:5rem; width: 30rem;">
                    <div class="card-header productname text-white">
                    Payment
                    </div>
                    <div class="card-body">
                        <input type="hidden" id="payProcess" value="0"/>
                        <?php

                        if (!$LOGGED_IN) {
                            ?>
                            <p class="card-text cost">Please <a href="index.php?page=login">log in</a> or <a href="index.php?page=register">register</a> to continue.</p>
                            <?php
                        } else if (!$CURRENT_PRODUCT_DATA["enabled"]) {
                            ?>
                            <p class="card-text cost">This product is disabled lmao yeet</p>
                            <?php
                        } else {
                        ?>
                        <form id="buy-form">
                            <input type="hidden" name="item_number" value="<?php echo $CURRENT_PRODUCT_DATA["id"]; ?>">
                            <input type="hidden" name="user_secret" value="<?php echo $USER_TOKEN; ?>">
                            <input type="hidden" name="purchaser_email" value="<?php echo $EMAIL; ?>">
                            <input type="hidden" name="purchaser_discord" value="<?php echo $DISCORD; ?>">
                            <input type="hidden" name="purchaser_username" value="<?php echo $USERNAME; ?>">
                            <input type="hidden" name="referreal_code" value="<?php if ($USR_REFERREAL === "") { echo "None"; } else { echo $USR_REFERREAL; } ?>">
                            <p class="card-text cost">Verification</p>

                            <hr/>

                            <p class="card-text cost"><?php echo $CURRENT_PRODUCT_DATA["display"]; ?></p>
                            <p class="card-text">Paying: $<?php echo $NEW_PRICE; ?></p>

                            <hr/>
                            <br>

                            <div class="form-check">
                                <input class="form-check-input" id="nigoswitcho" type="checkbox" value="" id="defaultCheck1">
                                <label class="form-check-label" for="defaultCheck1">
                                    I agree to the <a href="" id="tosopen">Terms Of Service</a>.
                                </label>
                            </div>
                            <br>

                            <?php
                            $kankerneger = strtolower($CURRENT_PRODUCT_DATA["alternate_url"]) !== "none" && $CURRENT_PRODUCT_DATA["alternate_url"] !== "";
                            ?>

                            <button type="submit" id="balancebutton" disabled class="btn btn-primary continue payment-button">Continue <small>with Balance</small></button>
                            <?php if ($kankerneger) { ?> <br> <br> <?php } ?>
                            <?php
                            if ($kankerneger) {
                                if (strtolower($CURRENT_PRODUCT_DATA["alternate_url"]) !== "none" && $CURRENT_PRODUCT_DATA["alternate_url"] !== "") {
                                    if (strpos(strtolower($CURRENT_PRODUCT_DATA["alternate_domain"]), "selly") !== false) {
                                        ?>
                                        <button type="submit" id="alternatebutton-selly" disabled class="btn btn-primary continue payment-button"  data-selly-product="<?php echo $CURRENT_PRODUCT_DATA["alternate_url"]; ?>">Continue <small>with <?php echo $CURRENT_PRODUCT_DATA["alternate_domain"]; ?></small></button>
                                        <?php
                                    } else {
                                        ?>
                                        <button type="submit" id="alternatebutton" disabled class="btn btn-primary continue payment-button">Continue <small>with <?php echo $CURRENT_PRODUCT_DATA["alternate_domain"]; ?></small></button>
                                        <?php
                                    }
                                }
                            }
                            ?>
                            
                        </form>
                        <div id="load-form" style="display:none">
                            <p id="load-form-p" class="card-text cost">Processing...</p>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php
    }
}
?>

<script src="https://checkout.stripe.com/checkout.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">

    $("#tosopen").click(function() {
        $("#tosnav").click();
        return false;
    });

    function enableButtons() {
        $("#balancebutton").attr("disabled", false);
        $("#stripebutton").attr("disabled", false);
        $("#alternatebutton").attr("disabled", false);
        $("#alternatebutton-selly").attr("disabled", false);
    }

    function disableButtons() {
        $("#balancebutton").attr("disabled", true);
        $("#stripebutton").attr("disabled", true);
        $("#alternatebutton").attr("disabled", true);
        $("#alternatebutton-selly").attr("disabled", true);
    }

    $("#nigoswitcho").change(function() {
        if (this.checked) {
            enableButtons();
        } else {
            disableButtons();
        }
    });

    var handler = StripeCheckout.configure({
        key: 'pk_live_ynJU5EcauIwWnV62taklDd7U',
        image: '../files/logo.png',
        locale: 'auto',
        token: function(token) {
            $('#payProcess').val(1);
            $.ajax({
                url: 'ipn.php',
                type: 'POST',
                data: {gateway: "stripe", referreal_code: "<?php if ($USR_REFERREAL === "") { echo "None"; } else { echo $USR_REFERREAL; } ?>", stripeToken: token.id, stripeEmail: token.email, item_number: '<?php echo $CURRENT_PRODUCT_DATA["id"]; ?>', user_secret: '<?php echo $USER_TOKEN; ?>'},
                dataType: "json",
                beforeSend: function(){
                    $('.payment-button').prop('disabled', true);
                },
                success: function(data){
                    $('#payProcess').val(0);
                    if(data.status == 1){
                        $('#buy-form').hide();
                        $("#load-form").show();
                        toastr.success("You have successfully purchased this product.");
                        $("#load-form-p").html("Waiting for user confirmation...");
                        Swal.fire({
                            title: '<strong>Info</strong>',
                            type: 'info',
                            html:
                                'You have to <strong>join our discord to complete this purchase</strong>. Please click on the <strong>link in the navbar</strong> or <a href="https://discord.gg/tCnBDE7">click here</a>. If you do not join you <strong>will not receive support</strong>.',
                            showCloseButton: false,
                            showCancelButton: false,
                            focusConfirm: true,
                            confirmButtonText:
                                'OK',
                            confirmButtonAriaLabel: 'OK',
                        }).then((result) => {
                            $("#load-form-p").html("Processing...");
                            setTimeout(function() {
                                window.location.replace("https://cucklord.pro/?page=purchased");
                            },2000);
                        });
                    }else {
                        $('.payment-button').prop('disabled', false);
                        toastr.error('Some problem occurred, please try again.');
                    }
                },
                error: function(data) {
                    $('#payProcess').val(0);
                    $('.payment-button').prop('disabled', false);
                    toastr.error('Some problem occurred, please try again.');
                    console.log(data);
                }
            });
        }
    });

    var stripe_closed = function(){
        var processing = $('#payProcess').val();
        if (processing == 0){
            $('.payment-button').prop('disabled', false);
        }
    };

    var stripe_opened = function(){
        $(".Textbox-label").addClass("phchanged");
    };

    window.addEventListener('popstate', function() {
        handler.close();
    });


    $("#stripebutton").click(function() {
        var price = Math.round(<?php echo (float)$NEW_PRICE * 100; ?>);
        handler.open({
            name: 'Cucklord',
            description: '<?php echo $CURRENT_PRODUCT_DATA["fullname"]; ?>',
            amount: price,
            currency: 'USD',
            opened: stripe_opened,
            closed:	stripe_closed
        });
        return false;
    });

    $("#alternatebutton").click(function() {
        Swal.fire({
            title: '<strong>Attention Required</strong>',
            type: 'warning',
            html: 'This payment method is not currently automated. It may take up to 24 hours until your order completes.<br>Upon purchase please join our <a href="https://discord.gg/ZrgxhAG">Discord</a> and DM LevensLes with proof of purchase.',
            showCloseButton: false,
            showCancelButton: true,
            focusConfirm: true,
            confirmButtonText: 'OK',
            confirmButtonAriaLabel: 'OK',
            cancelButtonText: 'Cancel',
            cancelButtonAriaLabel: 'Cancel',
        }).then(ok => {
            if (ok.value) {
                window.location.href = "<?php echo $CURRENT_PRODUCT_DATA["alternate_url"]; ?>";
                window.location.replace("<?php echo $CURRENT_PRODUCT_DATA["alternate_url"]; ?>");
            }
        });
        return false;
    });

    $("#alternatebutton-selly").click(function() {
    });

    $("#balancebutton").click(function() {
        var price = Math.round(<?php echo (float)$NEW_PRICE * 100; ?>);
        $.ajax({
            url: 'ipn.php',
            type: 'POST',
            data: {gateway: "balance", referreal_code: "<?php if ($USR_REFERREAL === "") { echo "None"; } else { echo $USR_REFERREAL; } ?>", item_number: '<?php echo $CURRENT_PRODUCT_DATA["id"]; ?>', user_secret: '<?php echo $USER_TOKEN; ?>'},
            dataType: "json",
            beforeSend: function(){
                $('.payment-button').prop('disabled', true);
            },
            success: function(data){
                if(data.success){
                    $('#buy-form').hide();
                    $("#load-form").show();
                    toastr.success("You have successfully purchased this product.");
                    $("#load-form-p").html("Waiting for user confirmation...");
                    Swal.fire({
                        title: '<strong>Info</strong>',
                        type: 'info',
                        html:
                            'You have to <strong>join our discord to complete this purchase</strong>. Please click on the <strong>link in the navbar</strong> or <a href="https://discord.gg/ZrgxhAG">click here</a>. If you do not join you <strong>will not receive support</strong>.',
                        showCloseButton: false,
                        showCancelButton: false,
                        focusConfirm: true,
                        confirmButtonText:
                            'OK',
                        confirmButtonAriaLabel: 'OK',
                    }).then((result) => {
                        $("#load-form-p").html("Processing...");
                        setTimeout(function() {
                            window.location.replace("https://cucklord.pro/?page=purchased");
                        },2000);
                    });
                }else {
                    $('.payment-button').prop('disabled', false);
                    if (data.code === -1) {
                        toastr.error('You do not have enough money in your balance.');
                    } else {
                        toastr.error('Some problem occurred, please try again.');
                    }
                }
            },
            error: function(data) {
                toastr.error('Some problem occurred, please try again.');
                console.log(data);
            }
        });
        return false;
    });
</script>
