<?php

session_destroy();
unset($_SESSION["USERNAME"]);
unset($_SESSION["PASSWORD"]);
$LOGGED_IN = false;
header("location: index.php?page=login".$REFERREAL_PART);
die();

?>