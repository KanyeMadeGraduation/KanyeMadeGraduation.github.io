<?php

if ($LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if (isset($_POST["lol"])) {
    $PASSWORD_SALT = "sqjfdajdu6rd67ARDauzsdta86SD5AR67asfFGADFGAFdasdJSU6AafsdgDDgasfagR5674R6UsdghFDADFZUZARD564ufzuzasrs7d6aaUTasdfaDFS56as";
    $LOGIN_NAME = $_POST["usernameData"];
    $LOGIN_PASSWORD = $_POST["passwordData"];
    $HASHED_PASSWORD = strtoupper(hash('sha512', $PASSWORD_SALT.$LOGIN_PASSWORD));
    $filter = ["username"=>"$LOGIN_NAME","password"=>"$HASHED_PASSWORD"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    $banned = false;
    $accountactivated = false;
    $STORED_INFO = [];
    $REFERREAL_PART = "";
    if (isset($_POST["r"])) {
        $REFERREAL_PART = "&r=".$_POST["r"];
    }
    foreach ($cursor as $document) {
        $valid = true;
        $STORED_INFO = (array)$document;
        if (!isset($STORED_INFO["activated"])) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => "".$STORED_INFO["user_id"]],
                ['$set' => ['activated' =>true]]
            );
            $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
            $accountactivated = true;
        } else {
            $accountactivated = $STORED_INFO["activated"];
        }
        if ($STORED_INFO["banned"]) {
            $banned = true;
        }
    }
    if ($valid) {
        if ($banned) {
            $_SESSION["MESSAGE_ID"] = 104;
            $_SESSION["BANNED_REASON"] = $STORED_INFO["banreason"];
            header("location: index.php?page=login".$REFERREAL_PART);
            die();
        } else if (!$accountactivated) {
            $_SESSION["MESSAGE_ID"] = 11244;
            header("location: index.php?page=login".$REFERREAL_PART);
            die();
        } else {
            $_SESSION["USERNAME"] = $STORED_INFO["username"];
            $_SESSION["PASSWORD"] = $STORED_INFO["password"];
            $_SESSION["EMAIL"] = $STORED_INFO["email"];
            $_SESSION["PERMISSION"] = $STORED_INFO["permission"];
            $_SESSION["MESSAGE_ID"] = 1;
            header("location: index.php?page=home".$REFERREAL_PART);
            die();
        }
    } else {
        $_SESSION["MESSAGE_ID"] = 2;
        header("location: index.php?page=login".$REFERREAL_PART);
        die();
    }
}

?>
<style type="text/css">
    .sitecard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .sitename {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .sitebutton {
        background-color: #515172;
        border-color: #515172;
    }
    .sitebutton:hover, .sitebutton:focus, .sitebutton:active, .sitebutton.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .site-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .site-list-group {
        list-style: none;
    }

    .sitedet {
        font-size: 22.5px;
    }

    .siterow {
        display: flex;
        justify-content: center;
        align-self: center;
    }
</style>

<?php

if (isset($_SESSION["MESSAGE_ID"])) {
    $MID = $_SESSION["MESSAGE_ID"];
    if ($MID == 6644) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Invalid credentials!</strong> The provided email is not associated with an account.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
}

?>

<div class="row siterow">
    <div class="card sitecard text-center" style="margin-top:5rem; width: 18rem;">
        <div class="card-header sitename text-white">
        Password Reset
        </div>
        <div class="card-body">

            <form action="/index.php" method="post">
                <input type="hidden" name="page" value="reset" />
                <input type="hidden" name="lol" value="reset" />
                <?php
                if ($USR_REFERREAL !== "") {
                    ?>
                        <input type="hidden" name="r" value="<?php echo $USR_REFERREAL; ?>"/>
                    <?php
                }
                ?>
                <div class="form-group">
                    <label for="emailData">Email</label>
                    <input type="email" class="form-control" name="emailData" id="emailData" aria-describedby="emailHelp" placeholder="Enter your email">
                </div>
                <button type="submit" class="btn btn-primary sitebutton">Reset</button>
            </form>
        </div>
    </div>
</div>