<?php

if ($LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

require './mailer/Exception.php';
require './mailer/PHPMailer.php';
require './mailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST["lol"])) {
    $PASSWORD_SALT = "sqjfdajdu6rd67ARDauzsdta86SD5AR67asfFGADFGAFdasdJSU6AafsdgDDgasfagR5674R6UsdghFDADFZUZARD564ufzuzasrs7d6aaUTasdfaDFS56as";
    $NEW_USERNAME = $_POST["usernameData"];
    $NEW_EMAIL = $_POST["emailData"];
    $NEW_PASSWORD = $_POST["passwordData"];
    $NDISCORD_NAME = $_POST["discordData"];
    $HASHED_PASSWORD = strtoupper(hash('sha512', $PASSWORD_SALT.$NEW_PASSWORD));
    $NUSER_TOKEN = generateRandomString(32);
    $invaliduser = false;
    $invalidemail = false;
    $invaliddc = false;
    $REFERREAL_PART = "";
    if (isset($_POST["r"])) {
        $REFERREAL_PART = "&r=".$_POST["r"];
    }

    $filter = ["username"=>"$NEW_USERNAME"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $invaliduser = true;
    }
    
    $filter = ["email"=>"$NEW_EMAIL"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $invalidemail = true;
    }

    if ($NDISCORD_NAME === "" || strpos($NDISCORD_NAME, "#") == false) {
        $invaliddc = true;
    }

    if (!$invaliduser) {
        if (!preg_match('/^[a-zA-Z0-9]{4,31}$/', $NEW_USERNAME)) {
            $invaliduser = true;
        }
    }

    if (!$invaliddc) {
        if (!preg_match('/(.*)#(\d{4})$/', $NDISCORD_NAME)) {
            $invaliddc = true;
        }
    }

    if ($invaliduser) {
        $_SESSION["MESSAGE_ID"] = 3;
    }
    if ($invalidemail) {
        $_SESSION["MESSAGE_ID"] = 4;
    }
    if ($invaliddc) {
        $_SESSION["MESSAGE_ID"] = -7;
    }

    if(!$invaliduser && !$invalidemail && !$invaliddc) {

        $ACTIVATION_TOKEN = generateRandomString(16);

        $bulkWrite=new MongoDB\Driver\BulkWrite;
        $doc = ["username"=>"$NEW_USERNAME","email"=>"$NEW_EMAIL","password"=>"$HASHED_PASSWORD","at"=>"".date("Y-m-d"),"permission"=>"None","usertoken"=>$NUSER_TOKEN,"discord"=>$NDISCORD_NAME,"hwid"=>"","banned"=>false,"banreason"=>"","bannedby"=>"","bannedat"=>"","user_id"=>generateRandomNumber(16),"activated"=>false,"activation_token"=>$ACTIVATION_TOKEN];
        $bulkWrite->insert($doc);
        $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $bulkWrite);

        $mail = new PHPMailer;

        $mail->IsSMTP();
        $mail->SMTPDebug = 0;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'ssl';
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 465;
        $mail->Username = "cucklord.pro@gmail.com";
        $mail->Password = "Schildpad12@";
        $mail->SetFrom("billing@cucklord.pro", "Cucklord");
        $mail->Subject = "Email Verification";
        $mail->Body = "Please click this link to activate your account: https://cucklord.pro/index.php?page=activate&token=".$ACTIVATION_TOKEN;
        $mail->IsHTML(true);
        $mail->AddAddress("$NEW_EMAIL");

        if (!$mail->send()) {
            $_SESSION["MESSAGE_ID"] = -341;
        } else {
            $_SESSION["MESSAGE_ID"] = 654;
            header("location: index.php?page=login".$REFERREAL_PART);
        }
    }

}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomNumber($length = 10) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
<style type="text/css">
    .sitecard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .sitename {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .sitebutton {
        background-color: #515172;
        border-color: #515172;
    }
    .sitebutton:hover, .sitebutton:focus, .sitebutton:active, .sitebutton.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .site-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .site-list-group {
        list-style: none;
    }

    .sitedet {
        font-size: 22.5px;
    }

    .siterow {
        display: flex;
        justify-content: center;
        align-self: center;
    }
</style>

<?php

if (isset($_SESSION["MESSAGE_ID"])) {
    $MID = $_SESSION["MESSAGE_ID"];
    if ($MID == 3) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Invalid credentials!</strong> This username is already in use.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == 4) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Invalid credentials!</strong> This email is already in use.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == -7) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Invalid credentials!</strong> You have entered an invalid discord name.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == -341) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Email error!</strong> Verification email could not be sent.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
}

?>

<div class="row siterow">
    <div class="card sitecard text-center" style="margin-top:5rem; width: 25rem;">
        <div class="card-header sitename text-white">
        Register
        </div>
        <div class="card-body">

            <form action="/index.php" method="post">
                <input type="hidden" name="page" value="register" />
                <input type="hidden" name="lol" value="reg" />
                <?php
                if ($USR_REFERREAL !== "") {
                    ?>
                        <input type="hidden" name="r" value="<?php echo $USR_REFERREAL; ?>"/>
                    <?php
                }
                ?>
                <div class="form-group">
                    <label for="usernameData">Username</label>
                    <input type="username" class="form-control" name="usernameData" id="usernameData" aria-describedby="usernameHelp" placeholder="Enter your username">
                </div>
                <div class="form-group">
                    <label for="discordData">Discord Name</label>
                    <input type="text" class="form-control" name="discordData" id="discordData" aria-describedby="discordHelp" placeholder="Enter your discord with #">
                </div>
                <div class="form-group">
                    <label for="emailData">Email</label>
                    <input type="email" class="form-control" name="emailData" id="emailData" aria-describedby="emailHelp" placeholder="Enter your email">
                </div>
                <div class="form-group">
                    <label for="discordData">Password</label>
                    <input type="password" class="form-control" name="passwordData" id="passwordData" aria-describedby="passwordHelp" placeholder="Enter your password">
                </div>
                <button type="submit" class="btn btn-primary sitebutton">Register</button>
            </form>
        </div>
    </div>
</div>