<?php

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if ($STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if (!isset($_POST["target"])) {
    header("location: index.php?page=admin".$REFERREAL_PART);
    die();
}

$TARGET_DATA = [];

$filter = ["user_id"=>$_POST["target"]];
$options = ["limit"=>1];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
$valid = false;
foreach ($cursor as $document) {
    $valid = true;
    $TARGET_DATA = (array)$document;
}
if (!$valid) {
    header("Location: index.php?page=admin");
    die();
}

if ($GLOBAL_PERMISSIONS[$TARGET_DATA["permission"]] > $STAFF_LEVEL && $STAFF_LEVEL < $FULLACCESS_PERMISSION_LEVEL) {
    header("Location: index.php?page=admin&invalid_permissions");
    die();
}

$PASSWORD_SALT = "sqjfdajdu6rd67ARDauzsdta86SD5AR67asfFGADFGAFdasdJSU6AafsdgDDgasfagR5674R6UsdghFDADFZUZARD564ufzuzasrs7d6aaUTasdfaDFS56as";

if (isset($_POST["method"])) {
    if (strtolower($_POST["method"]) === "save" && isset($_POST["hwid"]) && isset($_POST["newPass"]) && isset($_POST["permission"]) && isset($_POST["banreason"])) {
        $SET_HWID = $_POST["hwid"];
        $SET_PERMISSION = $_POST["permission"];
        $SET_BANNED = isset($_POST["bannedbox"]);
        $SET_BAN_REASON = $_POST["banreason"];
        $SET_PASSWORD = $_POST["newPass"];
        $HASHED_PASSWORD = strtoupper(hash('sha512', $PASSWORD_SALT.$SET_PASSWORD));

        $MODIFY_HWID = true;
        if ($SET_HWID === "" || $SET_HWID === $TARGET_DATA["hwid"]) {
            $MODIFY_HWID = false;
        }

        $MODIFY_PASS = true;
        if ($SET_PASSWORD === "" || $HASHED_PASSWORD === $TARGET_DATA["password"]) {
            $MODIFY_PASS = false;
        }

        $MODIFY_PERMS = true;
        if ($GLOBAL_PERMISSIONS[$TARGET_DATA["permission"]] == $SET_PERMISSION) {
            $MODIFY_PERMS = false;
        }

        $MODIFY_BANNED = true;
        if ($TARGET_DATA["banned"] === $SET_BANNED) {
            $MODIFY_BANNED = false;
        }

        $MODIFY_BAN_REASON = true;

        if ($MODIFY_BANNED) {
            $MODIFY_BAN_REASON = true;
        } else {
            if ($TARGET_DATA["banned"] && $TARGET_DATA["banreason"] == $SET_BAN_REASON) {
                $MODIFY_BAN_REASON = false;
            }
        }

        if ($SET_BANNED && $MODIFY_BAN_REASON && $SET_BAN_REASON === "") {
            $SET_BAN_REASON = "Violating our terms of service.";
        }

        if ($MODIFY_BANNED && !$SET_BANNED) {
            $SET_BAN_REASON = "";
        }

        /*$BULK_WRITE = new MongoDB\Driver\BulkWrite;
        $BULK_WRITE->update(
            ["user_id" => $TARGET_DATA["user_id"]],
            ['$set' => [ "password" => ($MODIFY_PASS ? $HASHED_PASSWORD : $TARGET_DATA["password"]), "hwid" => ($MODIFY_HWID ? $SET_HWID : $TARGET_DATA["hwid"]), "permission" => ($MODIFY_PERMS ? array_search($SET_PERMISSION, $GLOBAL_PERMISSIONS) : $TARGET_DATA["permission"]), "banned" => ($MODIFY_BANNED ? $SET_BANNED : $TARGET_DATA["banned"]), "banreason" => ($MODIFY_BAN_REASON ? $SET_BAN_REASON : $TARGET_DATA["banreason"]), "bannedby" => ($MODIFY_BANNED ? ($SET_BANNED ? $USERNAME : "") : $TARGET_DATA["bannedby"]), "bannedat" => ($MODIFY_BANNED ? ($SET_BANNED ? "".date("Y-m-d H:i:s") : "") : $TARGET_DATA["bannedat"]) ]],
            ['multi' => false, 'upsert' => false]
        );*/

        if ($MODIFY_PASS) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => $TARGET_DATA["user_id"]],
                ['$set' => [ "password" => $HASHED_PASSWORD]],
                ['multi' => false, 'upsert' => false]
            );
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        }
        if ($MODIFY_HWID) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => $TARGET_DATA["user_id"]],
                ['$set' => [ "hwid" => $SET_HWID]],
                ['multi' => false, 'upsert' => false]
            );
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        }
        if ($MODIFY_PERMS) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => $TARGET_DATA["user_id"]],
                ['$set' => [ "permission" => array_search($SET_PERMISSION, $GLOBAL_PERMISSIONS)]],
                ['multi' => false, 'upsert' => false]
            );
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        }
        if ($MODIFY_BANNED) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => $TARGET_DATA["user_id"]],
                ['$set' => ["banned" => $SET_BANNED, "bannedby" => ($SET_BANNED ? $USERNAME : ""), "bannedat" => ($SET_BANNED ? date("Y-m-d H:i:s") : "")]],
                ['multi' => false, 'upsert' => false]
            );
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        }
        if ($MODIFY_BAN_REASON) {
            $BULK_WRITE = new MongoDB\Driver\BulkWrite;
            $BULK_WRITE->update(
                ["user_id" => $TARGET_DATA["user_id"]],
                ['$set' => ["banreason" => $SET_BAN_REASON]],
                ['multi' => false, 'upsert' => false]
            );
            $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        }

        $OLD_BANNEDBY = $TARGET_DATA["bannedby"];
        $OLD_BANNEDAT = $TARGET_DATA["bannedat"];
        $OLD_PERM = $TARGET_DATA["permission"];
        $OLD_BANREASON = $TARGET_DATA["banreason"];

        $filter = ["user_id"=>$_POST["target"]];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
        $valid = false;
        foreach ($cursor as $document) {
            $TARGET_DATA = (array)$document;
        }

        if ($MODIFY_BANNED){
            $address="127.0.0.1";
            $port="666";
            $socketmessage = ["type"=>"userban","username"=>$TARGET_DATA["username"],"executor"=>$USERNAME,"banned"=>$SET_BANNED,"banreason"=>($SET_BANNED ? $TARGET_DATA["banreason"] : $OLD_BANREASON),"bannedat"=>($SET_BANNED ? $TARGET_DATA["bannedat"] : $OLD_BANNEDAT),"bannedby"=>($SET_BANNED ? $TARGET_DATA["bannedby"] : $OLD_BANNEDBY)];
            $msg=json_encode($socketmessage);
            $sock=socket_create(AF_INET,SOCK_STREAM,0);
            socket_connect($sock,$address,$port);
            socket_write($sock,$msg);
            socket_close($sock);
        }

        if ($MODIFY_PERMS){
            $address="127.0.0.1";
            $port="666";
            $socketmessage = ["type"=>"userperms","username"=>$TARGET_DATA["username"],"executor"=>$USERNAME,"before"=>$OLD_PERM,"after"=>$TARGET_DATA["permission"]];
            $msg=json_encode($socketmessage);
            $sock=socket_create(AF_INET,SOCK_STREAM,0);
            socket_connect($sock,$address,$port);
            socket_write($sock,$msg);
            socket_close($sock);
        }
    } else if (strtolower($_POST["method"]) === "grant" && isset($_POST["prod"])) {
        $TARGET_PRODUCT = $_POST["prod"];

        if ($TARGET_PRODUCT === "-") {
            header("location: index.php?page=admin");
            die();
        }

        $TARGET_PRODUCT_SPLIT = explode(" (", $TARGET_PRODUCT);
        $TARGET_PRODUCT_DISPLAYF = $TARGET_PRODUCT_SPLIT[0];
        $TARGET_PRODUCT_PRICEF = "(".$TARGET_PRODUCT_SPLIT[1];
        $TARGET_PRODUCT_DISPLAY = str_replace(array( ' ' ), '', $TARGET_PRODUCT_DISPLAYF);
        $TARGET_PRODUCT_PRICE = strtolower(str_replace(array( '(', ')', ' ' ), '', $TARGET_PRODUCT_PRICEF));
        $TARGET_PRODUCT_DISPLAY = str_replace(array('+'), 'plus', $TARGET_PRODUCT_DISPLAY);

        $PROC_DATA = [];

        $filter = ["fullname"=>"$TARGET_PRODUCT_DISPLAYF"];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
        foreach ($cursor as $document) {
            $PROC_DATA = (array)$document;
        }

        if (sizeof($PROC_DATA) == 0) {
            header("location: index.php?page=admin");
            die();
        }

        $CURRENT_PRODUCT_DATA = $PROC_DATA;
        $ORDER_ID = generateRandomString(32);

        $bulkWrite=new MongoDB\Driver\BulkWrite;
        $doc = ["username"=>$TARGET_DATA["username"],"transaction_id"=>"MANUAL-".$TARGET_DATA["username"],"at"=>"".date("Y-m-d H:i:s"),"orderid"=>"$ORDER_ID", "productid"=>"".$CURRENT_PRODUCT_DATA["id"], "productname"=>"".$CURRENT_PRODUCT_DATA["display"], "discordname"=>($TARGET_DATA["discord"] === "" ? "Unknown" : $TARGET_DATA["discord"]), "email"=>$TARGET_DATA["email"], "serverid" =>($CURRENT_PRODUCT_DATA["serverid"] ? "Contact a developer" : "NONE"), "status"=>"2"];
        $bulkWrite->insert($doc);
        $MONGO_MANAGER->executeBulkWrite("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $bulkWrite);

        $address="127.0.0.1";
        $port="666";
        $socketmessage = ["type"=>"purchase","discordname"=>($TARGET_DATA["discord"] === "" ? "Unknown" : $TARGET_DATA["discord"]),"productname"=>$CURRENT_PRODUCT_DATA["display"],"productid"=>$CURRENT_PRODUCT_DATA["id"],"money"=>$CURRENT_PRODUCT_DATA["total"],"email"=>$TARGET_DATA["email"],"orderid"=>$ORDER_ID,"manual"=>true];
        $msg=json_encode($socketmessage);
        $sock=socket_create(AF_INET,SOCK_STREAM,0);
        socket_connect($sock,$address,$port);
        socket_write($sock,$msg);
        socket_close($sock);
    }

    header("location: index.php?page=admin");
    die();
    
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>

<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        <?php echo $TARGET_DATA["username"]; ?>
        </div>
        <div class="card-body d-flex flex-column">
            <form method="post" action="index.php">
                <input type="hidden" name="page" value="user">
                <input type="hidden" name="target" value="<?php echo $TARGET_DATA["user_id"]; ?>">
                <input type="hidden" name="method" value="save">

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">@</span>
                    </div>
                    <input type="text" class="form-control" disabled placeholder="<?php echo $TARGET_DATA["username"]; ?>" aria-label="Username">
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="newPass" id="newPass" class="form-control" placeholder="**************" aria-label="Password">
                    <div class="input-group-append">
                        <span class="input-group-text">Password</span>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">⚩</span>
                    </div>
                    <select id="curr-perms" name="permission" class="custom-select">
                        <option value="0">None</option>
                        <option value="1">Media</option>
                        <option value="2">Staff</option>
                        <option value="3">Admin</option>
                        <option value="4">Developer</option>
                        <option value="5">Owner</option>
                    </select>
                </div>
                <div class="input-group mb-3">
                    <?php

                    $splitted = explode("@", $TARGET_DATA["email"]);

                    $EMAIL_FIRST_PART = $splitted[0];
                    $EMAIL_SECOND_PART = "@".$splitted[1];

                    ?>
                    <input type="text" class="form-control" disabled placeholder="<?php echo $EMAIL_FIRST_PART; ?>" aria-label="Email">
                    <div class="input-group-append">
                        <span class="input-group-text"><?php echo $EMAIL_SECOND_PART; ?></span>
                    </div>
                </div>
                <?php
                $HWID_N = "Not set";
                $HWID = $TARGET_DATA["hwid"];
                if ($HWID !== "NONE" && $HWID !== "") {
                    $HWID_N = $HWID;
                }
                ?>
                <div class="input-group mb-3">
                    <input type="text" name="hwid" id="hwid" class="form-control" placeholder="<?php echo $HWID_N; ?>" aria-label="Hardware ID">
                    <div class="input-group-append">
                        <span class="input-group-text">Hardware ID</span>
                    </div>
                </div>
                <div style="text-align: left" class="form-check">
                    <input class="form-check-input" name="bannedbox" type="checkbox" value="bannedbox" id="banned-check">
                    <label class="form-check-label" for="defaultCheck1">
                        Banned
                    </label>
                </div>

                <div id="ban-data" style="display:none">
                    <br>
                    <div class="input-group mb-3">
                        <input type="text" id="ban-reason" name="banreason" class="form-control" placeholder="<?php if ($TARGET_DATA["banned"]) { echo $TARGET_DATA["banreason"]; } else { echo "Not banned"; } ?>" aria-label="Ban Reason">
                        <div class="input-group-append">
                            <span class="input-group-text">Ban Reason</span>
                        </div>
                    </div>

                    <div class="input-group mb-3">
                        <input type="text" id="ban-executor" disabled class="form-control" placeholder="<?php if ($TARGET_DATA["banned"]) { echo $TARGET_DATA["bannedby"]; } else { echo "Not banned"; } ?>" aria-label="Banned By">
                        <div class="input-group-append">
                            <span class="input-group-text">Banned By</span>
                        </div>
                    </div>

                    <div class="input-group mb-3">
                        <input type="text" id="ban-time" disabled class="form-control" placeholder="<?php if ($TARGET_DATA["banned"]) { echo $TARGET_DATA["bannedat"]; } else { echo "Not banned"; } ?>" aria-label="Banned At">
                        <div class="input-group-append">
                            <span class="input-group-text">Banned At</span>
                        </div>
                    </div>
                </div>

                <button type="submit" disabled id="save-changes" class="mt-auto btn btn-primary datacardbutton">Save Changes</button>

            </form>
        </div>
    </div>
</div>

<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        Grant Product
        </div>
        <div class="card-body">
        <form action="/index.php" method="post">
            <input type="hidden" name="page" value="user" />
            <input type="hidden" name="target" value="<?php echo $TARGET_DATA["user_id"]; ?>">
            <input type="hidden" name="method" value="grant">
            <div class="form-group">
                <label for="prod">Select product</label>
                <select class="form-control" name="prod" id="prod">
                    <option>-</option>
                    <?php

                    $filter = [];
                    $options = [];
                    $query = new MongoDB\Driver\Query($filter, $options);
                    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
                    foreach ($cursor as $document) {
                        $process = (array)$document;
                        if ($process["enabled"]) {
                            ?>
                            <option><?php echo $process["fullname"]." (".$process["fmoney"].")"; ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary datacardbutton">Complete</button>
        </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#curr-perms option[value=<?php echo $GLOBAL_PERMISSIONS[$TARGET_DATA["permission"]]; ?>]").attr("selected", "selected");
        <?php
        if ($STAFF_LEVEL < $FULLACCESS_PERMISSION_LEVEL) {
            ?>
                $("#curr-perms option").each(function() {
                    var currentItem = parseInt($(this).attr("value"), 10);
                    if (currentItem > <?php echo $STAFF_LEVEL; ?>) {
                        $(this).remove();
                    }
                });
            <?php
        }
        ?>

        $("#curr-perms").change(function() {
            $('#save-changes').prop("disabled", false);
        });

        $("#hwid").keyup(function(){
            $('#save-changes').prop("disabled", false);
        });

        $("#newPass").keyup(function(){
            $('#save-changes').prop("disabled", false);
        });

        $('#banned-check').change(function(){
            $('#save-changes').prop("disabled", false);
            if(this.checked)
                $('#ban-data').fadeIn();
            else
                $('#ban-data').fadeOut();
        });

        $('#ban-reason').keyup(function() {
            $('#save-changes').prop("disabled", false);
        });

        setTimeout(function() {
            if(<?php echo $TARGET_DATA["banned"] ? "true" : "false"; ?>) {
                $('#banned-check').attr('checked', true);
                $('#ban-data').fadeIn();
            }
        },50);

        if ($('#banned-check').checked) {
            $('#ban-data').fadeIn();
        }
    });
</script>