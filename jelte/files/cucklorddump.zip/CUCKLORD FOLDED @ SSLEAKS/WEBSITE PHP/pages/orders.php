<?php

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if ($STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

if (isset($_GET["action"]) && isset($_GET["usr"])) {

    $TARGET_USER = $_GET["usr"];
    $TARGET_PRODUCT = $_GET["prod"];

    if ($TARGET_USER === "-" || $TARGET_PRODUCT === "-") {
        header("location: index.php?page=orders");
        die();
    }

    $TARGET_USER_SPLIT = explode(" ", $TARGET_USER);
    $TARGET_PRODUCT_SPLIT = explode(" ", $TARGET_PRODUCT);

    $TARGET_USER_NAME = $TARGET_USER_SPLIT[0];
    $TARGET_USER_EMAIL = $TARGET_USER_SPLIT[1];
    $TARGET_USER_EMAIL = str_replace(array( '(', ')', ' ' ), '', $TARGET_USER_EMAIL);
    $TARGET_USER_NAME = str_replace(array( ' ' ), '', $TARGET_USER_NAME);

    $TARGET_PRODUCT_DISPLAYF = $TARGET_PRODUCT_SPLIT[0];
    $TARGET_PRODUCT_PRICEF = $TARGET_PRODUCT_SPLIT[1];
    $TARGET_PRODUCT_DISPLAY = strtolower(str_replace(array( ' ' ), '', $TARGET_PRODUCT_DISPLAYF));
    $TARGET_PRODUCT_PRICE = strtolower(str_replace(array( '(', ')', ' ' ), '', $TARGET_PRODUCT_PRICEF));
    $TARGET_PRODUCT_DISPLAY = str_replace(array('+'), 'plus', $TARGET_PRODUCT_DISPLAY);

    $PROC_DATA = [];
    $USR_DATA = [];

    $filter = ["fmoney"=>"$TARGET_PRODUCT_PRICE"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
    foreach ($cursor as $document) {
        $PROC_DATA = (array)$document;
    }

    $filter = ["username"=>"$TARGET_USER_NAME", "email"=>"$TARGET_USER_EMAIL"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $USR_DATA = (array)$document;
    }

    if (sizeof($PROC_DATA) == 0) {
        $_SESSION["MESSAGE_ID"] = 570;
        $_SESSION["ORDER_MSG_H"] = true;
        header("location: index.php?page=orders&invalid_product");
        die();
    }
    if (sizeof($USR_DATA) == 0) {
        $_SESSION["MESSAGE_ID"] = 570;
        $_SESSION["ORDER_MSG_H"] = true;
        header("location: index.php?page=orders&invalid_user");
        die();
    }

    $CURRENT_PRODUCT_DATA = $PROC_DATA;
    $CURRENT_USER_DATA = $USR_DATA;

    $ORDER_ID = generateRandomString(32);


    $bulkWrite=new MongoDB\Driver\BulkWrite;
    $doc = ["username"=>"$TARGET_USER_NAME","transaction_id"=>"MANUAL-".$TARGET_USER_NAME,"at"=>"".date("Y-m-d H:i:s"),"orderid"=>"$ORDER_ID", "productid"=>"".$CURRENT_PRODUCT_DATA["id"], "productname"=>"".$CURRENT_PRODUCT_DATA["display"], "discordname"=>($USR_DATA["discord"] === "" ? "Unknown" : $USR_DATA["discord"]), "email"=>"$TARGET_USER_EMAIL", "serverid" =>($CURRENT_PRODUCT_DATA["serverid"] ? "Contact a developer" : "NONE"), "status"=>"2"];
    $bulkWrite->insert($doc);
    $MONGO_MANAGER->executeBulkWrite("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $bulkWrite);

    $address="127.0.0.1";
    $port="666";
    $socketmessage = ["type"=>"purchase","discordname"=>($USR_DATA["discord"] === "" ? "Unknown" : $USR_DATA["discord"]),"productname"=>$CURRENT_PRODUCT_DATA["display"],"productid"=>$CURRENT_PRODUCT_DATA["id"],"money"=>$CURRENT_PRODUCT_DATA["total"],"email"=>$TARGET_USER_EMAIL,"orderid"=>$ORDER_ID,"manual"=>true];
    $msg=json_encode($socketmessage);
    $sock=socket_create(AF_INET,SOCK_STREAM,0);
    socket_connect($sock,$address,$port);
    socket_write($sock,$msg);
    socket_close($sock);
    
    $_SESSION["MESSAGE_ID"] = 580;
    $_SESSION["ORDER_MSG_H"] = true;

    header("location: index.php?page=orders");
}
?>
<style type="text/css">
    .datacard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .datacardname {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .datacardbutton {
        background-color: #515172;
        border-color: #515172;
    }
    .datacardbutton:hover, .datacardbutton:focus, .datacardbutton:active, .datacardbutton.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .details-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .details-list-group {
        list-style: none;
    }

    .details {
        font-size: 22.5px;
    }

    .datarow {
        display: flex;
        justify-content: center;
        align-self: center;
    }

    .purchaseb {
        margin-left: 1em;
    }

    .table>tbody>tr>th {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr>td {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr.no-border>td {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr.no-border>th {
        border-top: none;
        border-bottom: none;
    }

    .rightstuff {
        text-align: right;
        margin-right: 1em;
    }

    .scrollabletableheader {
        display: block;
    }

    .scrollabletablebody {
        height:250px;
        overflow:auto;
        overflow-x:hidden;
        display:block;
        width:100%;
    }

    .scrollabletabletr {
        display:table;
        width:100%;
        table-layout:fixed;
    }
</style>
<?php

if (isset($_SESSION["MESSAGE_ID"]) && !isset($_SESSION["ORDER_MSG_H"])) {
    $MID = $_SESSION["MESSAGE_ID"];
    if ($MID == 580) {
        ?>
        <div class="alert alert-success" role="alert">
            <strong>Success!</strong> This user has received a purchase.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == 570) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Failed!</strong> Failed to grant order to the target user.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
}

if (isset($_SESSION["ORDER_MSG_H"])) {
    unset($_SESSION["ORDER_MSG_H"]);
}

?>
<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        Grant Order
        </div>
        <div class="card-body">
        <form action="/index.php" method="get">
            <input type="hidden" name="page" value="orders" />
            <input type="hidden" name="action" value="complete" />
            <div class="form-group">
                <label for="usr">Select target user</label>
                <select class="form-control" name="usr" id="usr">
                    <option>-</option>
                    <?php

                    $filter = [];
                    $options = [];
                    $query = new MongoDB\Driver\Query($filter, $options);
                    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
                    foreach ($cursor as $document) {
                        $process = (array)$document;
                        ?>
                        <option><?php echo $process["username"]." (".$process["email"].")"; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="prod">Select target product</label>
                <select class="form-control" name="prod" id="prod">
                    <option>-</option>
                    <?php

                    $filter = [];
                    $options = [];
                    $query = new MongoDB\Driver\Query($filter, $options);
                    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_PRODUCTS_COLL", $query);
                    foreach ($cursor as $document) {
                        $process = (array)$document;
                        if ($process["enabled"]) {
                            ?>
                            <option><?php echo $process["fullname"]." (".$process["fmoney"].")"; ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary datacardbutton">Complete</button>
        </form>
        </div>
    </div>
</div>