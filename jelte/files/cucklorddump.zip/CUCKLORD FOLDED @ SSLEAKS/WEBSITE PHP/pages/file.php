<?php
if (!$LOGGED_IN) {
    header("location: index.php?page=home");
    exit;
}

if (!$OWNS_CUCKLORD && !$OWNS_CLICKER) {
    if ($STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) {
        header("location: index.php?page=home");
        exit;
    }
}

if (!isset($_GET["type"])) {
    header("location: index.php?page=home");
    exit;
}

if (strcmp($_GET["type"], "cucklord") === 0) {
    if ($OWNS_CUCKLORD || $STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL -1) {
        $USER_DIR = "/home/users/$USERNAME/";
        $USER_FILE = $USER_DIR."Cucklord.exe";
    
        if (!file_exists($USER_DIR)) {
            mkdir($USER_DIR, 0777, true);
        }
    
        if (file_exists($USER_FILE)) {
            unlink($USER_FILE);
        }
    
        $FILENAME = generateRandomString(8).".exe";
        $file = "/home/master.exe";
        chmod($file, 0777);
        $newfile = $USER_FILE;
        copy($file,$newfile);
    
        chmod($USER_FILE, 0777);
    
        $FILEWRITE = fopen($USER_FILE, "a");
    
        if($FILEWRITE) {
    
            fwrite($FILEWRITE, "\nUniqueID: ".$USERNAME);
            fclose($FILEWRITE);
    
            $type = filetype($USER_FILE);
            $today = date("F j, Y, g:i a");
            $time = time();
            header("Content-type: $type");
            header("Content-Disposition: attachment;filename=$FILENAME");
            header("Content-Transfer-Encoding: binary"); 
            header('Pragma: no-cache'); 
            header('Expires: 0');
            set_time_limit(0);
            readfile($USER_FILE);
        } else {
            echo "failed to write ur file";
        }
    } else {
        header("location: index.php?page=home");
        exit;
    }
} else if (strcmp($_GET["type"], "clicker") === 0) {
    if ($OWNS_CLICKER || $OWNS_CUCKLORD || $STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL -1) {
        $USER_FILE = "/home/CuckLauncher.exe";
        $FILENAME = generateRandomString(8).".exe";
    
        if(file_exists($USER_FILE)) {
            $type = filetype($USER_FILE);
            $today = date("F j, Y, g:i a");
            $time = time();
            header("Content-type: $type");
            header("Content-Disposition: attachment;filename=$FILENAME");
            header("Content-Transfer-Encoding: binary"); 
            header('Pragma: no-cache'); 
            header('Expires: 0');
            set_time_limit(0);
            readfile($USER_FILE);
        } else {
            echo "file doesnt exist men";
        }
    } else {
        header("location: index.php?page=home");
        exit;
    }
} else {
    header("location: index.php?page=home");
    exit;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>