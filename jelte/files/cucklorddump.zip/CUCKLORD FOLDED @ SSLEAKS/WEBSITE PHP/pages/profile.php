<?php

$PAGE = 0;

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
}

if (isset($_GET["action"]) && isset($_GET["d"]) && isset($_GET["h"])) {
    $DN = $_GET["d"];
    $HN = $_GET["h"];

    if ($DN === "") {
        $DN = $DISCORD;
    }

    if ($HN === "") {
        $HN = $HWID;
    }

    if (strlen($HN) !== 32) {
        $_SESSION["uranigger"] = true;
        header("location: index.php?page=profile".$USR_REFERREAL);
        return;
    }

    $filter = ["username"=>"$USERNAME"];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    foreach ($cursor as $document) {
        $process = (array)$document;
        
        $BULK_WRITE = new MongoDB\Driver\BulkWrite;
        $BULK_WRITE->update(
            ["username" => $USERNAME],
            ['$set' => ['discord' => $DN,'hwid' => $HN]],
            ['multi' => false, 'upsert' => false]
        );

        $UPDATE_RESULT = $MONGO_MANAGER->executeBulkWrite("$MONGO_DATABASE.$MONGO_USERS_COLL", $BULK_WRITE);
        header("location: index.php?page=profile".$USR_REFERREAL);
    }
}

?>
<style type="text/css">
    .datacard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .datacardname {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .datacardbutton {
        background-color: #515172;
        border-color: #515172;
    }
    .datacardbutton:hover, .datacardbutton:focus, .datacardbutton:active, .datacardbutton.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .details-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .details-list-group {
        list-style: none;
    }

    .details {
        font-size: 22.5px;
    }

    .datarow {
        display: flex;
        justify-content: center;
        align-self: center;
    }

    .purchaseb {
        margin-left: 1em;
    }

    .table>tbody>tr>th {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr>td {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr.no-border>td {
        border-top: none;
        border-bottom: none;
    }

    .table>tbody>tr.no-border>th {
        border-top: none;
        border-bottom: none;
    }

    .rightstuff {
        text-align: right;
        margin-right: 1em;
    }

    
    .scrollabletableheader {
        display: block;
    }

    .scrollabletablebody {
        height:250px;
        overflow:auto;
        overflow-x:hidden;
        display:block;
        width:100%;
    }

    .scrollabletabletr {
        display:table;
        width:100%;
        table-layout:fixed;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<?php

if (isset($_SESSION["uranigger"])) {
    unset($_SESSION["uranigger"]);
    ?>
    <script type="text/javascript">
    Swal.fire({
        title: '<strong>Error</strong>',
        type: 'error',
        html:
            'This HWID is invalid. Please use the tool in our discord. To join click on the <strong>link in the navbar</strong> or <a href="https://discord.gg/tCnBDE7">click here</a>.',
        showCloseButton: false,
        showCancelButton: false,
        focusConfirm: false,
        confirmButtonText:
            'OK',
        confirmButtonAriaLabel: 'OK',
    });
    </script>
    <?php
}

?>

<?php

if($PAGE == 0) {

    $filter = ["username"=>"$USERNAME"];
    $options = [];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $query);
    $c = 0;
    foreach ($cursor as $document) {
        $process = (array)$document;
        $c++;
        ?>
            <div class="modal fade" id="modal<?php echo $c; ?>">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo $process["productname"]; ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="card-text">Purchased at: <?php echo $process["at"]; ?></p>
                        <p class="card-text">Purchased for: <?php echo $process["email"]; ?></p>
                        <p class="card-text">Discord name: <?php echo $process["discordname"]; ?></p>
                        <p class="card-text">Order ID: <?php echo $process["orderid"]; ?></p>
                        <p class="card-text">Transaction ID: <?php echo $process["transaction_id"]; ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary datacardbutton purchaseb" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
            </div>
        <?php
    }

    ?>
        <div class="row datarow">
            <div class="card datacard text-center" style="margin-top:5rem; width: 30rem;">
                <div class="card-header datacardname text-white">
                Profile Info
                </div>
                <div class="card-body">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">@</span>
                        </div>
                        <input type="text" class="form-control" disabled placeholder="<?php echo $USERNAME; ?>" aria-label="Username" aria-describedby="basic-addon1">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">⚩</span>
                        </div>
                        <input type="text" class="form-control" disabled placeholder="<?php echo $PERMISSION; ?>" aria-label="Username" aria-describedby="basic-addon1">
                    </div>
                    <div class="input-group mb-3">
                    <?php

                    $splitted = explode("@", $EMAIL);

                    $EMAIL_FIRST_PART = $splitted[0];
                    $EMAIL_SECOND_PART = "@".$splitted[1];

                    ?>
                        <input type="text" class="form-control" disabled placeholder="<?php echo $EMAIL_FIRST_PART; ?>" aria-label="Email" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2"><?php echo $EMAIL_SECOND_PART; ?></span>
                        </div>
                    </div>
                    <form action="/index.php" method="get">
                        <input type="hidden" name="page" value="profile" />
                        <input type="hidden" name="action" value="save" />
                        <?php
                        $DISCORD_N = "Not set";
                        if (strpos($DISCORD, "#") !== false){
                            $DISCORD_N = $DISCORD;
                        }
                        $HWID_N = "Not set";
                        if ($HWID !== "NONE" && $HWID !== "") {
                            $HWID_N = $HWID;
                        }
                        ?>
                        <div class="input-group mb-3">
                            <input type="text" name="d" class="form-control" placeholder="<?php echo $DISCORD_N; ?>" aria-label="Discord" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">Discord Name</span>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <input type="text" name="h" class="form-control" placeholder="<?php echo $HWID_N; ?>" <?php if ($HWID !== "" && $HWID !== "NONE") echo "disabled"; ?> aria-label="Hardware ID" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">Hardware ID</span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary datacardbutton">Save</button>
                        <button type="button" id="changePassButton" class="btn btn-primary datacardbutton">Change Password</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row datarow">


            <div class="card datacard text-center" style="margin-top:5rem; width: 50rem;">
                <div class="card-header datacardname text-white">
                Recent Purchases
                </div>
                <div class="card-body">
                    <table class="table noborder">
                        <thead class="scrollabletableheader">
                            <tr>
                                <th class="d-none" scope="col">Date</th>
                                <th class="d-none" scope="col">Product Name</th>
                                <th class="d-none" scope="col" style="padding-right: 1em;">Jump</th>
                            </tr>
                        </thead>
                        <tbody id="recentpurchasesscrollabletablebody" class="scrollabletablebody">
                            <?php

                            $filter = ["username"=>"$USERNAME"];
                            $options = [];
                            $query = new MongoDB\Driver\Query($filter, $options);
                            $cursor = $MONGO_MANAGER->executeQuery("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $query);
                            $i = 0;
                            foreach ($cursor as $document) {
                                $i++;
                                $process = (array)$document;
                                ?>
                                <tr class="scrollabletabletr">
                                    <td class="noborder"><?php echo $process['at']; ?></td>
                                    <td class="noborder"><?php echo $process['productname']; ?></td>
                                    <td class="noborder rightstuff">
                                        <button type="button" class="btn btn-primary datacardbutton purchasheb" data-toggle="modal" data-target="#modal<?php echo $i; ?>">View Purchase</button>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                <?php
                if ($i == 0) {
                ?>
                    <p class="card-text">No recent purchases found.</p>
                    <script type="text/javascript">
                        $("#recentpurchasesscrollabletablebody").removeClass("scrollabletablebody");
                    </script>
                <?php
                }
                ?>
                </div>
            </div>
        </div>
    <?php
}

?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
    $("#changePassButton").click(function() {
            Swal.fire({
            title: '<strong>Error</strong>',
            type: 'error',
            html:
                'Password changes have been temporarily disabled due to server side issues. If you would like to change your password in the meantime please create a ticket in our discord.',
            showCloseButton: false,
            showCancelButton: false,
            focusConfirm: false,
            confirmButtonText:
                'OK',
            confirmButtonAriaLabel: 'OK',
        });
        /*$.ajax({
            url: "https://cucklord.pro/vcode.php?yes=new",
            type: 'GET',
            dataType: 'json',
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 406) {
                    toastr.error("Please wait an hour between password changes.");
                    return;
                } else if (xhr.status == 200) {
                    var steps = [
                        {
                            type: 'question',
                            title: 'Verification',
                            text: 'We sent you a code to your email. Please enter it below:',
                            input: 'text',
                            inputPlaceholder: 'Verification Code'
                        },
                        {
                            type: 'question',
                            title: 'New Password',
                            text: 'Please enter your new password below:',
                            input: 'password',
                            inputPlaceholder: 'New Password'
                        }
                    ];

                    Swal.mixin({
                        input: 'text',
                        confirmButtonText: 'Continue',
                        showCancelButton: false,
                        animation: true,
                        progressSteps: ['1', '2'],
                        preConfirm: function(value) {
                            if(Swal.getQueueStep() == 0) {
                                return fetch(`https://cucklord.pro/vcode.php?yes=yoot&yeehaw=${value}`)
                                    .then(response => {
                                        if (!response.ok) {
                                            throw new Error("Invalid verification code");
                                        }
                                        return value;
                                    })
                                    .catch(error => {
                                        Swal.showValidationMessage(
                                        `${error}`
                                        )
                                    });
                            }
                        }
                    }).queue(steps).then(function(result) {
                        if (result && result.value) {
                            $.ajax({
                                url: "https://cucklord.pro/changepass.php?new=" + result.value[1] + "&code=" + result.value[0],
                                type: 'GET',
                                dataType: 'json'
                            });

                            Swal.fire({
                                title: '<strong>Completed</strong>',
                                type: 'success',
                                html: 'You have successfully changed your password.',
                                showCloseButton: false,
                                showCancelButton: false,
                                focusConfirm: true,
                                confirmButtonText: 'OK',
                                confirmButtonAriaLabel: 'OK',
                            });

                            setTimeout(function() {
                                window.location.href = "https://cucklord.pro/index.php?page=logout";
                            }, 5000);
                        } else {
                            toastr.info("You have cancelled your password change.");
                        }
                    });
                }
            }
        });*/
    });
</script>