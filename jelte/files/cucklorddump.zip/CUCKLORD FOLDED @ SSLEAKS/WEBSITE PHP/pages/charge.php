<?php

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
}

?>

<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 30rem;">
        <div class="card-header datacardname text-white">
        Charge balance
        </div>
        <div class="card-body">
            <?php if (!$TOPUPS_DISABLED) { ?>
                <form action="/ipn.php" method="post">
                    <input type="hidden" name="gateway" value="charge">
                    <input type="hidden" name="item_number" value="0002">
                    <input type="hidden" name="user_secret" value="<?php echo $USER_TOKEN; ?>">
                    <div class="input-group mb-3">
                        <input type="number" step="0.01" min="1" name="amount" class="form-control" placeholder="Amount - Minimum 1$" aria-label="Amount" aria-describedby="amount">
                    </div>
                    <button id="charge" type="submit" class="btn btn-primary datacardbutton">Continue <small>with PayPal</small></button>
                </form>
            <?php } else { ?>
                <div class="alert alert-danger" role="alert">
                    YOU DO NOT HAVE PERMISSION TO VIEW THIS CONTENT AT THIS TIME.
                </div>
            <?php } ?>
        </div>
    </div>
</div>