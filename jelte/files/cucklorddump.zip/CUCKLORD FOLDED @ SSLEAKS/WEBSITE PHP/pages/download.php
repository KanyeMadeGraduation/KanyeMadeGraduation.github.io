<?php
if (!$LOGGED_IN) {
    header("location: index.php?page=home");
}

if (!$OWNS_CUCKLORD && !$OWNS_CLICKER) {
    if ($STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) {
       
        header("location: index.php?page=home");
     
    }
}

if (isset($_SESSION["MESSAGE_ID"])) {
    $MID = $_SESSION["MESSAGE_ID"];
    if ($MID == 850) {
        ?>
        <div class="alert alert-success" role="alert">
            <strong>Success!</strong> Your download has started.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
    if ($MID == 851) {
        ?>
        <div class="alert alert-danger" role="alert">
            <strong>Failed!</strong> A server side problem has occured. Please try again later.
        </div>
        <?php
        unset($_SESSION["MESSAGE_ID"]);
    }
}

?>
<div class="row datarow">
    <?php
    if ($OWNS_CLICKER || $OWNS_CUCKLORD || $STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL -1) {
        ?>
        <div class="card datacard text-center" style="margin-top:5rem; width: 30rem;">
            <div class="card-header datacardname text-white">
            Download Clicker
            </div>
            <div class="card-body">
                <p class="card-text">Please click the button below to download the latest version.</p>
                <a id="dlbutton" href="<?php if (strcasecmp($HWID, "NONE") == 0 || strcasecmp($HWID, "") == 0) { echo '#'; } else { echo '?page=file&type=clicker'; } ?>" class="btn btn-primary datacardbutton" <?php if (!strcasecmp($HWID, "NONE") == 0 && !strcasecmp($HWID, "") == 0) { echo 'target="_blank"'; } ?>>Download</a>
            </div>
        </div>
        <?php
    }
    if ($OWNS_CUCKLORD || $STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL -1) {
        ?>
        <div class="card datacard text-center" style="margin-top:5rem; width: 30rem;">
            <div class="card-header datacardname text-white">
            Download Cucklord
            </div>
            <div class="card-body">
                <p class="card-text">Please click the button below to download the latest version.</p>
                <a id="dlbutton" href="<?php if (strcasecmp($HWID, "NONE") == 0 || strcasecmp($HWID, "") == 0) { echo '#'; } else { echo '?page=file&type=cucklord'; } ?>" class="btn btn-primary datacardbutton" <?php if (!strcasecmp($HWID, "NONE") == 0 && !strcasecmp($HWID, "") == 0) { echo 'target="_blank"'; } ?>>Download</a>
            </div>
        </div>
        <?php
    }
    ?>
</div>

<?php

if (strcasecmp($HWID, "NONE") == 0 || strcasecmp($HWID, "") == 0) {
    ?>
        <script type="text/javascript">
            $("#dlbutton").click(() => {
                toastr.error("You have to set your HWID to download.");
                return false;
            });
        </script>
    <?php
}

?>