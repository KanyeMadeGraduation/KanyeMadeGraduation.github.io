<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        FAQ
        </div>
        <div class="card-body text-left">
            <ol>
                <li>Im gay how fix</li>
            </ol>
        </div>
    </div>
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        TOS
        </div>
        <div class="card-body text-left">
            <ol>
                <li>no charge backs or gay</li>
            </ol>
        </div>
    </div>
</div>