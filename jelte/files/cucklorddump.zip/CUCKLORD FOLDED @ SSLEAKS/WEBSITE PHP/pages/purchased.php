<?php

require "config.php";
if (!$LOGGED_IN) {
    header("location: index.php?page=home");
}

?>
<style type="text/css">
    .productcard {
        border-color: #515172;
        border-width: 1px;
        margin-left: 1rem;
    }
    .productname {
        background-color: #515172;
        font-size: 25px;
        text-transform: uppercase;
    }
    .continue {
        background-color: #515172;
        border-color: #515172;
    }
    .continue:disabled {
        background-color: #515172;
        border-color: #515172;
    }
    .continue:hover, .continue:focus, .continue:active, .continue.active {
        background-color: #313145;
        border-color: #313145;
    }
    hr{
        border-color: #515172;
        background-color: #515172;
        color: #515172;
    }
    
    .cost {
        font-size: 25px;
    }

    .timestamp {
        font-size: 25px;
    }

    .product-list-group li::before {
        content: "\2022";
        color: #515172;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    }

    .product-list-group {
        list-style: none;
    }

    .productdet {
        font-size: 22.5px;
    }

    .productsrow {
        display: flex;
        justify-content: center;
        align-self: center;
    }
</style>
<div class="row productsrow">
    <div class="card productcard text-center" style="margin-top:5rem; width: 25rem;">
        <div class="card-header productname text-white">
        Order fulfilled
        </div>
        <div class="card-body">
            <p class="card-text cost">Thank you for purchasing.</p>
            <p class="card-text">It may take a minute for your product to arrive. You may view your purchase details on your profile page.</p>
            <br>
            <form action="/index.php">
                <input type="hidden" name="page" value="profile" />
                <button type="submit" class="btn btn-primary continue">Go to Profile</button>
            </form>
        </div>
    </div>
</div>