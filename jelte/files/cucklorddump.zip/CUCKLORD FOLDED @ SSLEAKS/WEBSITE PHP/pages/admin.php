<?php

if (!$LOGGED_IN) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

if ($STAFF_LEVEL < $ADMIN_PERMISSION_LEVEL) {
    header("location: index.php?page=home".$REFERREAL_PART);
    die();
}

$TARDS = [];

$filter = [];
$options = [];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
foreach ($cursor as $document) {
    $process = (array)$document;
    array_push($TARDS, $process);
}

?>

<style>
.counter{
  padding:8px; 
  color:#aaa;
}
</style>

<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
        Users (<?php echo sizeof($TARDS); ?>)
        </div>
        <div class="card-body">
                <div class="form-group pull-right">
            <input type="text" class="search form-control" placeholder="Search">
        </div>
        <span class="counter pull-right"></span>
        <table class="men table noborder">
            <thead class="scrollabletableheader">
                <tr>
                    <th class="d-none" scope="col">Username</th>
                    <th class="d-none" scope="col">Permission</th>
                    <th class="d-none" scope="col" style="padding-right: 1em;">Registered at</th>
                    <th class="d-none" scope="col" style="padding-right: 1em;">Quick Action</th>
                </tr>
                <tr style="display:none" class="warning no-result">
                    <td colspan="4"><i class="fa fa-warning"></i> No result</td>
                </tr>
            </thead>
            <tbody class="scrollabletablebody">
            <?php

            foreach ($TARDS as $document) {
                $process = (array)$document;
                ?>
                <tr class="scrollabletabletr">
                    <td class="niggername noborder"><?php echo $process['username']; ?></td>
                    <td class="noborder"><?php echo $process['permission']; ?></td>
                    <td class="noborder rightstuff"><?php echo $process['at']; ?></td>
                    <td class="noborder rightstuff">
                        <?php
                        if ($GLOBAL_PERMISSIONS[$process["permission"]] >= $STAFF_LEVEL && $STAFF_LEVEL < $FULLACCESS_PERMISSION_LEVEL && (int)$process["user_id"] !== $ACCOUNT_ID) {
                            ?>
                            <button type="submit" class="btn btn-primary datacardbutton invalid-perms"><i class="fa fa-info-circle"></i></button>
                            <?php
                        } else {
                            ?>
                            <form method="post" action="index.php">
                                <input type="hidden" name="page" value="user">
                                <input type="hidden" name="target" value="<?php echo $process["user_id"]; ?>">
                                <button type="submit" class="btn btn-primary datacardbutton"><i class="fa fa-info-circle"></i></button>
                            </form>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        </div>
    </div>
    <div class="card datacard text-center" style="margin-top:5rem; width: 40rem;">
        <div class="card-header datacardname text-white">
            Refferal Codes
        </div>
        <div class="card-body">
        <table class="table noborder">
            <thead class="scrollabletableheader">
                <tr>
                    <th class="d-none" scope="col">Code</th>
                    <th class="d-none" scope="col">Code Username</th>
                    <th class="d-none" scope="col">Discount percent</th>
                    <th class="d-none" scope="col" style="padding-right: 1em;">Uses</th>
                </tr>
            </thead>
            <tbody id="referrealsscrollabletablebody" class="scrollabletablebody">
            <?php

            $filter = [];
            $options = [];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$REFERREALS_COLL", $query);

            $VALID_STUFF = [];
            $NIGGA = [];
            $YOINK = [];

            foreach ($cursor as $document) {
                $process = (array)$document;
                array_push($VALID_STUFF, $process["code"]);
                array_push($NIGGA, ["code" => $process["code"], "user" => $process["user"], "discount" => $process["discount"]]);
                $YOINK[$process["code"]] = 0;
            }

            $filter = [];
            $options = [];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$SIMPLE_PURCHASES_COLL", $query);

            foreach ($cursor as $document) {
                $process = (array)$document;
                if (isset($process["referreal"])) {
                    if (in_array($process["referreal"], $VALID_STUFF)) {
                        $YOINK[$process["referreal"]] += 1;
                    }
                }
                
            }

            foreach($NIGGA as $stufflol) {
                ?>
                <tr class="scrollabletabletr">
                    <td class="noborder"><?php echo $stufflol['code']; ?></td>
                    <td class="noborder"><?php echo $stufflol['user']; ?></td>
                    <td class="noborder"><?php echo $stufflol['discount']."%"; ?></td>
                    <td class="noborder rightstuff"><?php echo $YOINK[$stufflol["code"]]; ?></td>
                </tr>
                <?php
            }

            ?>
            </tbody>
        </table>
        <?php
        if (sizeof($NIGGA) == 0) {
            ?>
            <p class="card-text">No referreal codes found.</p>
            <script type="text/javascript">
                $("#referrealsscrollabletablebody").removeClass("scrollabletablebody");
            </script>
            <?php
        }
        ?>
        </div>
    </div>
</div>
<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 65rem;">
        <div class="card-header datacardname text-white">
        <?php

        $yeshello = [];
        $filter = [];
        $options = [];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $query);
        $i = 0;
        foreach ($cursor as $document) {
            $process = (array)$document;
            // if (strpos($process["transaction_id"], "MANUAL") === false) {
                $i++;
                array_push($yeshello, $process);
            // }
        }
        ?>
        Purchases (<?php echo $i; ?>)
        </div>
        <div class="card-body">
        <table class="table noborder">
            <thead class="scrollabletableheader">
                <tr>
                    <th class="d-none" scope="col">Username</th>
                    <th class="d-none" scope="col">Discord Name</th>
                    <th class="d-none" scope="col">Email</th>
                    <th class="d-none" scope="col" style="padding-right: 1em;">Product Name</th>
                </tr>
            </thead>
            <tbody id="purchasesscrollabletablebody" class="scrollabletablebody">
            <?php

            foreach ($yeshello as $document) {
                $process = (array)$document;
                ?>
                <tr class="scrollabletabletr">
                    <td class="noborder"><?php echo $process['username']; ?></td>
                    <td class="noborder"><?php echo $process['discordname']; ?></td>
                    <td class="noborder"><?php echo $process['email']; ?></td>
                    <td class="noborder rightstuff"><?php echo $process['productname']; ?></td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <?php
            if ($i == 0) {
                ?>
                <p class="card-text">No purchases found.</p>
                <script type="text/javascript">
                    $("#purchasesscrollabletablebody").removeClass("scrollabletablebody");
                </script>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<div class="row datarow">
    <div class="card datacard text-center" style="margin-top:5rem; width: 75rem;">
        <div class="card-header datacardname text-white">
        Banned Users
        </div>
        <div class="card-body">
        <table class="table noborder">
            <thead class="scrollabletableheader">
                <tr>
                    <th class="d-none" scope="col">Username</th>
                    <th class="d-none" scope="col">Banned by</th>
                    <th class="d-none" scope="col">Ban reason</th>
                    <th class="d-none" scope="col" style="padding-right: 1em;">Banned at</th>
                </tr>
            </thead>
            <tbody id="bannedusersscrollabletablebody" class="scrollabletablebody">
            <?php

            $filter = [];
            $options = [];
            $query = new MongoDB\Driver\Query($filter, $options);
            $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
            $i = 0;
            foreach ($cursor as $document) {
                $process = (array)$document;
                if ($process['banned']) {
                    $i++;
                ?>
                    <tr class="scrollabletabletr">
                        <td class="noborder"><?php echo $process['username']; ?></td>
                        <td class="noborder"><?php echo $process['bannedby']; ?></td>
                        <td class="noborder"><?php echo $process['banreason']; ?></td>
                        <td class="noborder rightstuff"><?php echo $process['bannedat']; ?></td>
                    </tr>
                <?php
                }
            }
            ?>
            </tbody>
        </table>
        <?php
        if ($i == 0) {
            ?>
            <p class="card-text">No banned users found.</p>
            <script type="text/javascript">
                $("#bannedusersscrollabletablebody").removeClass("scrollabletablebody");
            </script>
            <?php
        }
        ?>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(".invalid-perms").click(function() {
        toastr.error("You have insufficient permissions to modify this user.");
        return false;
    });

    $(document).ready(function() {
        $(".search").keyup(function () {
            var searchTerm = $(".search").val();
            if (searchTerm.length == 0) {
                $('.counter').fadeOut();
            } else {
                $('.counter').fadeIn();
            }
            var listItem = $('.men tbody').children('tr');
            var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
            $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
                    return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
                }
            });
                
            $(".men tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
                $(this).attr('visible','false');
                $(this).attr('style', 'display:none');
            });

            $(".men tbody tr:containsi('" + searchSplit + "')").each(function(e){
                $(this).attr('visible','true');
                $(this).attr('style', '');
            });

            var jobCount = $('.men tbody tr[visible="true"]').length;
            $('.counter').text(jobCount + ' item' + (jobCount > 1 ? "s" : ""));

            if(jobCount == '0') {
                $('.no-result').fadeIn();
            }else {
                $('.no-result').fadeOut();
            }
        });
    });
</script>