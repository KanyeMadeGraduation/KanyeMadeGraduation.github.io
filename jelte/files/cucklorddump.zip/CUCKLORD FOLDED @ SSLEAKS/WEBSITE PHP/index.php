<?php
/*error_reporting(E_ALL);
ini_set("display_errors", 1);*/
error_reporting(0);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
session_start();
require "config.php";

$VALID_PAGES = ["home", "products", "buy", "profile", "logout", "login", "register", "admin", "download", "file", "cancelled", "purchased", "charge", "user", "activate"];

$PAGE = "home";
$LOGGED_IN = false;
$USERNAME = "NONE";
$EMAIL = "NONE";
$DISCORD = "NONE";
$HWID = "NONE";
$USER_TOKEN = "NONE";
$PERMISSION = "NONE";
$STAFF_LEVEL = -1;
$BANNED = false;
$BAN_REASON = "Not banned";
$BAN_BY = "None";
$BAN_AT = "1970-01-01";
$OWNS_GHOST = false;
$OWNS_CUCKLORD = false;
$OWNS_CLICKER = false;

$ACCOUNT_ID = 0;
$ACCOUNT_BALANCE = 0.0;

$USR_REFERREAL = "";
$STORED_REFERREAL_INFO = [];
$REFERREAL_PART = "";
$REFERREAL_DISCOUNT = 0;

$STORED_USER_INFO = [];

if (isset($_SESSION["USERNAME"]) && !empty($_SESSION["USERNAME"])) {
    $filter = ["username"=>"".$_SESSION["USERNAME"],"password"=>"".$_SESSION["PASSWORD"]];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$MONGO_USERS_COLL", $query);
    $valid = false;
    foreach ($cursor as $document) {
        $valid = true;
        $STORED_USER_INFO = (array)$document;
    }
    if (!$valid) {
        if (strcasecmp($PAGE, "logout") !== 0) {
            header("Location: index.php?page=logout");
            die();
        } else {
            session_destroy();
            if (isset($_SESSION["USERNAME"])) {
                $_SESSION["USERNAME"] = "";
            }
        }
    } else {
        $USERNAME = $STORED_USER_INFO["username"];
        $EMAIL = $STORED_USER_INFO["email"];
        $PERMISSION = $STORED_USER_INFO["permission"];
        $BANNED = $STORED_USER_INFO["banned"];
        $DISCORD = $STORED_USER_INFO["discord"];
        $USER_TOKEN = $STORED_USER_INFO["usertoken"];
        $HWID = $STORED_USER_INFO["hwid"];
        $GHIWD = $STORED_USER_INFO["ghost_hwid"];

        if ($BANNED) {
            $BAN_REASON = $STORED_USER_INFO["banreason"];
            $BAN_BY = $STORED_USER_INFO["bannedby"];
            $BAN_AT = $STORED_USER_INFO["bannedat"];
        }
        $ACCOUNT_BALANCE = (double)$STORED_USER_INFO["balance"];
        $ACCOUNT_ID = (int)$STORED_USER_INFO["user_id"];
        $STAFF_LEVEL = $GLOBAL_PERMISSIONS[$PERMISSION];
        $LOGGED_IN = true;
        $filter = ["email"=>$EMAIL];
        $options = ["limit"=>1];
        $query = new MongoDB\Driver\Query($filter, $options);
        $cursor = $MONGO_MANAGER->executeQuery("$SIMPLE_DATABASE.$SIMPLE_PURCHASES_COLL", $query);
        $STORED_PURCHASE_DATA = [];
        foreach ($cursor as $document) {
            $STORED_PURCHASE_DATA = (array)$document;
            if ($STORED_PURCHASE_DATA["productid"] === "0001") {
                $OWNS_CUCKLORD = true;
            }
            if ($STORED_PURCHASE_DATA["productid"] === "0003") {
                $OWNS_CLICKER = true;
            }
            if ($STORED_PURCHASE_DATA["productid"] === "0004") {
                $OWNS_GHOST = true;
            }
        }
    }
}

if ($BANNED) {
    header("location: index.php?page=logout");
}

if (isset($_GET["page"])) {
    if (in_array($_GET["page"], $VALID_PAGES)) {
        $PAGE = $_GET["page"];
    }
}

if (isset($_POST["page"])) {
    if (in_array($_POST["page"], $VALID_PAGES)) {
        $PAGE = $_POST["page"];
    }
}

if ($PAGE === "file") {
    require "pages/".$PAGE.".php";
    die();
}

if (isset($_GET["r"])) {

    $filter = ["code"=>"".$_GET["r"]];
    $options = ["limit"=>1];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $MONGO_MANAGER->executeQuery("$MONGO_DATABASE.$REFERREALS_COLL", $query);
    $valid_referreal = false;
    foreach ($cursor as $document) {
        $valid_referreal = true;
        $STORED_REFERREAL_INFO = (array)$document;
    }

    if ($valid_referreal) {
        $USR_REFERREAL = $STORED_REFERREAL_INFO["code"];
        $REFERREAL_PART = "&r=".$USR_REFERREAL;
        $REFERREAL_DISCOUNT = $STORED_REFERREAL_INFO["discount"];
    } else {
        header("location: https://cucklord.pro/index.php?page=".$PAGE);
        die();
    }
}


?>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <meta name="description" content="">
		<meta property="og:title" content="Cucklord"/>
		<meta property="og:type" content="website"/>
		<meta property="og:url" content="https://levensles.club"/>
		<meta property="og:description" content=""/>
		<meta property="og:image" content="https://cucklord.pro/files/logo.png"/>
		<meta name="theme-color" content="#A63BDF" />
        <link rel="stylesheet" href="style.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">
        <title>Cucklord</title>
        <style>
        .bd-callout {
            padding: 1.25rem;
            margin-top: 1.25rem;
            margin-bottom: 1.25rem;
            border-left: 1px solid #515172;
            border-left-width: .25rem;
            border-radius: .25rem;
        }
        </style>
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="?page=home">Cucklord</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <?php

                    if ($LOGGED_IN) {
                        ?>
                        <li class="nav-item"><a class="nav-link <?php if ($PAGE === "products") echo "active"; ?>" href="?page=products<?php echo $REFERREAL_PART; ?>">Products</a></li>
                        <?php
                        if ( $OWNS_GHOST || $OWNS_CUCKLORD || $OWNS_CLICKER || $STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL -1) {
                            ?>
                            <li class="nav-item"><a class="nav-link <?php if ($PAGE === "download") echo "active"; ?>" href="?page=download<?php echo $REFERREAL_PART; ?>">Download</a></li>
                            <?php
                        }
                        ?>
                        <li class="nav-item"><a class="nav-link" href="https://discord.gg/tCnBDE7" target="_blank">Discord</a></li>
                        <li class="nav-item"><a class="nav-link" data-toggle="modal" id="tosnav" data-target="#termsOfServiceModal">Terms Of Service</a></li>
                        <?php
                    }

                    if ($STAFF_LEVEL > $ADMIN_PERMISSION_LEVEL - 1) {
                        ?>
                        <li class="nav-item"><a class="nav-link <?php if ($PAGE === "admin") echo "active"; ?>" href="?page=admin<?php echo $REFERREAL_PART; ?>">Admin Panel</a></li>
                        <?php
                    }
                    ?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php
                    if ($LOGGED_IN) {
                    ?>
                        <li class="nav-item dropdown ml-auto">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo $USERNAME; ?>   <span class="badge badge-success">$<?php echo $ACCOUNT_BALANCE; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="?page=profile<?php echo $REFERREAL_PART; ?>">View Profile</a>
                                <?php
                                if (!$TOPUPS_DISABLED/* || $STAFF_LEVEL >= $ADMIN_PERMISSION_LEVEL*/) {
                                    ?>
                                <a class="dropdown-item" href="?page=charge">Charge Balance</a>
                                <?php } ?>
                                <a class="dropdown-item" href="?page=logout">Log out</a>
                            </div>
                        </li>
                    <?php
                    } else {
                        ?>
                            <a class="nav-link <?php if ($PAGE === "login") echo "active"; ?>" href="?page=login<?php echo $REFERREAL_PART; ?>">Log in</a>
                            <a class="nav-link <?php if ($PAGE === "register") echo "active"; ?>" href="?page=register<?php echo $REFERREAL_PART; ?>">Register</a>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </nav>
        <div class="containter" style="overflow-x: hidden;">
            <?php
            if ($USR_REFERREAL !== "") {
                ?>
                <div class="bd-callout">
                    <p><strong>Heads up!</strong> You are using the "<strong><?php echo $STORED_REFERREAL_INFO["user"]; ?></strong>" referral code. <?php if ($REFERREAL_DISCOUNT > 0) { echo "This gives you a <strong>".$REFERREAL_DISCOUNT."%</strong> discount."; } ?></p>
                </div>
                <?php
            }

            require "pages/".$PAGE.".php";

            ?>
            <div class="modal fade" id="termsOfServiceModal" tabindex="-1" role="dialog" aria-labelledby="termsOfServiceModal" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Terms Of Service</h5>
                        </button>
                    </div>
                    <div class="modal-body" style="font-size: 15px;">
                        <span style="font-size: 16px;">Violating any of the following terms will result in a ban from using Cucklord.</span>
                        <hr/>
                        <ol class="tosOl">
                        <li>By purchasing, you agree not to receive a refund or dispute a chargeback on your payment and you certify to be the rightful owner of the money given.</li>
                            <li>All packages purchased are final as all sold items are virtual goods and not redeemable or useable in the real world. Due to this, we practice a no refunds/chargeback policy unless an exception (or special agreement) is created under the agreement of both parties (The user & Cucklord Administration)</li>
                            <li>Attempts to bypass or break our refund/chargeback policy via filing chargeback case with your credit card company will result in a permanent ban from our services. These actions could also cause a serious police investigation.</li>
                            <li>You are not allowed to try and find detections methods for all of the cucklord products. Doing so will result in a permanent ban from our services.</li>
                            <li>Attempting to crack, reverse engineer, steal code, reselling \ sharing the program and or account will result in a permanent ban from our services.</li>      
                            <li>We reserve the right to deny access to Cucklord to anyone without notice.</li>
                            <li>You agree to not use our pentesting services against services that you do not directly own.</li>
                            <li>We are in no way responsible if you misuse our services.</li>
                        </ol>
                        <hr/>
                        <span style="font-size: 16px;">We may, at any time, and at our sole discretion, modify these Terms and Conditions of Use, with or without notice to the User. Any such modification will be effective immediately upon public posting. Your continued use of our Service and this Site following any such modification constitutes your acceptance of these modified Terms.</span>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary payment-button continue" id="tosClose" data-dismiss="modal">Close</button>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>