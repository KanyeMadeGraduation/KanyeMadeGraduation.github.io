﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace _1vpnd
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Xbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void miniBTN_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        public static Point newpoint = new Point();
        public static int x;
        public static int y;

        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Form1.newpoint = Control.MousePosition;
                Form1.newpoint.X -= Form1.x;
                Form1.newpoint.Y -= Form1.y;
                base.Location = Form1.newpoint;
            }
        }

        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            Form1.x = Control.MousePosition.X - base.Location.X;
            Form1.y = Control.MousePosition.Y - base.Location.Y;
        }

        private static void EndProcessTree(string imageName)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "taskkill",
                Arguments = $"/im {imageName} /f /t",
                CreateNoWindow = true,
                UseShellExecute = false
            }).WaitForExit();
        }

        private void skeetButton1_Click(object sender, EventArgs e)
        {

            EndProcessTree("openvpn.exe");
            MessageBox.Show("Disconnected!");
        }

        private void AuthBTN_Click(object sender, EventArgs e)
        {

            if (skeetComboBox1.Text == "HYDRA - UK")
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.FileName = @"C:\Program Files\OpenVPN\bin\openvpn.exe";
                startInfo.Arguments = "--config client2.ovpn";
                startInfo.Verb = "runas";
                process.StartInfo = startInfo;

                process.Start();
                MessageBox.Show("Connected");
            }
            
            else if (skeetComboBox1.Text == "OVH - USA")
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.FileName = @"C:\Program Files\OpenVPN\bin\openvpn.exe";
                startInfo.Arguments = "--config client2.ovpn";
                startInfo.Verb = "runas";
                process.StartInfo = startInfo;

                process.Start();
                MessageBox.Show("Connected");
            }

            else if (skeetComboBox1.Text == "OVH - PARIS")
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.FileName = @"C:\Program Files\OpenVPN\bin\openvpn.exe";
                startInfo.Arguments = "--config usa.ovpn";
                startInfo.Verb = "runas";
                process.StartInfo = startInfo;

                process.Start();
                MessageBox.Show("Connected");
            }

            else
            { 
                MessageBox.Show("No Location Selected");
            }


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
            

