﻿namespace _1vpnd
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.miniBTN = new _1vpnd.SkeetButton();
            this.Xbtn = new _1vpnd.SkeetButton();
            this.shadowLabel1 = new _1vpnd.shadowLabel();
            this.AuthBTN = new _1vpnd.SkeetButton();
            this.skeetButton1 = new _1vpnd.SkeetButton();
            this.skeetComboBox1 = new _1vpnd.SkeetComboBox();
            this.SuspendLayout();
            // 
            // miniBTN
            // 
            this.miniBTN.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.miniBTN.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.miniBTN.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniBTN.Location = new System.Drawing.Point(260, 12);
            this.miniBTN.Name = "miniBTN";
            this.miniBTN.Size = new System.Drawing.Size(27, 26);
            this.miniBTN.TabIndex = 5;
            this.miniBTN.Text = "-";
            this.miniBTN.Click += new System.EventHandler(this.miniBTN_Click);
            // 
            // Xbtn
            // 
            this.Xbtn.ColorBottom = System.Drawing.Color.Red;
            this.Xbtn.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.Xbtn.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Xbtn.Location = new System.Drawing.Point(293, 12);
            this.Xbtn.Name = "Xbtn";
            this.Xbtn.Size = new System.Drawing.Size(27, 26);
            this.Xbtn.TabIndex = 6;
            this.Xbtn.Text = "X";
            this.Xbtn.Click += new System.EventHandler(this.Xbtn_Click);
            // 
            // shadowLabel1
            // 
            this.shadowLabel1.AutoSize = true;
            this.shadowLabel1.EnableShadow = false;
            this.shadowLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shadowLabel1.ForeColor = System.Drawing.Color.DarkViolet;
            this.shadowLabel1.Location = new System.Drawing.Point(40, 56);
            this.shadowLabel1.Name = "shadowLabel1";
            this.shadowLabel1.ShadowColor = System.Drawing.Color.LightGray;
            this.shadowLabel1.ShadowOffset = 1;
            this.shadowLabel1.Size = new System.Drawing.Size(263, 42);
            this.shadowLabel1.TabIndex = 7;
            this.shadowLabel1.Text = "Cucklord VPN ";
            // 
            // AuthBTN
            // 
            this.AuthBTN.ColorBottom = System.Drawing.Color.Purple;
            this.AuthBTN.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.AuthBTN.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuthBTN.Location = new System.Drawing.Point(33, 313);
            this.AuthBTN.Name = "AuthBTN";
            this.AuthBTN.Size = new System.Drawing.Size(122, 67);
            this.AuthBTN.TabIndex = 8;
            this.AuthBTN.Text = "Connect";
            this.AuthBTN.Click += new System.EventHandler(this.AuthBTN_Click);
            // 
            // skeetButton1
            // 
            this.skeetButton1.ColorBottom = System.Drawing.Color.Purple;
            this.skeetButton1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.skeetButton1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skeetButton1.Location = new System.Drawing.Point(181, 313);
            this.skeetButton1.Name = "skeetButton1";
            this.skeetButton1.Size = new System.Drawing.Size(122, 67);
            this.skeetButton1.TabIndex = 9;
            this.skeetButton1.Text = "Disconnect";
            this.skeetButton1.Click += new System.EventHandler(this.skeetButton1_Click);
            // 
            // skeetComboBox1
            // 
            this.skeetComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.skeetComboBox1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.skeetComboBox1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.skeetComboBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.skeetComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skeetComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skeetComboBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skeetComboBox1.ForeColor = System.Drawing.Color.White;
            this.skeetComboBox1.FormattingEnabled = true;
            this.skeetComboBox1.ItemHeight = 18;
            this.skeetComboBox1.Items.AddRange(new object[] {
            "OVH - USA",
            "OVH - PARIS",
            "HYDRA - UK"});
            this.skeetComboBox1.Location = new System.Drawing.Point(60, 207);
            this.skeetComboBox1.Name = "skeetComboBox1";
            this.skeetComboBox1.Size = new System.Drawing.Size(208, 24);
            this.skeetComboBox1.TabIndex = 10;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(332, 450);
            this.Controls.Add(this.skeetComboBox1);
            this.Controls.Add(this.skeetButton1);
            this.Controls.Add(this.AuthBTN);
            this.Controls.Add(this.shadowLabel1);
            this.Controls.Add(this.Xbtn);
            this.Controls.Add(this.miniBTN);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SkeetButton miniBTN;
        private SkeetButton Xbtn;
        private shadowLabel shadowLabel1;
        private SkeetButton AuthBTN;
        private SkeetButton skeetButton1;
        private SkeetComboBox skeetComboBox1;
    }
}