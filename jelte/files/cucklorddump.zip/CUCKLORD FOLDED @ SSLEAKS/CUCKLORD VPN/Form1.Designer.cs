﻿namespace _1vpnd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.skeetButton1 = new _1vpnd.SkeetButton();
            this.miniBTN = new _1vpnd.SkeetButton();
            this.Xbtn = new _1vpnd.SkeetButton();
            this.shadowLabel1 = new _1vpnd.shadowLabel();
            this.AuthBTN = new _1vpnd.SkeetButton();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // skeetButton1
            // 
            this.skeetButton1.ColorBottom = System.Drawing.Color.Purple;
            this.skeetButton1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.skeetButton1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skeetButton1.Location = new System.Drawing.Point(83, 241);
            this.skeetButton1.Name = "skeetButton1";
            this.skeetButton1.Size = new System.Drawing.Size(155, 60);
            this.skeetButton1.TabIndex = 5;
            this.skeetButton1.Text = "Get HWID";
            this.skeetButton1.Click += new System.EventHandler(this.skeetButton1_Click);
            // 
            // miniBTN
            // 
            this.miniBTN.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.miniBTN.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.miniBTN.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniBTN.Location = new System.Drawing.Point(260, 12);
            this.miniBTN.Name = "miniBTN";
            this.miniBTN.Size = new System.Drawing.Size(27, 26);
            this.miniBTN.TabIndex = 4;
            this.miniBTN.Text = "-";
            this.miniBTN.Click += new System.EventHandler(this.miniBTN_Click);
            // 
            // Xbtn
            // 
            this.Xbtn.ColorBottom = System.Drawing.Color.Red;
            this.Xbtn.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.Xbtn.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Xbtn.Location = new System.Drawing.Point(293, 12);
            this.Xbtn.Name = "Xbtn";
            this.Xbtn.Size = new System.Drawing.Size(27, 26);
            this.Xbtn.TabIndex = 3;
            this.Xbtn.Text = "X";
            this.Xbtn.Click += new System.EventHandler(this.Xbtn_Click);
            // 
            // shadowLabel1
            // 
            this.shadowLabel1.AutoSize = true;
            this.shadowLabel1.EnableShadow = false;
            this.shadowLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shadowLabel1.ForeColor = System.Drawing.Color.DarkViolet;
            this.shadowLabel1.Location = new System.Drawing.Point(38, 76);
            this.shadowLabel1.Name = "shadowLabel1";
            this.shadowLabel1.ShadowColor = System.Drawing.Color.LightGray;
            this.shadowLabel1.ShadowOffset = 1;
            this.shadowLabel1.Size = new System.Drawing.Size(263, 42);
            this.shadowLabel1.TabIndex = 2;
            this.shadowLabel1.Text = "Cucklord VPN ";
            // 
            // AuthBTN
            // 
            this.AuthBTN.ColorBottom = System.Drawing.Color.Purple;
            this.AuthBTN.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.AuthBTN.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuthBTN.Location = new System.Drawing.Point(83, 337);
            this.AuthBTN.Name = "AuthBTN";
            this.AuthBTN.Size = new System.Drawing.Size(155, 60);
            this.AuthBTN.TabIndex = 1;
            this.AuthBTN.Text = "Authenticate";
            this.AuthBTN.Click += new System.EventHandler(this.AuthBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(332, 450);
            this.Controls.Add(this.skeetButton1);
            this.Controls.Add(this.miniBTN);
            this.Controls.Add(this.Xbtn);
            this.Controls.Add(this.shadowLabel1);
            this.Controls.Add(this.AuthBTN);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private SkeetButton AuthBTN;
        private shadowLabel shadowLabel1;
        private SkeetButton Xbtn;
        private SkeetButton miniBTN;
        private SkeetButton skeetButton1;
    }
}

