﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace _1vpnd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("user32.dll")]
        private static extern int GetWindowThreadProcessId([In] IntPtr hWnd, ref int lpdwProcessId);

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
         
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }



        private void Xbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void miniBTN_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        public static Point newpoint = new Point();
        public static int x;
        public static int y;

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Form1.x = Control.MousePosition.X - base.Location.X;
            Form1.y = Control.MousePosition.Y - base.Location.Y;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Form1.newpoint = Control.MousePosition;
                Form1.newpoint.X -= Form1.x;
                Form1.newpoint.Y -= Form1.y;
                base.Location = Form1.newpoint;
            }
        }

        public static WebClient wc = new WebClient();
        private static string getWebString(string url)
        {
            List<string> _items = new List<string>();
            Form1.wc.Proxy = (IWebProxy)null;
            string str;
            try
            {
                str = Form1.wc.DownloadString(url);
            }
            catch (Exception ex)
            {
                str = "";
            }
            return str;
        }
        private void AuthBTN_Click(object sender, EventArgs e)
        {
            HttpWebRequest.DefaultWebProxy = new WebProxy();

            using (var client = new WebClient())

            {
                string result = client.DownloadString("https://pastebin.com/raw/CUk6gM7G");
                if (!result.Contains(auth.gethwid()))
                {
                    MessageBox.Show("Invalid Credentials");
                    Environment.Exit(0);


                }

                else
                {
                    this.Hide();
                    Form2 frmMain = new Form2();
                    frmMain.ShowDialog();
                    this.Close();
                    MessageBox.Show("Hydro VPN");

                    Webhook hook = new Webhook("https://discordapp.com/api/webhooks/732764273541120021/190xl4Z9enENbcxNQFdPvXp2cqdlWyD44sh86UcrWWmyZlA0dGpfVK43qiMJkKFucpza");
                    hook.Name = "Logins";

                    hook.SendMessage("HWID: " + auth.gethwid() + " Has Succesfully logged in");
                }
            }
        }

        private void skeetButton1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(auth.gethwid());
            MessageBox.Show("HWID Copied to Clipboard");
        }


    }
}
