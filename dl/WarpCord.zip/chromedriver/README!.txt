https://chromedriver.chromium.org/downloads

Check your own chrome browser version before and then download the right one.