NightX is a fork of LiquidBounce Client. The installation procedure is as follows.

1. Install minecraft forge 1.8.9

2. Launch minecraft forge 1.8.9 once

3. put nightx-release-b51.jar in mods folder inside AppData\Roaming\.minecraft

4. start forge again

5. If the main menu has changed, installation is complete!

(If it fails to start, please delete all mods except NightX in the mods folder and try again.)

If you want to use the official config with this client, you can install it by putting the configs folder in this folder into AppData\Roaming\.minecraft\NightX\configs
(The command to load config is ".config load <yourconfigname>")

Ask on my discord server if you need more help. (https://discord.gg/SGBccUXFKZ)
If you don't mind, please subscribe to youtube. Inspiring! (https://www.youtube.com/@as_pw)