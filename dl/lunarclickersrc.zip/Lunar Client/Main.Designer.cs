﻿
namespace Lunar_Client
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.homeBTN1 = new Guna.UI2.WinForms.Guna2Button();
            this.serversBTN1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.settingsBTN1 = new Guna.UI2.WinForms.Guna2Button();
            this.aboutBTN1 = new Guna.UI2.WinForms.Guna2Button();
            this.storeBTN1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.homePanel = new System.Windows.Forms.Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.launchBTN = new Guna.UI2.WinForms.Guna2Button();
            this.serverPanel = new System.Windows.Forms.Panel();
            this.launchBTN3 = new Guna.UI2.WinForms.Guna2Button();
            this.realserverpanel = new System.Windows.Forms.Panel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.settingsPanel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2TrackBar1 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button15 = new Guna.UI2.WinForms.Guna2Button();
            this.aboutPanel = new System.Windows.Forms.Panel();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button20 = new Guna.UI2.WinForms.Guna2Button();
            this.exitBTN = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox23 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox22 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox21 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox39 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox38 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox37 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox36 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox35 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox33 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox31 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox24 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox18 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox19 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox20 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox14 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox13 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox12 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox15 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox16 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox17 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox11 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.launchPic = new Guna.UI2.WinForms.Guna2PictureBox();
            this.launchpic2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox29 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox34 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox32 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox28 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox30 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox27 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox26 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox25 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Button21 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel4.SuspendLayout();
            this.guna2Panel5.SuspendLayout();
            this.guna2Panel6.SuspendLayout();
            this.homePanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.serverPanel.SuspendLayout();
            this.realserverpanel.SuspendLayout();
            this.settingsPanel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.aboutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.launchPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.launchpic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox25)).BeginInit();
            this.SuspendLayout();
            // 
            // homeBTN1
            // 
            this.homeBTN1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
            this.homeBTN1.BorderThickness = 2;
            this.homeBTN1.CheckedState.Parent = this.homeBTN1;
            this.homeBTN1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.homeBTN1.CustomImages.Parent = this.homeBTN1;
            this.homeBTN1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.homeBTN1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBTN1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.homeBTN1.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.homeBTN1.HoverState.Parent = this.homeBTN1;
            this.homeBTN1.Location = new System.Drawing.Point(397, 33);
            this.homeBTN1.Name = "homeBTN1";
            this.homeBTN1.ShadowDecoration.Parent = this.homeBTN1;
            this.homeBTN1.Size = new System.Drawing.Size(92, 42);
            this.homeBTN1.TabIndex = 3;
            this.homeBTN1.Text = "Home";
            this.homeBTN1.Click += new System.EventHandler(this.homeBTN1_Click);
            // 
            // serversBTN1
            // 
            this.serversBTN1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.serversBTN1.BorderThickness = 2;
            this.serversBTN1.CheckedState.Parent = this.serversBTN1;
            this.serversBTN1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.serversBTN1.CustomImages.Parent = this.serversBTN1;
            this.serversBTN1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.serversBTN1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serversBTN1.ForeColor = System.Drawing.Color.White;
            this.serversBTN1.HoverState.Parent = this.serversBTN1;
            this.serversBTN1.Location = new System.Drawing.Point(495, 33);
            this.serversBTN1.Name = "serversBTN1";
            this.serversBTN1.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.serversBTN1.ShadowDecoration.Parent = this.serversBTN1;
            this.serversBTN1.Size = new System.Drawing.Size(92, 42);
            this.serversBTN1.TabIndex = 4;
            this.serversBTN1.Text = "Servers";
            this.serversBTN1.Click += new System.EventHandler(this.serversBTN1_Click);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.ContainerControl = this;
            this.guna2DragControl1.TargetControl = this;
            // 
            // settingsBTN1
            // 
            this.settingsBTN1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.settingsBTN1.BorderThickness = 2;
            this.settingsBTN1.CheckedState.Parent = this.settingsBTN1;
            this.settingsBTN1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.settingsBTN1.CustomImages.Parent = this.settingsBTN1;
            this.settingsBTN1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.settingsBTN1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsBTN1.ForeColor = System.Drawing.Color.White;
            this.settingsBTN1.HoverState.Parent = this.settingsBTN1;
            this.settingsBTN1.Location = new System.Drawing.Point(593, 33);
            this.settingsBTN1.Name = "settingsBTN1";
            this.settingsBTN1.ShadowDecoration.Parent = this.settingsBTN1;
            this.settingsBTN1.Size = new System.Drawing.Size(92, 42);
            this.settingsBTN1.TabIndex = 6;
            this.settingsBTN1.Text = "Settings";
            this.settingsBTN1.Click += new System.EventHandler(this.settingsBTN1_Click);
            // 
            // aboutBTN1
            // 
            this.aboutBTN1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.aboutBTN1.BorderThickness = 2;
            this.aboutBTN1.CheckedState.Parent = this.aboutBTN1;
            this.aboutBTN1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aboutBTN1.CustomImages.Parent = this.aboutBTN1;
            this.aboutBTN1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.aboutBTN1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutBTN1.ForeColor = System.Drawing.Color.White;
            this.aboutBTN1.HoverState.Parent = this.aboutBTN1;
            this.aboutBTN1.Location = new System.Drawing.Point(691, 33);
            this.aboutBTN1.Name = "aboutBTN1";
            this.aboutBTN1.ShadowDecoration.Parent = this.aboutBTN1;
            this.aboutBTN1.Size = new System.Drawing.Size(92, 42);
            this.aboutBTN1.TabIndex = 7;
            this.aboutBTN1.Text = "About";
            this.aboutBTN1.Click += new System.EventHandler(this.aboutBTN1_Click);
            // 
            // storeBTN1
            // 
            this.storeBTN1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.storeBTN1.BorderThickness = 2;
            this.storeBTN1.CheckedState.Parent = this.storeBTN1;
            this.storeBTN1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.storeBTN1.CustomImages.Parent = this.storeBTN1;
            this.storeBTN1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.storeBTN1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.storeBTN1.ForeColor = System.Drawing.Color.White;
            this.storeBTN1.HoverState.Parent = this.storeBTN1;
            this.storeBTN1.Location = new System.Drawing.Point(789, 33);
            this.storeBTN1.Name = "storeBTN1";
            this.storeBTN1.ShadowDecoration.Parent = this.storeBTN1;
            this.storeBTN1.Size = new System.Drawing.Size(92, 42);
            this.storeBTN1.TabIndex = 8;
            this.storeBTN1.Text = "Store";
            this.storeBTN1.Click += new System.EventHandler(this.storeBTN1_Click);
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel4.BorderRadius = 3;
            this.guna2Panel4.Controls.Add(this.guna2PictureBox14);
            this.guna2Panel4.Controls.Add(this.guna2PictureBox13);
            this.guna2Panel4.Controls.Add(this.guna2PictureBox12);
            this.guna2Panel4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(29)))));
            this.guna2Panel4.Location = new System.Drawing.Point(12, 41);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.ShadowDecoration.Parent = this.guna2Panel4;
            this.guna2Panel4.Size = new System.Drawing.Size(405, 262);
            this.guna2Panel4.TabIndex = 10;
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel5.BorderRadius = 3;
            this.guna2Panel5.Controls.Add(this.guna2PictureBox15);
            this.guna2Panel5.Controls.Add(this.guna2PictureBox16);
            this.guna2Panel5.Controls.Add(this.guna2PictureBox17);
            this.guna2Panel5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(29)))));
            this.guna2Panel5.Location = new System.Drawing.Point(447, 41);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.Size = new System.Drawing.Size(405, 262);
            this.guna2Panel5.TabIndex = 13;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel6.BorderRadius = 3;
            this.guna2Panel6.Controls.Add(this.guna2PictureBox18);
            this.guna2Panel6.Controls.Add(this.guna2PictureBox19);
            this.guna2Panel6.Controls.Add(this.guna2PictureBox20);
            this.guna2Panel6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(29)))));
            this.guna2Panel6.Location = new System.Drawing.Point(883, 41);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.Size = new System.Drawing.Size(405, 262);
            this.guna2Panel6.TabIndex = 14;
            // 
            // homePanel
            // 
            this.homePanel.Controls.Add(this.guna2Button1);
            this.homePanel.Controls.Add(this.panel2);
            this.homePanel.Controls.Add(this.panel1);
            this.homePanel.Controls.Add(this.guna2PictureBox11);
            this.homePanel.Controls.Add(this.launchBTN);
            this.homePanel.Controls.Add(this.launchPic);
            this.homePanel.Controls.Add(this.launchpic2);
            this.homePanel.Controls.Add(this.guna2PictureBox2);
            this.homePanel.Location = new System.Drawing.Point(0, 97);
            this.homePanel.Name = "homePanel";
            this.homePanel.Size = new System.Drawing.Size(1354, 728);
            this.homePanel.TabIndex = 15;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(525, 662);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(249, 41);
            this.guna2Button1.TabIndex = 15;
            this.guna2Button1.UseTransparentBackground = true;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panel2.Controls.Add(this.guna2Panel6);
            this.panel2.Controls.Add(this.guna2Panel4);
            this.panel2.Controls.Add(this.guna2Panel5);
            this.panel2.Controls.Add(this.guna2PictureBox10);
            this.panel2.Location = new System.Drawing.Point(0, 329);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1302, 333);
            this.panel2.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.guna2PictureBox9);
            this.panel1.Controls.Add(this.guna2PictureBox8);
            this.panel1.Controls.Add(this.guna2PictureBox3);
            this.panel1.Controls.Add(this.guna2PictureBox7);
            this.panel1.Controls.Add(this.guna2PictureBox4);
            this.panel1.Controls.Add(this.guna2PictureBox6);
            this.panel1.Controls.Add(this.guna2PictureBox5);
            this.panel1.Location = new System.Drawing.Point(0, 272);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1302, 58);
            this.panel1.TabIndex = 15;
            // 
            // launchBTN
            // 
            this.launchBTN.BackColor = System.Drawing.Color.Transparent;
            this.launchBTN.BorderColor = System.Drawing.Color.Transparent;
            this.launchBTN.CheckedState.Parent = this.launchBTN;
            this.launchBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.launchBTN.CustomImages.Parent = this.launchBTN;
            this.launchBTN.FillColor = System.Drawing.Color.Transparent;
            this.launchBTN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.launchBTN.ForeColor = System.Drawing.Color.White;
            this.launchBTN.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.launchBTN.HoverState.Parent = this.launchBTN;
            this.launchBTN.Location = new System.Drawing.Point(466, 100);
            this.launchBTN.Name = "launchBTN";
            this.launchBTN.PressedColor = System.Drawing.Color.Transparent;
            this.launchBTN.PressedDepth = 100;
            this.launchBTN.ShadowDecoration.Parent = this.launchBTN;
            this.launchBTN.Size = new System.Drawing.Size(368, 77);
            this.launchBTN.TabIndex = 9;
            this.launchBTN.UseTransparentBackground = true;
            this.launchBTN.Click += new System.EventHandler(this.guna2Button2_Click);
            this.launchBTN.MouseEnter += new System.EventHandler(this.guna2Button2_MouseEnter);
            this.launchBTN.MouseLeave += new System.EventHandler(this.guna2Button2_MouseLeave);
            this.launchBTN.MouseHover += new System.EventHandler(this.guna2Button2_MouseHover);
            // 
            // serverPanel
            // 
            this.serverPanel.Controls.Add(this.guna2PictureBox23);
            this.serverPanel.Controls.Add(this.launchBTN3);
            this.serverPanel.Controls.Add(this.guna2PictureBox22);
            this.serverPanel.Controls.Add(this.guna2PictureBox21);
            this.serverPanel.Location = new System.Drawing.Point(0, 97);
            this.serverPanel.Name = "serverPanel";
            this.serverPanel.Size = new System.Drawing.Size(1302, 150);
            this.serverPanel.TabIndex = 15;
            this.serverPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.serverPanel_Paint);
            // 
            // launchBTN3
            // 
            this.launchBTN3.BackColor = System.Drawing.Color.Transparent;
            this.launchBTN3.CheckedState.Parent = this.launchBTN3;
            this.launchBTN3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.launchBTN3.CustomImages.Parent = this.launchBTN3;
            this.launchBTN3.FillColor = System.Drawing.Color.Transparent;
            this.launchBTN3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.launchBTN3.ForeColor = System.Drawing.Color.White;
            this.launchBTN3.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.launchBTN3.HoverState.Parent = this.launchBTN3;
            this.launchBTN3.Location = new System.Drawing.Point(466, 37);
            this.launchBTN3.Name = "launchBTN3";
            this.launchBTN3.PressedColor = System.Drawing.Color.Transparent;
            this.launchBTN3.ShadowDecoration.Parent = this.launchBTN3;
            this.launchBTN3.Size = new System.Drawing.Size(368, 78);
            this.launchBTN3.TabIndex = 2;
            this.launchBTN3.UseTransparentBackground = true;
            this.launchBTN3.Click += new System.EventHandler(this.launchBTN3_Click);
            this.launchBTN3.MouseEnter += new System.EventHandler(this.launchBTN3_MouseEnter);
            this.launchBTN3.MouseLeave += new System.EventHandler(this.launchBTN3_MouseLeave);
            // 
            // realserverpanel
            // 
            this.realserverpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.realserverpanel.Controls.Add(this.guna2PictureBox39);
            this.realserverpanel.Controls.Add(this.guna2PictureBox38);
            this.realserverpanel.Controls.Add(this.guna2PictureBox37);
            this.realserverpanel.Controls.Add(this.guna2PictureBox36);
            this.realserverpanel.Controls.Add(this.guna2PictureBox35);
            this.realserverpanel.Controls.Add(this.guna2PictureBox33);
            this.realserverpanel.Controls.Add(this.guna2PictureBox31);
            this.realserverpanel.Controls.Add(this.guna2Button8);
            this.realserverpanel.Controls.Add(this.guna2Button7);
            this.realserverpanel.Controls.Add(this.guna2Button6);
            this.realserverpanel.Controls.Add(this.guna2Button5);
            this.realserverpanel.Controls.Add(this.guna2Button4);
            this.realserverpanel.Controls.Add(this.guna2Button3);
            this.realserverpanel.Controls.Add(this.guna2Button2);
            this.realserverpanel.Controls.Add(this.guna2PictureBox24);
            this.realserverpanel.Location = new System.Drawing.Point(-6, 240);
            this.realserverpanel.Name = "realserverpanel";
            this.realserverpanel.Size = new System.Drawing.Size(1326, 522);
            this.realserverpanel.TabIndex = 14;
            // 
            // guna2Button8
            // 
            this.guna2Button8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button8.CheckedState.Parent = this.guna2Button8;
            this.guna2Button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button8.CustomImages.Parent = this.guna2Button8;
            this.guna2Button8.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button8.HoverState.Parent = this.guna2Button8;
            this.guna2Button8.Location = new System.Drawing.Point(341, 385);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button8.ShadowDecoration.Parent = this.guna2Button8;
            this.guna2Button8.Size = new System.Drawing.Size(83, 92);
            this.guna2Button8.TabIndex = 7;
            this.guna2Button8.UseTransparentBackground = true;
            this.guna2Button8.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Location = new System.Drawing.Point(341, 213);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(83, 92);
            this.guna2Button7.TabIndex = 6;
            this.guna2Button7.UseTransparentBackground = true;
            this.guna2Button7.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // guna2Button6
            // 
            this.guna2Button6.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Location = new System.Drawing.Point(341, 42);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(83, 92);
            this.guna2Button6.TabIndex = 5;
            this.guna2Button6.UseTransparentBackground = true;
            this.guna2Button6.Click += new System.EventHandler(this.guna2Button6_Click);
            // 
            // guna2Button5
            // 
            this.guna2Button5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(746, 42);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(83, 92);
            this.guna2Button5.TabIndex = 4;
            this.guna2Button5.UseTransparentBackground = true;
            this.guna2Button5.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(746, 213);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(83, 92);
            this.guna2Button4.TabIndex = 3;
            this.guna2Button4.UseTransparentBackground = true;
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(1147, 42);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(83, 92);
            this.guna2Button3.TabIndex = 2;
            this.guna2Button3.UseTransparentBackground = true;
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(1147, 213);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.PressedColor = System.Drawing.Color.Transparent;
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(83, 92);
            this.guna2Button2.TabIndex = 1;
            this.guna2Button2.UseTransparentBackground = true;
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click_1);
            // 
            // settingsPanel
            // 
            this.settingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.settingsPanel.Controls.Add(this.panel3);
            this.settingsPanel.Location = new System.Drawing.Point(-6, 240);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(1326, 522);
            this.settingsPanel.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(29)))));
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.guna2PictureBox25);
            this.panel3.Location = new System.Drawing.Point(63, 16);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1192, 489);
            this.panel3.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.panel5.Controls.Add(this.guna2Button11);
            this.panel5.Controls.Add(this.guna2Button10);
            this.panel5.Controls.Add(this.guna2Button9);
            this.panel5.Controls.Add(this.guna2PictureBox27);
            this.panel5.Location = new System.Drawing.Point(26, 105);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(358, 172);
            this.panel5.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.guna2TrackBar1);
            this.panel4.Controls.Add(this.guna2PictureBox26);
            this.panel4.Location = new System.Drawing.Point(419, 105);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(358, 172);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(140, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "1 1  G B  L E F T  T O  A L L O C A T E";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(62, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Y O U  H A V E ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(113, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "4.6 GB ALLOCATED";
            // 
            // guna2TrackBar1
            // 
            this.guna2TrackBar1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(200)))), ((int)(((byte)(207)))));
            this.guna2TrackBar1.HoverState.Parent = this.guna2TrackBar1;
            this.guna2TrackBar1.IndicateFocus = false;
            this.guna2TrackBar1.Location = new System.Drawing.Point(30, 65);
            this.guna2TrackBar1.Maximum = 16;
            this.guna2TrackBar1.MouseWheelBarPartitions = 1;
            this.guna2TrackBar1.Name = "guna2TrackBar1";
            this.guna2TrackBar1.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar1.TabIndex = 3;
            this.guna2TrackBar1.ThumbColor = System.Drawing.Color.White;
            this.guna2TrackBar1.Value = 4;
            this.guna2TrackBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar1_Scroll);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this.panel4;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.panel6.Controls.Add(this.guna2Button14);
            this.panel6.Controls.Add(this.guna2Button15);
            this.panel6.Controls.Add(this.guna2PictureBox28);
            this.panel6.Controls.Add(this.guna2PictureBox30);
            this.panel6.Location = new System.Drawing.Point(810, 105);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(358, 344);
            this.panel6.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.panel7.Controls.Add(this.guna2Button21);
            this.panel7.Controls.Add(this.guna2Button13);
            this.panel7.Controls.Add(this.guna2PictureBox32);
            this.panel7.Location = new System.Drawing.Point(419, 295);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(358, 154);
            this.panel7.TabIndex = 4;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.panel8.Controls.Add(this.guna2Button12);
            this.panel8.Controls.Add(this.guna2PictureBox34);
            this.panel8.Location = new System.Drawing.Point(26, 295);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(358, 154);
            this.panel8.TabIndex = 4;
            // 
            // guna2Button9
            // 
            this.guna2Button9.BorderRadius = 5;
            this.guna2Button9.CheckedState.Parent = this.guna2Button9;
            this.guna2Button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button9.CustomImages.Parent = this.guna2Button9;
            this.guna2Button9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.guna2Button9.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button9.ForeColor = System.Drawing.Color.White;
            this.guna2Button9.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(175)))), ((int)(((byte)(85)))));
            this.guna2Button9.HoverState.Parent = this.guna2Button9;
            this.guna2Button9.Location = new System.Drawing.Point(91, 61);
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.ShadowDecoration.Parent = this.guna2Button9;
            this.guna2Button9.Size = new System.Drawing.Size(177, 27);
            this.guna2Button9.TabIndex = 3;
            this.guna2Button9.Text = "Hide Launcher";
            this.guna2Button9.Click += new System.EventHandler(this.guna2Button9_Click);
            // 
            // guna2Button10
            // 
            this.guna2Button10.BorderRadius = 5;
            this.guna2Button10.CheckedState.Parent = this.guna2Button10;
            this.guna2Button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button10.CustomImages.Parent = this.guna2Button10;
            this.guna2Button10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.guna2Button10.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button10.ForeColor = System.Drawing.Color.White;
            this.guna2Button10.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.guna2Button10.HoverState.Parent = this.guna2Button10;
            this.guna2Button10.Location = new System.Drawing.Point(91, 95);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.ShadowDecoration.Parent = this.guna2Button10;
            this.guna2Button10.Size = new System.Drawing.Size(177, 27);
            this.guna2Button10.TabIndex = 4;
            this.guna2Button10.Text = "Keep Launcher Open";
            this.guna2Button10.Click += new System.EventHandler(this.guna2Button10_Click);
            // 
            // guna2Button11
            // 
            this.guna2Button11.BorderRadius = 5;
            this.guna2Button11.CheckedState.Parent = this.guna2Button11;
            this.guna2Button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button11.CustomImages.Parent = this.guna2Button11;
            this.guna2Button11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.guna2Button11.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button11.ForeColor = System.Drawing.Color.White;
            this.guna2Button11.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.guna2Button11.HoverState.Parent = this.guna2Button11;
            this.guna2Button11.Location = new System.Drawing.Point(91, 127);
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.ShadowDecoration.Parent = this.guna2Button11;
            this.guna2Button11.Size = new System.Drawing.Size(177, 27);
            this.guna2Button11.TabIndex = 5;
            this.guna2Button11.Text = "Close Launcher";
            this.guna2Button11.Click += new System.EventHandler(this.guna2Button11_Click);
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this.panel6;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.TargetControl = this.panel7;
            // 
            // guna2Elipse4
            // 
            this.guna2Elipse4.TargetControl = this.panel8;
            // 
            // guna2Elipse5
            // 
            this.guna2Elipse5.TargetControl = this.panel5;
            // 
            // guna2Button13
            // 
            this.guna2Button13.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button13.CheckedState.Parent = this.guna2Button13;
            this.guna2Button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button13.CustomImages.Parent = this.guna2Button13;
            this.guna2Button13.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button13.ForeColor = System.Drawing.Color.White;
            this.guna2Button13.HoverState.Parent = this.guna2Button13;
            this.guna2Button13.Location = new System.Drawing.Point(65, 109);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.ShadowDecoration.Parent = this.guna2Button13;
            this.guna2Button13.Size = new System.Drawing.Size(114, 32);
            this.guna2Button13.TabIndex = 3;
            this.guna2Button13.UseTransparentBackground = true;
            // 
            // guna2Button14
            // 
            this.guna2Button14.BorderRadius = 5;
            this.guna2Button14.CheckedState.Parent = this.guna2Button14;
            this.guna2Button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button14.CustomImages.Parent = this.guna2Button14;
            this.guna2Button14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.guna2Button14.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button14.ForeColor = System.Drawing.Color.White;
            this.guna2Button14.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.guna2Button14.HoverState.Parent = this.guna2Button14;
            this.guna2Button14.Location = new System.Drawing.Point(103, 106);
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.ShadowDecoration.Parent = this.guna2Button14;
            this.guna2Button14.Size = new System.Drawing.Size(177, 27);
            this.guna2Button14.TabIndex = 7;
            this.guna2Button14.Text = "Experimental Branch";
            this.guna2Button14.Click += new System.EventHandler(this.guna2Button14_Click);
            // 
            // guna2Button15
            // 
            this.guna2Button15.BorderRadius = 5;
            this.guna2Button15.CheckedState.Parent = this.guna2Button15;
            this.guna2Button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button15.CustomImages.Parent = this.guna2Button15;
            this.guna2Button15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.guna2Button15.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button15.ForeColor = System.Drawing.Color.White;
            this.guna2Button15.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(175)))), ((int)(((byte)(85)))));
            this.guna2Button15.HoverState.Parent = this.guna2Button15;
            this.guna2Button15.Location = new System.Drawing.Point(103, 67);
            this.guna2Button15.Name = "guna2Button15";
            this.guna2Button15.ShadowDecoration.Parent = this.guna2Button15;
            this.guna2Button15.Size = new System.Drawing.Size(177, 27);
            this.guna2Button15.TabIndex = 6;
            this.guna2Button15.Text = "Stable Branch";
            this.guna2Button15.Click += new System.EventHandler(this.guna2Button15_Click);
            // 
            // aboutPanel
            // 
            this.aboutPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.aboutPanel.Controls.Add(this.guna2Button20);
            this.aboutPanel.Controls.Add(this.guna2Button19);
            this.aboutPanel.Controls.Add(this.guna2Button18);
            this.aboutPanel.Controls.Add(this.guna2Button17);
            this.aboutPanel.Controls.Add(this.guna2Button16);
            this.aboutPanel.Controls.Add(this.guna2PictureBox29);
            this.aboutPanel.Location = new System.Drawing.Point(-1, 240);
            this.aboutPanel.Name = "aboutPanel";
            this.aboutPanel.Size = new System.Drawing.Size(1339, 522);
            this.aboutPanel.TabIndex = 1;
            // 
            // guna2Button16
            // 
            this.guna2Button16.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button16.CheckedState.Parent = this.guna2Button16;
            this.guna2Button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button16.CustomImages.Parent = this.guna2Button16;
            this.guna2Button16.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.HoverState.Parent = this.guna2Button16;
            this.guna2Button16.Location = new System.Drawing.Point(946, 308);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.ShadowDecoration.Parent = this.guna2Button16;
            this.guna2Button16.Size = new System.Drawing.Size(180, 23);
            this.guna2Button16.TabIndex = 1;
            this.guna2Button16.UseTransparentBackground = true;
            this.guna2Button16.Click += new System.EventHandler(this.guna2Button16_Click);
            // 
            // guna2Button17
            // 
            this.guna2Button17.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button17.CheckedState.Parent = this.guna2Button17;
            this.guna2Button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button17.CustomImages.Parent = this.guna2Button17;
            this.guna2Button17.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button17.ForeColor = System.Drawing.Color.White;
            this.guna2Button17.HoverState.Parent = this.guna2Button17;
            this.guna2Button17.Location = new System.Drawing.Point(174, 308);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.ShadowDecoration.Parent = this.guna2Button17;
            this.guna2Button17.Size = new System.Drawing.Size(180, 23);
            this.guna2Button17.TabIndex = 2;
            this.guna2Button17.UseTransparentBackground = true;
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2Button18
            // 
            this.guna2Button18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button18.CheckedState.Parent = this.guna2Button18;
            this.guna2Button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button18.CustomImages.Parent = this.guna2Button18;
            this.guna2Button18.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button18.ForeColor = System.Drawing.Color.White;
            this.guna2Button18.HoverState.Parent = this.guna2Button18;
            this.guna2Button18.Location = new System.Drawing.Point(812, 418);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.ShadowDecoration.Parent = this.guna2Button18;
            this.guna2Button18.Size = new System.Drawing.Size(227, 37);
            this.guna2Button18.TabIndex = 3;
            this.guna2Button18.UseTransparentBackground = true;
            this.guna2Button18.Click += new System.EventHandler(this.guna2Button18_Click);
            // 
            // guna2Button19
            // 
            this.guna2Button19.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button19.CheckedState.Parent = this.guna2Button19;
            this.guna2Button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button19.CustomImages.Parent = this.guna2Button19;
            this.guna2Button19.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button19.ForeColor = System.Drawing.Color.White;
            this.guna2Button19.HoverState.Parent = this.guna2Button19;
            this.guna2Button19.Location = new System.Drawing.Point(538, 420);
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.ShadowDecoration.Parent = this.guna2Button19;
            this.guna2Button19.Size = new System.Drawing.Size(227, 37);
            this.guna2Button19.TabIndex = 4;
            this.guna2Button19.UseTransparentBackground = true;
            this.guna2Button19.Click += new System.EventHandler(this.guna2Button19_Click);
            // 
            // guna2Button20
            // 
            this.guna2Button20.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button20.CheckedState.Parent = this.guna2Button20;
            this.guna2Button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button20.CustomImages.Parent = this.guna2Button20;
            this.guna2Button20.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button20.ForeColor = System.Drawing.Color.White;
            this.guna2Button20.HoverState.Parent = this.guna2Button20;
            this.guna2Button20.Location = new System.Drawing.Point(263, 418);
            this.guna2Button20.Name = "guna2Button20";
            this.guna2Button20.ShadowDecoration.Parent = this.guna2Button20;
            this.guna2Button20.Size = new System.Drawing.Size(227, 37);
            this.guna2Button20.TabIndex = 5;
            this.guna2Button20.UseTransparentBackground = true;
            this.guna2Button20.Click += new System.EventHandler(this.guna2Button20_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
            this.exitBTN.BorderRadius = 3;
            this.exitBTN.BorderThickness = 2;
            this.exitBTN.CheckedState.Parent = this.exitBTN;
            this.exitBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exitBTN.CustomImages.Parent = this.exitBTN;
            this.exitBTN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.exitBTN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.exitBTN.ForeColor = System.Drawing.Color.White;
            this.exitBTN.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
            this.exitBTN.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(53)))), ((int)(((byte)(69)))));
            this.exitBTN.HoverState.Parent = this.exitBTN;
            this.exitBTN.Image = global::Lunar_Client.Properties.Resources.multiply_26px;
            this.exitBTN.ImageSize = new System.Drawing.Size(17, 17);
            this.exitBTN.Location = new System.Drawing.Point(1229, 33);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.ShadowDecoration.Parent = this.exitBTN;
            this.exitBTN.Size = new System.Drawing.Size(40, 40);
            this.exitBTN.TabIndex = 5;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_p4D27H5Tz1;
            this.guna2PictureBox1.Location = new System.Drawing.Point(0, 1);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(292, 90);
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2PictureBox23
            // 
            this.guna2PictureBox23.Location = new System.Drawing.Point(43, 372);
            this.guna2PictureBox23.Name = "guna2PictureBox23";
            this.guna2PictureBox23.ShadowDecoration.Parent = this.guna2PictureBox23;
            this.guna2PictureBox23.Size = new System.Drawing.Size(300, 200);
            this.guna2PictureBox23.TabIndex = 3;
            this.guna2PictureBox23.TabStop = false;
            // 
            // guna2PictureBox22
            // 
            this.guna2PictureBox22.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_Fk7Lzsyh9d;
            this.guna2PictureBox22.Location = new System.Drawing.Point(414, 2);
            this.guna2PictureBox22.Name = "guna2PictureBox22";
            this.guna2PictureBox22.ShadowDecoration.Parent = this.guna2PictureBox22;
            this.guna2PictureBox22.Size = new System.Drawing.Size(467, 150);
            this.guna2PictureBox22.TabIndex = 1;
            this.guna2PictureBox22.TabStop = false;
            // 
            // guna2PictureBox21
            // 
            this.guna2PictureBox21.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_AFH5ccAoQR;
            this.guna2PictureBox21.Location = new System.Drawing.Point(-1, 2);
            this.guna2PictureBox21.Name = "guna2PictureBox21";
            this.guna2PictureBox21.ShadowDecoration.Parent = this.guna2PictureBox21;
            this.guna2PictureBox21.Size = new System.Drawing.Size(1387, 140);
            this.guna2PictureBox21.TabIndex = 0;
            this.guna2PictureBox21.TabStop = false;
            // 
            // guna2PictureBox39
            // 
            this.guna2PictureBox39.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox39.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_ybQBigXIqk;
            this.guna2PictureBox39.Location = new System.Drawing.Point(264, 407);
            this.guna2PictureBox39.Name = "guna2PictureBox39";
            this.guna2PictureBox39.ShadowDecoration.Parent = this.guna2PictureBox39;
            this.guna2PictureBox39.Size = new System.Drawing.Size(34, 25);
            this.guna2PictureBox39.TabIndex = 14;
            this.guna2PictureBox39.TabStop = false;
            this.guna2PictureBox39.UseTransparentBackground = true;
            // 
            // guna2PictureBox38
            // 
            this.guna2PictureBox38.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox38.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_JQ0fQ0exID;
            this.guna2PictureBox38.Location = new System.Drawing.Point(1071, 237);
            this.guna2PictureBox38.Name = "guna2PictureBox38";
            this.guna2PictureBox38.ShadowDecoration.Parent = this.guna2PictureBox38;
            this.guna2PictureBox38.Size = new System.Drawing.Size(31, 21);
            this.guna2PictureBox38.TabIndex = 13;
            this.guna2PictureBox38.TabStop = false;
            this.guna2PictureBox38.UseTransparentBackground = true;
            // 
            // guna2PictureBox37
            // 
            this.guna2PictureBox37.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox37.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_QnUV1g2qDP1;
            this.guna2PictureBox37.Location = new System.Drawing.Point(668, 237);
            this.guna2PictureBox37.Name = "guna2PictureBox37";
            this.guna2PictureBox37.ShadowDecoration.Parent = this.guna2PictureBox37;
            this.guna2PictureBox37.Size = new System.Drawing.Size(33, 23);
            this.guna2PictureBox37.TabIndex = 12;
            this.guna2PictureBox37.TabStop = false;
            this.guna2PictureBox37.UseTransparentBackground = true;
            // 
            // guna2PictureBox36
            // 
            this.guna2PictureBox36.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox36.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_fPE4ud0S9H;
            this.guna2PictureBox36.Location = new System.Drawing.Point(264, 236);
            this.guna2PictureBox36.Name = "guna2PictureBox36";
            this.guna2PictureBox36.ShadowDecoration.Parent = this.guna2PictureBox36;
            this.guna2PictureBox36.Size = new System.Drawing.Size(31, 30);
            this.guna2PictureBox36.TabIndex = 11;
            this.guna2PictureBox36.TabStop = false;
            this.guna2PictureBox36.UseTransparentBackground = true;
            // 
            // guna2PictureBox35
            // 
            this.guna2PictureBox35.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox35.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_GcNIiKNIm6;
            this.guna2PictureBox35.Location = new System.Drawing.Point(1071, 65);
            this.guna2PictureBox35.Name = "guna2PictureBox35";
            this.guna2PictureBox35.ShadowDecoration.Parent = this.guna2PictureBox35;
            this.guna2PictureBox35.Size = new System.Drawing.Size(37, 22);
            this.guna2PictureBox35.TabIndex = 10;
            this.guna2PictureBox35.TabStop = false;
            this.guna2PictureBox35.UseTransparentBackground = true;
            // 
            // guna2PictureBox33
            // 
            this.guna2PictureBox33.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox33.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_I2evAeUWCM;
            this.guna2PictureBox33.Location = new System.Drawing.Point(668, 66);
            this.guna2PictureBox33.Name = "guna2PictureBox33";
            this.guna2PictureBox33.ShadowDecoration.Parent = this.guna2PictureBox33;
            this.guna2PictureBox33.Size = new System.Drawing.Size(34, 22);
            this.guna2PictureBox33.TabIndex = 9;
            this.guna2PictureBox33.TabStop = false;
            this.guna2PictureBox33.UseTransparentBackground = true;
            // 
            // guna2PictureBox31
            // 
            this.guna2PictureBox31.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox31.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_l1U8gp2qO6;
            this.guna2PictureBox31.Location = new System.Drawing.Point(265, 65);
            this.guna2PictureBox31.Name = "guna2PictureBox31";
            this.guna2PictureBox31.ShadowDecoration.Parent = this.guna2PictureBox31;
            this.guna2PictureBox31.Size = new System.Drawing.Size(33, 23);
            this.guna2PictureBox31.TabIndex = 8;
            this.guna2PictureBox31.TabStop = false;
            this.guna2PictureBox31.UseTransparentBackground = true;
            // 
            // guna2PictureBox24
            // 
            this.guna2PictureBox24.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_aNecdq09t1;
            this.guna2PictureBox24.Location = new System.Drawing.Point(56, 13);
            this.guna2PictureBox24.Name = "guna2PictureBox24";
            this.guna2PictureBox24.ShadowDecoration.Parent = this.guna2PictureBox24;
            this.guna2PictureBox24.Size = new System.Drawing.Size(1199, 492);
            this.guna2PictureBox24.TabIndex = 0;
            this.guna2PictureBox24.TabStop = false;
            // 
            // guna2PictureBox18
            // 
            this.guna2PictureBox18.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox18.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_6mNBVmfQCW;
            this.guna2PictureBox18.Location = new System.Drawing.Point(309, 222);
            this.guna2PictureBox18.Name = "guna2PictureBox18";
            this.guna2PictureBox18.ShadowDecoration.Parent = this.guna2PictureBox18;
            this.guna2PictureBox18.Size = new System.Drawing.Size(83, 27);
            this.guna2PictureBox18.TabIndex = 13;
            this.guna2PictureBox18.TabStop = false;
            this.guna2PictureBox18.UseTransparentBackground = true;
            this.guna2PictureBox18.Click += new System.EventHandler(this.guna2PictureBox18_Click);
            // 
            // guna2PictureBox19
            // 
            this.guna2PictureBox19.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_wmCe5Wei6v;
            this.guna2PictureBox19.Location = new System.Drawing.Point(6, 180);
            this.guna2PictureBox19.Name = "guna2PictureBox19";
            this.guna2PictureBox19.ShadowDecoration.Parent = this.guna2PictureBox19;
            this.guna2PictureBox19.Size = new System.Drawing.Size(428, 98);
            this.guna2PictureBox19.TabIndex = 13;
            this.guna2PictureBox19.TabStop = false;
            // 
            // guna2PictureBox20
            // 
            this.guna2PictureBox20.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_GUt8in55JR;
            this.guna2PictureBox20.Location = new System.Drawing.Point(0, 0);
            this.guna2PictureBox20.Name = "guna2PictureBox20";
            this.guna2PictureBox20.ShadowDecoration.Parent = this.guna2PictureBox20;
            this.guna2PictureBox20.Size = new System.Drawing.Size(405, 198);
            this.guna2PictureBox20.TabIndex = 0;
            this.guna2PictureBox20.TabStop = false;
            // 
            // guna2PictureBox14
            // 
            this.guna2PictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox14.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_6mNBVmfQCW;
            this.guna2PictureBox14.Location = new System.Drawing.Point(311, 222);
            this.guna2PictureBox14.Name = "guna2PictureBox14";
            this.guna2PictureBox14.ShadowDecoration.Parent = this.guna2PictureBox14;
            this.guna2PictureBox14.Size = new System.Drawing.Size(83, 27);
            this.guna2PictureBox14.TabIndex = 13;
            this.guna2PictureBox14.TabStop = false;
            this.guna2PictureBox14.UseTransparentBackground = true;
            this.guna2PictureBox14.Click += new System.EventHandler(this.guna2PictureBox14_Click);
            // 
            // guna2PictureBox13
            // 
            this.guna2PictureBox13.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_SGKKY5PA72;
            this.guna2PictureBox13.Location = new System.Drawing.Point(6, 180);
            this.guna2PictureBox13.Name = "guna2PictureBox13";
            this.guna2PictureBox13.ShadowDecoration.Parent = this.guna2PictureBox13;
            this.guna2PictureBox13.Size = new System.Drawing.Size(428, 98);
            this.guna2PictureBox13.TabIndex = 13;
            this.guna2PictureBox13.TabStop = false;
            // 
            // guna2PictureBox12
            // 
            this.guna2PictureBox12.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_RERMUpZUTa;
            this.guna2PictureBox12.Location = new System.Drawing.Point(0, 0);
            this.guna2PictureBox12.Name = "guna2PictureBox12";
            this.guna2PictureBox12.ShadowDecoration.Parent = this.guna2PictureBox12;
            this.guna2PictureBox12.Size = new System.Drawing.Size(405, 198);
            this.guna2PictureBox12.TabIndex = 0;
            this.guna2PictureBox12.TabStop = false;
            // 
            // guna2PictureBox15
            // 
            this.guna2PictureBox15.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2PictureBox15.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_6mNBVmfQCW;
            this.guna2PictureBox15.Location = new System.Drawing.Point(312, 220);
            this.guna2PictureBox15.Name = "guna2PictureBox15";
            this.guna2PictureBox15.ShadowDecoration.Parent = this.guna2PictureBox15;
            this.guna2PictureBox15.Size = new System.Drawing.Size(83, 27);
            this.guna2PictureBox15.TabIndex = 13;
            this.guna2PictureBox15.TabStop = false;
            this.guna2PictureBox15.UseTransparentBackground = true;
            this.guna2PictureBox15.Click += new System.EventHandler(this.guna2PictureBox15_Click);
            // 
            // guna2PictureBox16
            // 
            this.guna2PictureBox16.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_VBljSwARoz;
            this.guna2PictureBox16.Location = new System.Drawing.Point(6, 180);
            this.guna2PictureBox16.Name = "guna2PictureBox16";
            this.guna2PictureBox16.ShadowDecoration.Parent = this.guna2PictureBox16;
            this.guna2PictureBox16.Size = new System.Drawing.Size(428, 98);
            this.guna2PictureBox16.TabIndex = 13;
            this.guna2PictureBox16.TabStop = false;
            // 
            // guna2PictureBox17
            // 
            this.guna2PictureBox17.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_29n31Kwogh;
            this.guna2PictureBox17.Location = new System.Drawing.Point(0, 0);
            this.guna2PictureBox17.Name = "guna2PictureBox17";
            this.guna2PictureBox17.ShadowDecoration.Parent = this.guna2PictureBox17;
            this.guna2PictureBox17.Size = new System.Drawing.Size(405, 198);
            this.guna2PictureBox17.TabIndex = 0;
            this.guna2PictureBox17.TabStop = false;
            // 
            // guna2PictureBox10
            // 
            this.guna2PictureBox10.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox10.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_rTpQ6130mJ;
            this.guna2PictureBox10.Location = new System.Drawing.Point(572, 2);
            this.guna2PictureBox10.Name = "guna2PictureBox10";
            this.guna2PictureBox10.ShadowDecoration.Parent = this.guna2PictureBox10;
            this.guna2PictureBox10.Size = new System.Drawing.Size(176, 49);
            this.guna2PictureBox10.TabIndex = 9;
            this.guna2PictureBox10.TabStop = false;
            this.guna2PictureBox10.UseTransparentBackground = true;
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_UabrgZEqKJ;
            this.guna2PictureBox9.Location = new System.Drawing.Point(1077, 3);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.ShadowDecoration.Parent = this.guna2PictureBox9;
            this.guna2PictureBox9.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox9.TabIndex = 9;
            this.guna2PictureBox9.TabStop = false;
            // 
            // guna2PictureBox8
            // 
            this.guna2PictureBox8.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_TBUf8oXZbX;
            this.guna2PictureBox8.Location = new System.Drawing.Point(945, 0);
            this.guna2PictureBox8.Name = "guna2PictureBox8";
            this.guna2PictureBox8.ShadowDecoration.Parent = this.guna2PictureBox8;
            this.guna2PictureBox8.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox8.TabIndex = 9;
            this.guna2PictureBox8.TabStop = false;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_1AjOCxflB4;
            this.guna2PictureBox3.Location = new System.Drawing.Point(205, 0);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(72, 60);
            this.guna2PictureBox3.TabIndex = 9;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.Click += new System.EventHandler(this.guna2PictureBox3_Click);
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_qAmT68b3k2;
            this.guna2PictureBox7.Location = new System.Drawing.Point(812, 0);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.ShadowDecoration.Parent = this.guna2PictureBox7;
            this.guna2PictureBox7.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox7.TabIndex = 9;
            this.guna2PictureBox7.TabStop = false;
            this.guna2PictureBox7.Click += new System.EventHandler(this.guna2PictureBox7_Click);
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_dQoYyLwngA;
            this.guna2PictureBox4.Location = new System.Drawing.Point(374, 0);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox4.TabIndex = 9;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.Click += new System.EventHandler(this.guna2PictureBox4_Click);
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_Yxchf1XPuz;
            this.guna2PictureBox6.Location = new System.Drawing.Point(680, 0);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.ShadowDecoration.Parent = this.guna2PictureBox6;
            this.guna2PictureBox6.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox6.TabIndex = 9;
            this.guna2PictureBox6.TabStop = false;
            this.guna2PictureBox6.Click += new System.EventHandler(this.guna2PictureBox6_Click);
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_Cb9PJrHJkT;
            this.guna2PictureBox5.Location = new System.Drawing.Point(534, 0);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.ShadowDecoration.Parent = this.guna2PictureBox5;
            this.guna2PictureBox5.Size = new System.Drawing.Size(84, 67);
            this.guna2PictureBox5.TabIndex = 9;
            this.guna2PictureBox5.TabStop = false;
            this.guna2PictureBox5.Click += new System.EventHandler(this.guna2PictureBox5_Click);
            // 
            // guna2PictureBox11
            // 
            this.guna2PictureBox11.Image = global::Lunar_Client.Properties.Resources.devenv_oQuHeQUeiq;
            this.guna2PictureBox11.Location = new System.Drawing.Point(0, 662);
            this.guna2PictureBox11.Name = "guna2PictureBox11";
            this.guna2PictureBox11.ShadowDecoration.Parent = this.guna2PictureBox11;
            this.guna2PictureBox11.Size = new System.Drawing.Size(1300, 44);
            this.guna2PictureBox11.TabIndex = 11;
            this.guna2PictureBox11.TabStop = false;
            this.guna2PictureBox11.Click += new System.EventHandler(this.guna2PictureBox11_Click);
            // 
            // launchPic
            // 
            this.launchPic.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_h9QrNTNPw41;
            this.launchPic.Location = new System.Drawing.Point(387, 41);
            this.launchPic.Name = "launchPic";
            this.launchPic.ShadowDecoration.Parent = this.launchPic;
            this.launchPic.Size = new System.Drawing.Size(535, 173);
            this.launchPic.TabIndex = 8;
            this.launchPic.TabStop = false;
            this.launchPic.MouseEnter += new System.EventHandler(this.launchPic_MouseEnter);
            // 
            // launchpic2
            // 
            this.launchpic2.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_7j7ad1wciM1;
            this.launchpic2.Location = new System.Drawing.Point(423, 55);
            this.launchpic2.Name = "launchpic2";
            this.launchpic2.ShadowDecoration.Parent = this.launchpic2;
            this.launchpic2.Size = new System.Drawing.Size(534, 173);
            this.launchpic2.TabIndex = 9;
            this.launchpic2.TabStop = false;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Image = global::Lunar_Client.Properties.Resources.devenv_6vjoHk3ygH;
            this.guna2PictureBox2.Location = new System.Drawing.Point(0, 0);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(1302, 293);
            this.guna2PictureBox2.TabIndex = 0;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2PictureBox29
            // 
            this.guna2PictureBox29.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_dtMPvjXwUT;
            this.guna2PictureBox29.Location = new System.Drawing.Point(53, 37);
            this.guna2PictureBox29.Name = "guna2PictureBox29";
            this.guna2PictureBox29.ShadowDecoration.Parent = this.guna2PictureBox29;
            this.guna2PictureBox29.Size = new System.Drawing.Size(1199, 449);
            this.guna2PictureBox29.TabIndex = 0;
            this.guna2PictureBox29.TabStop = false;
            // 
            // guna2Button12
            // 
            this.guna2Button12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button12.BorderRadius = 3;
            this.guna2Button12.CheckedState.Parent = this.guna2Button12;
            this.guna2Button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button12.CustomImages.Parent = this.guna2Button12;
            this.guna2Button12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(113)))), ((int)(((byte)(206)))));
            this.guna2Button12.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button12.ForeColor = System.Drawing.Color.White;
            this.guna2Button12.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(106)))), ((int)(((byte)(203)))));
            this.guna2Button12.HoverState.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_j5ZqnhDbST;
            this.guna2Button12.HoverState.Parent = this.guna2Button12;
            this.guna2Button12.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_81EBy8odLZ;
            this.guna2Button12.ImageSize = new System.Drawing.Size(21, 14);
            this.guna2Button12.Location = new System.Drawing.Point(87, 49);
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.ShadowDecoration.Parent = this.guna2Button12;
            this.guna2Button12.Size = new System.Drawing.Size(177, 26);
            this.guna2Button12.TabIndex = 3;
            this.guna2Button12.Text = "Change Directory";
            this.guna2Button12.Click += new System.EventHandler(this.guna2Button12_Click);
            // 
            // guna2PictureBox34
            // 
            this.guna2PictureBox34.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_TsUktx6SXn;
            this.guna2PictureBox34.Location = new System.Drawing.Point(9, 3);
            this.guna2PictureBox34.Name = "guna2PictureBox34";
            this.guna2PictureBox34.ShadowDecoration.Parent = this.guna2PictureBox34;
            this.guna2PictureBox34.Size = new System.Drawing.Size(338, 138);
            this.guna2PictureBox34.TabIndex = 2;
            this.guna2PictureBox34.TabStop = false;
            // 
            // guna2PictureBox32
            // 
            this.guna2PictureBox32.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_r4QHnixpnb;
            this.guna2PictureBox32.Location = new System.Drawing.Point(65, 5);
            this.guna2PictureBox32.Name = "guna2PictureBox32";
            this.guna2PictureBox32.ShadowDecoration.Parent = this.guna2PictureBox32;
            this.guna2PictureBox32.Size = new System.Drawing.Size(242, 139);
            this.guna2PictureBox32.TabIndex = 2;
            this.guna2PictureBox32.TabStop = false;
            // 
            // guna2PictureBox28
            // 
            this.guna2PictureBox28.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_cw9TfslWIm;
            this.guna2PictureBox28.Location = new System.Drawing.Point(41, 158);
            this.guna2PictureBox28.Name = "guna2PictureBox28";
            this.guna2PictureBox28.ShadowDecoration.Parent = this.guna2PictureBox28;
            this.guna2PictureBox28.Size = new System.Drawing.Size(291, 186);
            this.guna2PictureBox28.TabIndex = 2;
            this.guna2PictureBox28.TabStop = false;
            // 
            // guna2PictureBox30
            // 
            this.guna2PictureBox30.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_QcDw492EWl;
            this.guna2PictureBox30.Location = new System.Drawing.Point(67, 8);
            this.guna2PictureBox30.Name = "guna2PictureBox30";
            this.guna2PictureBox30.ShadowDecoration.Parent = this.guna2PictureBox30;
            this.guna2PictureBox30.Size = new System.Drawing.Size(240, 48);
            this.guna2PictureBox30.TabIndex = 2;
            this.guna2PictureBox30.TabStop = false;
            // 
            // guna2PictureBox27
            // 
            this.guna2PictureBox27.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_MIKrbiUnmK;
            this.guna2PictureBox27.Location = new System.Drawing.Point(34, 8);
            this.guna2PictureBox27.Name = "guna2PictureBox27";
            this.guna2PictureBox27.ShadowDecoration.Parent = this.guna2PictureBox27;
            this.guna2PictureBox27.Size = new System.Drawing.Size(295, 89);
            this.guna2PictureBox27.TabIndex = 2;
            this.guna2PictureBox27.TabStop = false;
            // 
            // guna2PictureBox26
            // 
            this.guna2PictureBox26.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_35Usb9CXFU;
            this.guna2PictureBox26.Location = new System.Drawing.Point(58, 8);
            this.guna2PictureBox26.Name = "guna2PictureBox26";
            this.guna2PictureBox26.ShadowDecoration.Parent = this.guna2PictureBox26;
            this.guna2PictureBox26.Size = new System.Drawing.Size(237, 45);
            this.guna2PictureBox26.TabIndex = 2;
            this.guna2PictureBox26.TabStop = false;
            // 
            // guna2PictureBox25
            // 
            this.guna2PictureBox25.Image = global::Lunar_Client.Properties.Resources.Lunar_Client_Pp4Tj96Yyr;
            this.guna2PictureBox25.Location = new System.Drawing.Point(-1, 0);
            this.guna2PictureBox25.Name = "guna2PictureBox25";
            this.guna2PictureBox25.ShadowDecoration.Parent = this.guna2PictureBox25;
            this.guna2PictureBox25.Size = new System.Drawing.Size(1194, 99);
            this.guna2PictureBox25.TabIndex = 1;
            this.guna2PictureBox25.TabStop = false;
            // 
            // guna2Button21
            // 
            this.guna2Button21.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button21.CheckedState.Parent = this.guna2Button21;
            this.guna2Button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button21.CustomImages.Parent = this.guna2Button21;
            this.guna2Button21.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button21.ForeColor = System.Drawing.Color.White;
            this.guna2Button21.HoverState.Parent = this.guna2Button21;
            this.guna2Button21.Location = new System.Drawing.Point(186, 109);
            this.guna2Button21.Name = "guna2Button21";
            this.guna2Button21.ShadowDecoration.Parent = this.guna2Button21;
            this.guna2Button21.Size = new System.Drawing.Size(114, 32);
            this.guna2Button21.TabIndex = 3;
            this.guna2Button21.UseTransparentBackground = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.ClientSize = new System.Drawing.Size(1300, 800);
            this.Controls.Add(this.storeBTN1);
            this.Controls.Add(this.aboutBTN1);
            this.Controls.Add(this.settingsBTN1);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.serversBTN1);
            this.Controls.Add(this.homeBTN1);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.serverPanel);
            this.Controls.Add(this.homePanel);
            this.Controls.Add(this.aboutPanel);
            this.Controls.Add(this.settingsPanel);
            this.Controls.Add(this.realserverpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lunar Client";
            this.Load += new System.EventHandler(this.Main_Load);
            this.guna2Panel4.ResumeLayout(false);
            this.guna2Panel5.ResumeLayout(false);
            this.guna2Panel6.ResumeLayout(false);
            this.homePanel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.serverPanel.ResumeLayout(false);
            this.realserverpanel.ResumeLayout(false);
            this.settingsPanel.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.aboutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.launchPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.launchpic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox25)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button homeBTN1;
        private Guna.UI2.WinForms.Guna2Button serversBTN1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2Button exitBTN;
        private Guna.UI2.WinForms.Guna2Button settingsBTN1;
        private Guna.UI2.WinForms.Guna2Button aboutBTN1;
        private Guna.UI2.WinForms.Guna2Button storeBTN1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox11;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox12;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox13;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox18;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox19;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox20;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox15;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox16;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox17;
        private System.Windows.Forms.Panel homePanel;
        private Guna.UI2.WinForms.Guna2Button launchBTN;
        private Guna.UI2.WinForms.Guna2PictureBox launchpic2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox launchPic;
        private System.Windows.Forms.Panel serverPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox21;
        private Guna.UI2.WinForms.Guna2Button launchBTN3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox22;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox23;
        private System.Windows.Forms.Panel realserverpanel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox24;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private System.Windows.Forms.Panel settingsPanel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox25;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox26;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox27;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox34;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox32;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox30;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox28;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2Button guna2Button15;
        private System.Windows.Forms.Panel aboutPanel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox29;
        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private Guna.UI2.WinForms.Guna2Button guna2Button20;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox31;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox33;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox35;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox36;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox37;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox38;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox39;
        private Guna.UI2.WinForms.Guna2Button guna2Button21;
    }
}