# Vestige-v3-open-src

Contains the source only since I used normal mcp for Vestige (mcp 918, source replaced by Optifine 1.8.9 HD U L5).
All minecraft libraries were used, by the exception of Log4j core which is replaced by the Intent.store fixed one.
Vestige also uses lombok (projectlombok.org) and openauth (https://github.com/Litarvan/OpenAuth)

If you use any code from here, please credit me (besides from code that I did not make, which is listed in credits)

# Credits

Font renderer : https://github.com/Godwhitelight/FontRenderer