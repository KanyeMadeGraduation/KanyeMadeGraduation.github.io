import tkinter as tk
from tkinter import messagebox
import pymem
import math
import time
import threading
import psutil

_0x1A2B=0x27C6D40
_0x3C4D=0x168
_0x5E6F=0xA8
_0x7890=0x50
_0xABCD=0x1D8
_0xEF01=0x8
_0x2345=0x8
_0x6789=0x68
_0xBCDE=0x88
_0xF012=0x10
_0x3456=0x10
_0x789A=0x27C
_0xBCEF=0x280
_0x0123=0x284
_0xDEAD=0
_0xBEEF=0.2
_0xCAFE=0.00000000000000000000000000001
_0xFACE=100
_0xBABE=0.0000000000000000000000000000000000000000005
_0xD00D=100
_0xF00D=0.0000000000000000000001
_0xC0DE=0.000000000000000000000003
_0xABBA=0.02
_0x1337=0.5
_0x7331=30
_0x9999=500
_0xFLGT=0

class _0xA1B2C3:
    def __init__(self):
        self._0xD4E5=None
        self._0xF6A7=None
        self._0xB8C9=None
        self._0xDA0E=False
    def _0xFB1C(self):
        try:
            self._0xD4E5=pymem.Pymem("HytaleClient.exe")
            self._0xF6A7=self._0xD4E5.base_address
            self._0xB8C9=self._0x2D3E()
            if self._0xB8C9:
                self._0xDA0E=True
                return True,"OK"
            return False,"No player"
        except:
            return False,"Not running"
    def _0x2D3E(self):
        try:
            _0x4F5A=self._0xD4E5.read_longlong(self._0xF6A7+_0x1A2B)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0x3C4D)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0x5E6F)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0x7890)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0xABCD)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0xEF01)
            if _0x4F5A==0:return None
            _0x4F5A=self._0xD4E5.read_longlong(_0x4F5A+_0x2345)
            if _0x4F5A==0:return None
            _0x6B7C=self._0xD4E5.read_longlong(_0x4F5A+_0x6789)
            if _0x6B7C==0:return None
            _0x8D9E=self._0xD4E5.read_longlong(_0x6B7C+_0xBCDE)
            if _0x8D9E==0:return None
            _0xAF0B=self._0xD4E5.read_longlong(_0x8D9E+_0xF012)
            if _0xAF0B==0:return None
            return self._0xD4E5.read_longlong(_0xAF0B+_0x3456)
        except:
            return None
    def _0xC1D2(self):
        if not self._0xDA0E or not self._0xB8C9:
            return None,None,None
        try:
            return(self._0xD4E5.read_float(self._0xB8C9+_0x789A),self._0xD4E5.read_float(self._0xB8C9+_0xBCEF),self._0xD4E5.read_float(self._0xB8C9+_0x0123))
        except:
            return None,None,None
    def _0xE3F4(self,_0xA5B6,_0xC7D8,_0xE9FA):
        try:
            self._0xD4E5.write_float(self._0xB8C9+_0x789A,_0xA5B6)
            self._0xD4E5.write_float(self._0xB8C9+_0xBCEF,_0xC7D8)
            self._0xD4E5.write_float(self._0xB8C9+_0x0123,_0xE9FA)
            return True
        except:
            return False

class _0x0B1C2D:
    def __init__(self):
        self._0x3E4F=_0xA1B2C3()
        self._0x5A6B=False
        self._0x7C8D=False
        self._0x9EAF=tk.Tk()
        self._0x9EAF.title("TP")
        self._0x9EAF.geometry("300x350")
        self._0x9EAF.configure(bg="#1a1a1a")
        self._0xB0C1()
    def _0xB0C1(self):
        tk.Label(self._0x9EAF,text="TELEPORTER",font=("Arial",16,"bold"),bg="#1a1a1a",fg="#00ff00").pack(pady=10)
        self._0xD2E3=tk.Label(self._0x9EAF,text="Not Connected",font=("Arial",10),bg="#1a1a1a",fg="#ff0000")
        self._0xD2E3.pack(pady=5)
        tk.Button(self._0x9EAF,text="Connect",command=self._0xF4A5,bg="#4CAF50",fg="white",font=("Arial",10,"bold")).pack(pady=5)
        _0x05B6=tk.Frame(self._0x9EAF,bg="#2a2a2a")
        _0x05B6.pack(pady=10,fill="x",padx=20)
        self._0x1C7D=tk.Label(_0x05B6,text="X: ---",font=("Arial",9),bg="#2a2a2a",fg="#00ff00")
        self._0x1C7D.pack()
        self._0x2E8F=tk.Label(_0x05B6,text="Y: ---",font=("Arial",9),bg="#2a2a2a",fg="#00ff00")
        self._0x2E8F.pack()
        self._0x3FA0=tk.Label(_0x05B6,text="Z: ---",font=("Arial",9),bg="#2a2a2a",fg="#00ff00")
        self._0x3FA0.pack()
        _0x40B1=tk.Frame(self._0x9EAF,bg="#1a1a1a")
        _0x40B1.pack(pady=10,fill="x",padx=20)
        tk.Label(_0x40B1,text="X:",bg="#1a1a1a",fg="white",width=3).grid(row=0,column=0)
        self._0x51C2=tk.Entry(_0x40B1,width=15)
        self._0x51C2.grid(row=0,column=1,padx=5)
        tk.Label(_0x40B1,text="Y:",bg="#1a1a1a",fg="white",width=3).grid(row=1,column=0)
        self._0x62D3=tk.Entry(_0x40B1,width=15)
        self._0x62D3.grid(row=1,column=1,padx=5)
        tk.Label(_0x40B1,text="Z:",bg="#1a1a1a",fg="white",width=3).grid(row=2,column=0)
        self._0x73E4=tk.Entry(_0x40B1,width=15)
        self._0x73E4.grid(row=2,column=1,padx=5)
        self._0x84F5=tk.BooleanVar(value=False)
        tk.Checkbutton(self._0x9EAF,text="6b6t Bypass",variable=self._0x84F5,bg="#1a1a1a",fg="#ff4444",selectcolor="#2a2a2a",font=("Arial",9,"bold")).pack(pady=5)
        _0x95A6=tk.Frame(self._0x9EAF,bg="#1a1a1a")
        _0x95A6.pack(pady=5)
        tk.Button(_0x95A6,text="Set Current",command=self._0xA6B7,bg="#555",fg="white",width=12).pack(side="left",padx=5)
        tk.Button(_0x95A6,text="Teleport",command=self._0xB7C8,bg="#9C27B0",fg="white",width=12,font=("Arial",10,"bold")).pack(side="left",padx=5)
        self._0xC8D9=tk.Label(self._0x9EAF,text="",font=("Arial",9),bg="#1a1a1a",fg="#00ff00")
        self._0xC8D9.pack(pady=5)
    def _0xF4A5(self):
        _0xD9EA,_0xEAFB=self._0x3E4F._0xFB1C()
        if _0xD9EA:
            self._0xD2E3.config(text="Connected",fg="#00ff00")
            self._0xFB0C()
        else:
            messagebox.showerror("Error",f"Failed: {_0xEAFB}")
    def _0xFB0C(self):
        if not self._0x3E4F._0xDA0E:
            return
        _0x0C1D,_0x1D2E,_0x2E3F=self._0x3E4F._0xC1D2()
        if _0x0C1D is not None:
            self._0x1C7D.config(text=f"X: {_0x0C1D:.2f}")
            self._0x2E8F.config(text=f"Y: {_0x1D2E:.2f}")
            self._0x3FA0.config(text=f"Z: {_0x2E3F:.2f}")
        self._0x9EAF.after(10,self._0xFB0C)
    def _0xA6B7(self):
        _0x3F40,_0x4051,_0x5162=self._0x3E4F._0xC1D2()
        if _0x3F40 is not None:
            self._0x51C2.delete(0,tk.END)
            self._0x62D3.delete(0,tk.END)
            self._0x73E4.delete(0,tk.END)
            self._0x51C2.insert(0,f"{_0x3F40:.2f}")
            self._0x62D3.insert(0,f"{_0x4051:.2f}")
            self._0x73E4.insert(0,f"{_0x5162:.2f}")
    def _0xB7C8(self):
        if self._0x5A6B:
            return
        try:
            _0x6273=float(self._0x51C2.get())
            _0x7384=float(self._0x62D3.get())
            _0x8495=float(self._0x73E4.get())
            threading.Thread(target=self._0x95A6,args=(_0x6273,_0x7384,_0x8495),daemon=True).start()
        except:
            messagebox.showerror("Error","Invalid coordinates")
    def _0x95A6(self,_0xA5B6,_0xB6C7,_0xC7D8):
        self._0x5A6B=True
        _0xD8E9=False
        try:
            _0xE9FA,_0xFA0B,_0x0B1C=self._0x3E4F._0xC1D2()
            if _0xE9FA is None:
                return
            _0x1C2D=math.sqrt((_0xA5B6-_0xE9FA)**2+(_0xC7D8-_0x0B1C)**2)
            self._0xC8D9.config(text=f"Distance: {_0x1C2D:.1f}m")
            time.sleep(_0x1337)
            self._0xC8D9.config(text="Ascending...")
            _0x2D3E=max(_0xFA0B,_0xB6C7)+_0xFLGT
            while _0xFA0B<_0x2D3E and self._0x5A6B:
                _0x3E4F=min(_0xBEEF,_0x2D3E-_0xFA0B)
                _0xFA0B+=_0x3E4F
                self._0x3E4F._0xE3F4(_0xE9FA,_0xFA0B,_0x0B1C)
                time.sleep(_0xCAFE)
            time.sleep(_0xC0DE)
            _0xE9FA,_0xFA0B,_0x0B1C=self._0x3E4F._0xC1D2()
            self._0xC8D9.config(text="Traveling...")
            while _0x1C2D>_0xFACE and self._0x5A6B:
                _0x4F50=_0xA5B6-_0xE9FA
                _0x5061=_0xC7D8-_0x0B1C
                _0x1C2D=math.sqrt(_0x4F50**2+_0x5061**2)
                if self._0x84F5.get()and not _0xD8E9 and _0x1C2D<=_0x9999:
                    self._0xC8D9.config(text=f"Bypassing @ {_0x1C2D:.1f}m!")
                    try:
                        for _0x6172 in psutil.process_iter(['name']):
                            if _0x6172.info['name'].lower()in['hytaleclient.exe','hytale.exe']:
                                _0x6172.kill()
                                _0xD8E9=True
                                self._0x5A6B=False
                                messagebox.showinfo("Bypassed",f" {_0x1C2D:.1f}m")
                                return
                    except:
                        pass
                if _0x1C2D<_0xFACE:
                    break
                _0x7283=math.sqrt(_0x4F50**2+_0x5061**2)
                _0x4F50=(_0x4F50/_0x7283)*_0xFACE
                _0x5061=(_0x5061/_0x7283)*_0xFACE
                _0xE9FA+=_0x4F50
                _0x0B1C+=_0x5061
                self._0x3E4F._0xE3F4(_0xE9FA,_0xFA0B,_0x0B1C)
                _0x8394=math.sqrt((_0xA5B6-_0xE9FA)**2+(_0xC7D8-_0x0B1C)**2)
                if self._0x84F5.get()and _0x8394<=_0x9999:
                    self._0xC8D9.config(text=f"⚠ {_0x8394:.1f}m - KILL ZONE!")
                else:
                    self._0xC8D9.config(text=f"Traveling... {_0x8394:.1f}m")
                time.sleep(_0xBABE)
            _0xE9FA,_0x0B1C=_0xA5B6,_0xC7D8
            self._0x3E4F._0xE3F4(_0xE9FA,_0xFA0B,_0x0B1C)
            time.sleep(_0xABBA)
            self._0xC8D9.config(text="Descending...")
            while abs(_0xFA0B-_0xB6C7)>_0x7331 and self._0x5A6B:
                _0x94A5=min(_0xD00D,abs(_0xFA0B-_0xB6C7))
                _0xFA0B=_0xFA0B-_0x94A5 if _0xFA0B>_0xB6C7 else _0xFA0B+_0x94A5
                self._0x3E4F._0xE3F4(_0xE9FA,_0xFA0B,_0x0B1C)
                time.sleep(_0xF00D)
            self._0x3E4F._0xE3F4(_0xA5B6,_0xB6C7,_0xC7D8)
            self._0xC8D9.config(text="✓ Arrived!")
            messagebox.showinfo("Success",f"Arrived at:\n{_0xA5B6:.1f}, {_0xB6C7:.1f}, {_0xC7D8:.1f}")
        except Exception as _0xA5B6:
            self._0xC8D9.config(text=f"Error: {str(_0xA5B6)}")
        finally:
            self._0x5A6B=False
    def _0xD7E8(self):
        self._0x9EAF.mainloop()

if __name__=="__main__":
    _0x0B1C2D()._0xD7E8()